import os
from dotenv import load_dotenv
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Neo4jVector
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from neo4j import GraphDatabase
from LLMManager import LLMManager

# Load environment
load_dotenv()

# Azure LLM Setup
llm_obj = LLMManager()
azure_openai = llm_obj.create_azure_openai_llm()

# Neo4j Config
NEO4J_URI = "bolt://localhost:7687"
NEO4J_USERNAME = "neo4j"
NEO4J_PASSWORD = "password"
NEO4J_DATABASE = "resdb1"

# Embedding Model
embedding_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    model_kwargs={"device": "cpu"},
    encode_kwargs={'normalize_embeddings': False}
)

# Vector Index from Neo4j
vector_index = Neo4jVector.from_existing_graph(
    embedding=embedding_model,
    url=NEO4J_URI,
    username=NEO4J_USERNAME,
    password=NEO4J_PASSWORD,
    database=NEO4J_DATABASE,
    index_name="vector",
    keyword_index_name="keyword",
    node_label="Augmentation",
    text_node_properties=["name", "description"],
    embedding_node_property="embedding",
    search_type="hybrid"
)

# Retriever for modality
retriever = vector_index.as_retriever(search_kwargs={"k": 5})

# Prompt Template for Modality Recommendation
MODALITY_PROMPT_TEMPLATE = """
You are a smart assistant designed to analyze a user summary and suggest the best fitting modality from the following list:

["Voice", "Text", "Code", "Image"]

Use the user summary, the prior question/answer pair, and the embeddings of the most relevant context from a knowledge graph to recommend 
**ONE OR MORE** suitable modalities. Justify your recommendation with a clear, brief explanation. Also provide the top 10 matching nodes which have 
considered for giving modality recommendation.

USER SUMMARY:
{user_summary}

QUESTION:
{question}

ANSWER:
{answer}

KNOWLEDGE GRAPH CONTEXT:
{context}

Your response format should be:

Modality: <chosen_modality>
Reason: <your explanation>
"""

prompt = PromptTemplate(
    input_variables=["user_summary", "question", "answer", "context"],
    template=MODALITY_PROMPT_TEMPLATE
)
llm_chain = LLMChain(llm=azure_openai, prompt=prompt)

# User Input
user_summary = ("The system records and transcribes travel agency calls, using generative AI to extract key details and provide structured summaries for agents, "
           "customers, and supervisors. It eliminates manual effort, improves response time, and ensures accurate documentation of customer requests. "
           "Primary users include travel agents, customer support teams, and supervisors for quality assurance. Risks involve incorrect or incomplete summaries, "
           "miscommunication, and potential bias in interpreting customer priorities. To mitigate bias, the system uses diverse training data, applies age-specific rules,"
           " and maintains gender balance in decision-making. It flags offensive or sensitive language for review and allows agents to manually correct or "
           "override AI-generated summaries. Performance is monitored through metrics on accuracy and hallucination, with flagged summaries reviewed offline "
           "by the business team. Feedback is used to refine the system through data-driven adjustments and model fine-tuning. The system processes only call "
           "transcripts and includes traceability to original conversations for validation.")

question="Can you briefly describe your applications functionality?",
answer="The system records travel agency calls, transcribes them, and uses Generative AI to extract key details, providing structured summaries for agents and customers."


# Step 1: Modality Retrieval & Recommendation
docs = retriever.get_relevant_documents(user_summary)
context_text = "\n\n".join([doc.page_content for doc in docs])
response = llm_chain.invoke({
    "user_summary": user_summary,
    "question": question,
    "answer": answer,
    "context": context_text
})
recommended_modality = response["text"].split(":")[1].strip()

print("\n🔍 Recommended Modality:")
print(response["text"])

# Step 2: Fetch relevant augmentations from the graph using Cypher
driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD))
session = driver.session(database=NEO4J_DATABASE)


# Step 3: Filter augmentations using embeddings + LLM
augmentation_retriever = vector_index.as_retriever(search_kwargs={"k": 100})
augmentation_docs = augmentation_retriever.get_relevant_documents(user_summary)

# Prompt for Filtering Augmentations with LLM
AUG_FILTER_PROMPT = """
Based on the user's summary and question-answer context and recommended modality, look into the embeddings of retrieved augmentations and 
choose only the most relevant augmentations from the provided list which correlated with the modality given.

USER SUMMARY:
{user_summary}

QUESTION:
{question}

ANSWER:
{answer}

MODALITY
{recommended_modality}

AUGMENTATIONS:
{augmentations}

Return the top relevant augmentations only, with their exact description as mentioned in the graph.
Also give the top 10 matched nodes you have considered for recommending augmentations.

Output format:
"possible_augmentations": [
                {{
                    "name": "Rotation",
                    "description": "Rotate the image by a certain angle (e.g., 90°, 180°)."
                }},
                {{
                    "name": "Translation",
                    "description": "Shift the image in x or y directions to simulate different perspectives."
                }},
                {{
                    "name": "Scaling",
                    "description": "Resize the image while maintaining aspect ratio, changing its size."
                }}
]
"""

augmentation_texts = "\n\n".join([f"- {doc.page_content}" for doc in augmentation_docs])

aug_filter_chain = LLMChain(
    llm=azure_openai,
    prompt=PromptTemplate(
        input_variables=["user_summary", "question", "answer", "recommended_modality", "augmentations"],
        template=AUG_FILTER_PROMPT
    )
)

filtered_augmentations = aug_filter_chain.invoke({
    "user_summary": user_summary,
    "question": question,
    "answer": answer,
    "recommended_modality":recommended_modality,
    "augmentations": augmentation_texts
})

# Output Filtered Augmentations
print("\n📚 Filtered Relevant Augmentations (via Hybrid Embedding + LLM):")
print(filtered_augmentations["text"])


# Close the session
session.close()
