import os
from dotenv import load_dotenv
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Neo4jVector
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from neo4j import GraphDatabase

from LLMManager import LLMManager

# Initialize the LLMManager and Azure OpenAI
llm_obj = LLMManager()
azure_openai = llm_obj.create_azure_openai_llm()

NEO4J_URI = "bolt://localhost:7687"
NEO4J_USERNAME = "neo4j"
NEO4J_PASSWORD = "password"
os.environ['NEO4J_URI'] = NEO4J_URI
os.environ['NEO4J_USERNAME'] = NEO4J_USERNAME
os.environ['NEO4J_PASSWORD'] = NEO4J_PASSWORD
NEO4J_DATABASE = "resdb1"

load_dotenv()

# --- Embedding Model ---
embedding_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    model_kwargs={"device": "cpu"},
    encode_kwargs={'normalize_embeddings': False}
)

# --- Vector Index from Graph for label Augmentation ---
vector_index = Neo4jVector.from_existing_graph(
    embedding=embedding_model,
    url=NEO4J_URI,
    username=NEO4J_USERNAME,
    password=NEO4J_PASSWORD,
    database=NEO4J_DATABASE,
    index_name="vector_metrics",
    keyword_index_name="keyword_metrics",
    node_label="SubMetrics",
    text_node_properties=["name", "description"],
    embedding_node_property="embedding",
    search_type="hybrid"
)

# --- Retriever ---
retriever = vector_index.as_retriever(search_kwargs={"k": 10})

# --- Prompt Template ---
USECASE_PROMPT_TEMPLATE = """
You are a smart assistant designed to analyze a user summary and suggest the best fitting usecase from the following list:

["Summarization", "Q&A", "Code Generation", "Image Generation"]

Use the user summary, the prior question/answer pair, and the embeddings of the most relevant context from a knowledge graph to recommend 
**ONE OR MORE** suitable usecase. Justify your recommendation with a clear, brief explanation. Also provide the top 10 matching nodes which have 
considered for giving usecase recommendation.

USER SUMMARY:
{user_summary}

QUESTION:
{question}

ANSWER:
{answer}

KNOWLEDGE GRAPH CONTEXT:
{context}

Your response format should be:

Usecase: <chosen_usecase>
Reason: <your explanation>
"""

prompt = PromptTemplate(
    input_variables=["user_summary", "question", "answer", "context"],
    template=USECASE_PROMPT_TEMPLATE
)


# --- LLMChain ---
llm_chain = LLMChain(llm=azure_openai, prompt=prompt)

# --- Your input ---
user_summary = ("This AI-powered tool analyzes call conversations. It provides concise, actionable synopses for managers. "
                "Key features include automatic transcription, contextual understanding, and sentiment analysis.")

#user_summary = "We want to analyze real-time customer feedback during voice calls to detect sentiment trends and emotional cues."
question="Can you briefly describe your applications functionality?",
answer="The system records travel agency calls, transcribes them, and uses Generative AI to extract key details, providing structured summaries for agents and customers."

# --- Step 1: Retrieve relevant context from KG ---
docs = retriever.get_relevant_documents(user_summary)
context_text = "\n\n".join([doc.page_content for doc in docs])

# --- Step 2: Run the LLMChain manually ---
response = llm_chain.invoke({
    "user_summary": user_summary,
    "question": question,
    "answer": answer,
    "context": context_text
})
recommended_usecase = response["text"].split(":")[1].strip()

# --- Output ---
print("\n🔍 Recommended Usecase:")
print(response["text"])


# Step 2: Fetch relevant augmentations from the graph using Cypher
driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD))
session = driver.session(database=NEO4J_DATABASE)

# Step 3: Filter augmentations using embeddings + LLM
metrics_retriever = vector_index.as_retriever(search_kwargs={"k": 100})
metrics_docs = metrics_retriever.get_relevant_documents(user_summary)

# Prompt for Filtering Augmentations with LLM
METRICS_FILTER_PROMPT = """
Based on the user's summary, question-answer context and recommended usecase, look into the embeddings of retrieved submetrics and 
choose only the most relevant submetrics from the provided list which correlated with the usecase given. 


USER SUMMARY:
{user_summary}

QUESTION:
{question}

ANSWER:
{answer}

USECASE
{recommended_usecase}

SUBMETRICS:
{submetrics}

Return the top relevant submetrics only, with their name and exact description as mentioned in the graph. 
Refer to the output format and return the result in the same format given.
Also give the top 10 matched nodes you have considered for recommending submetrics.

Output format:
"possible_metrics": [
                {{
                    "name": "Coverage check",
                    "description": "Verifies how much of the code test data is available & checks if it's balanced with the SME provided test data spread."
                }},
                {{
                    "name": "Instruction Handling",
                    "description": "Assesses how well the output generated adhered to the instructions provided in the user prompt."
                }}
            ]
"""

metrics_texts = "\n\n".join([f"- {doc.page_content}" for doc in metrics_docs])

metrics_filter_chain = LLMChain(
    llm=azure_openai,
    prompt=PromptTemplate(
        input_variables=["user_summary", "question", "answer", "recommended_usecase" ,"submetrics"],
        template=METRICS_FILTER_PROMPT
    )
)

filtered_metrics = metrics_filter_chain.invoke({
    "user_summary": user_summary,
    "question": question,
    "answer": answer,
    "recommended_usecase": recommended_usecase,
    "submetrics": metrics_texts
})

# Output Filtered Augmentations
print("\n📚 Filtered Relevant SubMetrics (via Hybrid Embedding + LLM):")
print(filtered_metrics["text"])

# Close the session
session.close()
