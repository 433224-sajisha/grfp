import React from 'react';
import './EntityBasedInsights.css';
import AugmentationInsightsIcon from "../../../../assets/genaiIcons/emoji_objects.png"


const augmentationData = [
    { title: "Flight Booking & Fare Deals", subtitle: "Fare Classes & Restrictions", passInfo: "25 Records (30% Pass)" },
    { title: "Flight Booking & Fare Deals	", subtitle: "Multi‑City", passInfo: "15 Records (50% Pass)" },
    { title: "Flight Booking & Fare Deals", subtitle: "Non‑Refundable Tickets", passInfo: "19 Records (25% Pass)" },
    
];
const EntityBasedInsights = () => {
    return (
        <div className="augmentation-container">
            <div className="augmentation-title">
                <span className="augmentation-icon"><img src={AugmentationInsightsIcon}/></span> Entity Based Insights
            </div>
            <div className="augmentation-grid">
                {augmentationData.map((item, index) => (
                    <div key={index} className="augmentation-card">
                        <div className="card-content-entity">
                            <div className="card-title">{item.title}<br/><span>{item.subtitle}</span></div>
                            <div className="card-subtitle">
                                {item.passInfo} 
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
export default EntityBasedInsights;