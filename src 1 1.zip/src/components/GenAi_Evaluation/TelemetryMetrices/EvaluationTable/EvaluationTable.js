import React, { useState, useEffect } from 'react';

import './EvaluationTable.css';

const filterMap = {

    "Flight Booking": ["Fare Classes", "Multi-City", "Cancelation Policies"],

    "Baggage Info": ["Carry-on", "Extra Charges"],

    "Visa Support": ["Document Checklist", "Processing Time"]

};

const EvaluationTable = ({ evaluationData }) => {

    const transformApiData = (apiResponse) => {

        return apiResponse.map((item) => ({

            id: item._id,

            input: item.question,

            output: item.answer,

            topics: item.topics || [],

            subtopics: item.subtopics || [],

            metrics: item.metrics || [],

        }));

    };

    const [data, setData] = useState([]);

    const [filteredData, setFilteredData] = useState([]);

    const [selectedTopic, setSelectedTopic] = useState('');

    const [selectedSubtopics, setSelectedSubtopics] = useState([]);

    const [currentPage, setCurrentPage] = useState(1);

    const rowsPerPage = 10;

    useEffect(() => {

        const transformed = transformApiData(evaluationData);

        setData(transformed);

        setFilteredData(transformed);

    }, [evaluationData]);

    const subtopicsForSelected = selectedTopic ? filterMap[selectedTopic] || [] : [];

    const metricHeaders = Array.from(

        new Set(data.flatMap(item => item.metrics.map(m => m.name)))

    );

    const applyFilters = () => {

        const filtered = data.filter(record => {

            const topicMatch = record.topics.includes(selectedTopic);

            const subtopicMatch =

                selectedSubtopics.length === 0 ||

                record.subtopics.some(sub => selectedSubtopics.includes(sub));

            return topicMatch && subtopicMatch;

        });

        setFilteredData(filtered);

        setCurrentPage(1);

    };

    const clearFilters = () => {

        setSelectedTopic('');

        setSelectedSubtopics([]);

        setFilteredData(data);

    };

    const handleCheckboxChange = (sub) => {

        setSelectedSubtopics(prev =>

            prev.includes(sub) ? prev.filter(s => s !== sub) : [...prev, sub]

        );

    };

    const indexOfLastRow = currentPage * rowsPerPage;

    const indexOfFirstRow = indexOfLastRow - rowsPerPage;

    const currentRows = filteredData.slice(indexOfFirstRow, indexOfLastRow);

    const totalPages = Math.ceil(filteredData.length / rowsPerPage);

    return (
        <div>

            {/* Filter Panel */}
            <div style={{ marginBottom: '10px' }}>
                <button onClick={clearFilters} disabled={!selectedTopic && selectedSubtopics.length === 0}>

                    Clear Filter
                </button>
                <div style={{ border: '1px solid #ccc', padding: '10px', display: 'inline-block', marginLeft: '10px' }}>
                    <strong>Topics</strong>
                    <div>

                        {Object.keys(filterMap).map(topic => (
                            <div key={topic}>
                                <label>
                                    <input

                                        type="radio"

                                        name="topic"

                                        checked={selectedTopic === topic}

                                        onChange={() => {

                                            setSelectedTopic(topic);

                                            setSelectedSubtopics([]);

                                        }}

                                    />

                                    {topic}
                                </label>
                            </div>

                        ))}
                    </div>

                    {selectedTopic && (
                        <>
                            <hr />
                            <strong>Subtopics</strong>
                            <div>

                                {subtopicsForSelected.map(sub => (
                                    <div key={sub}>
                                        <label>
                                            <input

                                                type="checkbox"

                                                checked={selectedSubtopics.includes(sub)}

                                                onChange={() => handleCheckboxChange(sub)}

                                            />

                                            {sub}
                                        </label>
                                    </div>

                                ))}
                            </div>
                            <button onClick={applyFilters} style={{ marginTop: '10px' }}>

                                Apply
                            </button>
                        </>

                    )}
                </div>
            </div>

            {/* Table */}
            <div style={{ overflowX: 'auto' }}>
                <table className="evaluation-table">
                    <thead>
                        <tr>
                            <th className="sticky">S. No.</th>
                            <th className="sticky">Input</th>
                            <th className="sticky">Output</th>
                            <th className="sticky">Topics</th>
                            <th className="sticky">Subtopics</th>

                            {metricHeaders.map(metric => (
                                <th key={metric}>{metric}</th>

                            ))}
                        </tr>
                    </thead>
                    <tbody>

                        {currentRows.map((row, index) => (
                            <tr key={row.id}>
                                <td className="sticky">{indexOfFirstRow + index + 1}</td>
                                <td className="sticky">{row.input}</td>
                                <td className="sticky">{row.output}</td>
                                <td className="sticky">{row.topics.join(', ')}</td>
                                <td className="sticky">{row.subtopics.join(', ')}</td>

                                {metricHeaders.map(metric => {

                                    const metricObj = row.metrics.find(m => m.name === metric);

                                    return <td key={metric}>{metricObj ? metricObj.score.toFixed(2) : '-'}</td>;

                                })}
                            </tr>

                        ))}
                    </tbody>
                </table>
            </div>

            {/* Pagination */}
            <div style={{ marginTop: '10px' }}>
                <button

                    onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}

                    disabled={currentPage === 1}
                >

                    Prev
                </button>
                <span style={{ margin: '0 10px' }}>Page {currentPage} of {totalPages}</span>
                <button

                    onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}

                    disabled={currentPage === totalPages}
                >

                    Next
                </button>
            </div>
        </div>

    );

};

export default EvaluationTable;
