import React from 'react';
import './AggregatedScore.css'
import AggregatedScoreIcon from "../../../../assets/genaiIcons/blood_pressure.png"
// Utility to generate background based on score (0–1)
const getBackgroundStyle = (value) => {
    const percentage = Math.round(value * 100);
    return {
        background: `linear-gradient(to right, #e0f2fe ${percentage}%, #fff ${percentage}%)`,
        border: '1px solid #ddd',
        borderRadius: '8px',
        padding: '12px',
        textAlign: 'center',
        minWidth: '120px',
    };
};
const scores = [
    { label: 'Fluency', value: 0.9 },
    { label: 'Completeness', value:0.7 },
    { label: 'Exact Match Check', value: 0.7 },
    { label: 'Factual Accuracy', value: 0.7 },
    { label: 'Non Informativeness', value: 0.7 },
    { label: 'QA Score', value: 0.7 },
    { label: 'Bert Similarity', value: 0.6 },
    { label: 'Contradiction Check', value: 0.6 },
    { label: 'Insensitiivty', value: 0.3 },
    { label: 'Stereotype', value: 0.3 },
    { label: 'Unethical', value: 0.3 },
    { label: 'Profanity', value: 0.2 },
    { label: 'PII Detection', value: 0 },
];
const AggregatedScore = () => {
    return (
        <div style={{ background: '#fff', padding: '20px', borderRadius: '10px', boxShadow: '0 1px 4px rgba(0,0,0,0.1)',marginTop: '20px',border: '1px solid #C1C1C1' }}>
            <h2 style={{ fontSize: '16px', fontWeight: 'bold', margin:'0 0 10px 0', display: 'flex', alignItems: 'center', color: '#666687' }}>
                <span role="img" aria-label="chart" style={{ marginRight: '8px' }}><img src={AggregatedScoreIcon} />&nbsp;</span>
                Aggregated Score
            </h2>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px' }}>
                {scores.map((score, index) => (
                    <div key={index} style={getBackgroundStyle(score.value)}>
                        <div style={{ fontSize: '12px', fontWeight: 500, color: '#333' }}>{score.label}</div>
                        <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#1d4ed8' }}>{score.value}</div>
                    </div>
                ))}
            </div>
        </div>
    );
};
export default AggregatedScore;