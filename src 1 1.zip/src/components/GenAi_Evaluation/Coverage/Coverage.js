import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Button,
  CircularProgress,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import './coverage.css'
import { useState } from "react";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import listIcon from "../../../assets/genaiIcons/list_alt.svg"
import deselectIcon from "../../../assets/genaiIcons/deselect.svg"

const irrelevantData=[
  {
  "Sno": "TD030",
  "Input": {
  "Agent": "Thank you for calling Easy Travel, this is Priya. May I have your name and date of birth?",
  "Customer": "I am be Rajiv Sharm, May ten year 1988 born I is.",
  "Agent": "Thank you, Mr. Sharma; you've been with us since 2020. How can I help?",
  "Customer": "Hi, I'm calling about flight reservations.",
  "Agent": "Hello! How can I assist you with your flight reservations today?",
  "Customer": "Actually, I was wondering if you have any information about job openings at the airport.",
  "Agent": "I apologize, but we don't handle employment inquiries. We're a flight booking service. For airport job information, you might want to check the airport's official website or contact their HR department directly.",
  "Customer": "Oh, I see. Do you know which positions are typically available at airports?",
  "Agent": "I'm sorry, but I don't have that information. Our service is limited to flight bookings and related inquiries. Is there anything about flights that I can help you with?",
  "Customer": "No, I guess not. Thanks anyway!"
  },
  "Topic": "Airport Employment"
  },
  {
  "Sno": "TD034",
  "Input": {
  "Agent": "Welcome to Easy Travel, this is Alex. How may I assist you today?",
  "Customer": "Hello, I'm calling to book a flight, but I also wanted to ask about hotel recommendations near the airport.",
  "Agent": "I can certainly help you with booking a flight, but I'm afraid we don't provide hotel recommendations. Is there a specific flight you're interested in booking?",
  "Customer": "Actually, can you tell me about the best restaurants near the airport instead?",
  "Agent": "I'm sorry, but we don't have information about restaurants either. Our service is strictly for flight bookings. Would you like to proceed with booking a flight?",
  "Customer": "No, I think I'll look elsewhere for that information. Thank you anyway."
  },
  "Topic": "Local Amenities"
  },
  {
  "Sno": "TD036",
  "Input": {
  "Agent": "Thank you for contacting Easy Travel, this is Sarah. How can I help you today?",
  "Customer": "Hi Sarah, I'm calling about my upcoming flight, but I also wanted to know if you could help me plan my itinerary for my vacation.",
  "Agent": "I can certainly assist you with any questions about your flight, but we don't offer vacation planning services. What specific information do you need about your flight?",
  "Customer": "Oh, I see. Well, do you know any good travel blogs I could check for vacation ideas?",
  "Agent": "I'm sorry, but we don't have recommendations for travel blogs. Our service is focused on flight bookings and related inquiries. Is there anything about your flight that you need assistance with?",
  "Customer": "No, I guess not. I'll look for travel blogs elsewhere. Thanks for your time."
  },
  "Topic": "Vacation Planning"
  },
  {
  "Sno": "TD012",
  "Input": {
  "Agent": "Good morning, Easy Travel, this is Mike. How may I assist you?",
  "Customer": "Hi Mike, I'm calling about a flight, but I also wanted to know if you could help me with travel insurance.",
  "Agent": "I can help you with flight-related queries, but we don't offer travel insurance services. What information do you need about your flight?",
  "Customer": "Actually, can you tell me about the weather at my destination?",
  "Agent": "I'm sorry, but we don't provide weather forecasts. Our service is limited to flight bookings and related information. Is there anything specific about your flight that you need help with?",
  "Customer": "No, I suppose not. I'll check the weather elsewhere. Thank you."
  },
  "Topic": "Travel-related Services"
  },
  {
  "Sno": "TD025",
  "Input": {
  "Agent": "Welcome to Easy Travel, this is Emily. How can I help you today?",
  "Customer": "Hi Emily, I'm calling about flights, but I was wondering if you could also help me with currency exchange rates?",
  "Agent": "I can assist you with flight-related questions, but we don't provide information on currency exchange rates. What do you need to know about flights?",
  "Customer": "Oh, I see. Well, do you know anything about visa requirements for different countries?",
  "Agent": "I'm afraid we don't have information about visa requirements either. Our service is focused on flight bookings. Is there anything specific about flights that you need assistance with?",
  "Customer": "No, I guess not. I'll find that information elsewhere. Thanks for your help."
  },
  "Topic": "International Travel Information"
  }
  ]

const Coverage = (props) => {
  const [accordianStatus, setAccordianStatus] = useState(
    props.coverageDetails.map((it) => true)
  );
  const [activeTab, setActiveTab] = useState('spread')
  return (
    <div>

      <div className="tab-container">
        <div className="tab-buttons">
          <button
            className={activeTab === 'spread' ? 'active' : ''}
            onClick={() => setActiveTab('spread')}
          >
            <img src={listIcon}/>&nbsp;
            Spread Data
          </button>
          <button
            className={activeTab === 'irrelevant' ? 'active' : ''}
            onClick={() => setActiveTab('irrelevant')}
          >
            <img src={deselectIcon}/> &nbsp;
            Irrelevant Data
          </button>
        </div>
        <div className="tab-content">
          {/* {activeTab === 'spread' ? renderTable(spreadData) : renderTable(irrelevantData)} */}
        </div>
      </div>
      {props.coverageDetails.length > 0 && activeTab === 'spread' && (
        <Stack direction="row-reverse">
          <Button
            style={{ margin: "1rem 0" }}
            variant="contained"
            onClick={() => setAccordianStatus((prev) => prev.map((it) => true))}
          >
            Expand All
          </Button>
        </Stack>
      )}

      {props.loading === true && (
        <Stack width="100%" direction="row" justifyContent="center">
          <CircularProgress />
        </Stack>
      )}

      {activeTab === 'spread' && props.coverageDetails.map((row, index) => {
        return (
          <Accordion
            expanded={accordianStatus[index]}
            onChange={() =>
              setAccordianStatus((prev) => {
                let temp = [...prev];
                temp[index] = !temp[index];
                return temp;
              })
            }
            defaultExpanded={true}
          >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel1-content"
              id="panel1-header"
            >
              <Typography fontWeight={500}>Traceback {index + 1}</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <TableContainer sx={{ marginTop: "0px" }} component={Paper}>
                <Table aria-label="Material-UI Table">
                  <TableHead sx={{ background: "#78ABB6", color: "#fff" }}>
                    <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                      {props.coverageDetails &&
                        props.coverageDetails.length > 0 &&
                        Object.keys(props.coverageDetails[0]).map(
                          (row, index) => {
                            return (
                              <TableCell
                                sx={{
                                  width: "33%",
                                  padding: "0.5rem",
                                  color: "#fff",
                                  textAlign: "center",
                                  borderRight: "1px solid gray",
                                }}
                                key={index}
                              >
                                <strong>{row.toUpperCase()}</strong>
                              </TableCell>
                            );
                          }
                        )}
                    </TableRow>
                  </TableHead>

                  <TableBody>
                    <TableRow
                      key={index}
                      style={
                        index % 2
                          ? { background: "#EEF4F9" }
                          : { background: "#EEF4F9" }
                      }
                    >
                      {props.coverageDetails &&
                        props.coverageDetails.length > 0 &&
                        Object.keys(props.coverageDetails[0]).map(
                          (cell, index) => {
                            return (
                              <TableCell
                                sx={{
                                  width: "33%",
                                  padding: index === 2 ? "0 3rem" : "0.5rem",
                                  color: "black",
                                  textAlign: "center",
                                  borderRight: "1px solid gray",
                                }}
                                key={index}
                              >
                                {typeof row[cell] === "object"  ? (
                                  Object.keys(row[cell]).map((item, idx) => {
                                    return (
                                    index!==4 ?
                                      <div
                                        style={{
                                
                                        }}
                                      >
                                        <p style={{fontSize:"14px"}}>
                                          {item
                                            .split("_")
                                            .join(" ")}{" "}
                                          :{" "}
                                        </p>
                                        <strong style={{ fontSize: "1em" }}>
                                          {row[cell][item]} %
                                        </strong>
                                      </div> : <p>{row[cell][item]}</p>
                                    );
                                  })
                                ) : index === 1 ? (
                                  <strong style={{ fontSize: "1.5em" }}>
                                    {row[cell]} %
                                  </strong>
                                ) : (
                                  row[cell].split("_").join(" ")
                                )}
                              </TableCell>
                            );
                          }
                        )}
                    </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
              <br />
            </AccordionDetails>
          </Accordion>
        );
      })}





          {/* <Typography fontWeight={500}>Traceback {index + 1}</Typography> */}

      {activeTab !== 'spread' && (<TableContainer sx={{ marginTop: "50px" }} component={Paper}>
        <Table aria-label="Material-UI Table">
          <TableHead sx={{ background: "#78ABB6", color: "#fff" }}>
            <TableRow sx={{ alignItems: "center", color: "#fff" }}>

              <TableCell
                sx={{
                  width: "33%",
                  padding: "0.5rem",
                  color: "#fff",
                  textAlign: "center",
                  borderRight: "1px solid gray",
                }}
              >
                <strong>{"Sl. No"}</strong>
              </TableCell>
              <TableCell
                sx={{
                  width: "33%",
                  padding: "0.5rem",
                  color: "#fff",
                  textAlign: "center",
                  borderRight: "1px solid gray",
                }}
              >
                <strong>{"Input"}</strong>
              </TableCell>
              <TableCell
                sx={{
                  width: "33%",
                  padding: "0.5rem",
                  color: "#fff",
                  textAlign: "center",
                  borderRight: "1px solid gray",
                }}
              >
                <strong>{"Topic"}</strong>
              </TableCell>

            </TableRow>
          </TableHead>

          <TableBody>
            {irrelevantData.map((item,index)=>(<TableRow
              sx= { {background: "#EEF4F9" }} key={index}>

              <TableCell
                sx={{
                  width: "33%",
                  padding:  "0 3rem",
                  color: "black",
                  textAlign: "center",
                  borderRight: "1px solid gray",
                }}
              >

                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <p>
                  {item.Sno}
                  </p>

                </div>




              </TableCell>
              <TableCell  sx={{
                  width: "33%",
                  padding:  "0 3rem",
                  color: "black",
                  textAlign: "center",
                  borderRight: "1px solid gray",
                }}>
                {JSON.stringify(item.Input)}
              </TableCell>
              <TableCell>
                {item.Topic}
              </TableCell>
            
            </TableRow>))}
          </TableBody>
        </Table>
      </TableContainer>

      )}

    </div>
  );
};

export default Coverage;
