import { Paper, Stack, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import avgCostIcon from "../../../assets/genaiIcons/savings.png";
import avgTokenIcon from "../../../assets/genaiIcons/award_star.png";
import avgHitsIcon from "../../../assets/genaiIcons/cloud_sync.png";
import avgResponseTimeIcon from "../../../assets/genaiIcons/avg_time.png";
import RadialBarChartComponent from "./RadialBarChart";
import BarChartComponent from "./BarChart";
import CustomBarChart from "./CustomBarChart";
import { getEvaluationDashboardData } from "../../../_services/genai_evaluation.service";
import { useParams } from "react-router-dom";

const hardData = {
  "overall_latency_cost_token": [
      {
          "total_latency": 590.6952,
          "total_cost": 0.0772,
          "total_token": 4840
      }
  ],
  "execution_status": [
      {
          "name": "Total Failed",
          "value": 74
      },
      {
          "name": "Total Passed",
          "value": 106
      },
      {
          "name": "Total Executed",
          "value": 180
      }
  ],
  "evaluation_metrics_status": [
      {
          "metric": "QA_RELEVANCE",
          "Total Passed": 20,
          "Total Failed": 0
      },
      {
          "metric": "QC_RELEVANCE",
          "Total Passed": 20,
          "Total Failed": 0
      },
      {
          "metric": "SUMMARIZATION",
          "Total Passed": 19,
          "Total Failed": 1
      },
      {
          "metric": "CONTROVERSIALITY",
          "Total Passed": 16,
          "Total Failed": 4
      },
      {
          "metric": "FACTUALITY",
          "Total Passed": 15,
          "Total Failed": 5
      },
      {
          "metric": "SENTIMENT",
          "Total Passed": 16,
          "Total Failed": 4
      },
      {
          "metric": "INSENSITIVITY",
          "Total Passed": 0,
          "Total Failed": 20
      },
      {
          "metric": "MALICIOUSNESS",
          "Total Passed": 0,
          "Total Failed": 20
      },
      {
          "metric": "PROFANITY",
          "Total Passed": 0,
          "Total Failed": 20
      }
  ],
  "evaluation_metrics_latency_cost_status": {
        "Coherence": {
            "cost": 0.006686000000000001,
            "latency": 184.39448809623718,
            "token": 7028
        },
        "Summarization": {
            "cost": 0.0146035,
            "latency": 201.19862055778503,
            "token": 19279
        }
    },
}

const PerformanceMetrics = () => {

  const [data, setData] = useState(hardData)

  const parameters = useParams();

  let metricOptions = data.evaluation_metrics_status.map(item => ({label: item.metric.replace('_', ' '), value: item.metric}))

  useEffect(() => {
    getEvaluationDashboardData(parameters.id).then(result => {
      setData(result);
    })
  }, [])
  return (
    <>
      <Stack direction="row" gap="1rem" margin="1rem 0">
        <Paper
          style={{
            width: "150px",
            height: "170px",
            borderRadius: "32px",
            padding: "1rem",
          }}
          elevation={3}
        >
          <Stack height="100%" justifyContent="space-between">
            <Stack
              style={{
                height: "52px",
                width: "52px",
                backgroundColor: "#D5F2F2",
                borderRadius: "12px",
              }}
              justifyContent="center"
              alignItems={"center"}
            >
              <img src={avgCostIcon} alt="cost icon" />
            </Stack>
            <Stack>
              <Typography color="#6C6E7C" fontSize="1rem" fontWeight="400">
                Cost
              </Typography>
              <Typography color="#484A56" fontSize="2rem" fontWeight="400">
                $ {data.overall_latency_cost_token[0].total_cost || 28.42}
              </Typography>
            </Stack>
            <Typography color="#898B9B" fontSize="14px" fontWeight="400">
              {/* vs Last Month */}
            </Typography>
          </Stack>
        </Paper>

        <Paper
          style={{
            width: "150px",
            height: "170px",
            borderRadius: "32px",
            padding: "1rem",
          }}
          elevation={3}
        >
          <Stack height="100%" justifyContent="space-between">
            <Stack
              style={{
                height: "52px",
                width: "52px",
                backgroundColor: "#D5F2F2",
                borderRadius: "12px",
              }}
              justifyContent="center"
              alignItems={"center"}
            >
              <img src={avgTokenIcon} alt="token icon" />
            </Stack>
            <Stack>
              <Typography color="#6C6E7C" fontSize="1rem" fontWeight="400">
                Token
              </Typography>
              <Typography color="#484A56" fontSize="2rem" fontWeight="400">
                {data.overall_latency_cost_token[0].total_token || 8106840}
              </Typography>
            </Stack>
            <Typography color="#898B9B" fontSize="14px" fontWeight="400">
              {/* vs Last Month */}
            </Typography>
          </Stack>
        </Paper>

        <Paper
          style={{
            width: "150px",
            height: "170px",
            borderRadius: "32px",
            padding: "1rem",
          }}
          elevation={3}
        >
          <Stack height="100%" justifyContent="space-between">
            <Stack
              style={{
                height: "52px",
                width: "52px",
                backgroundColor: "#D5F2F2",
                borderRadius: "12px",
              }}
              justifyContent="center"
              alignItems={"center"}
            >
              <img src={avgHitsIcon} alt="hit icon" />
            </Stack>
            <Stack>
              <Typography color="#6C6E7C" fontSize="1rem" fontWeight="400">
                Hits
              </Typography>
              <Typography color="#484A56" fontSize="2rem" fontWeight="400">
                2400
              </Typography>
            </Stack>
            <Typography color="#898B9B" fontSize="14px" fontWeight="400">
              {/* vs Last Month */}
            </Typography>
          </Stack>
        </Paper>

        <Paper
          style={{
            width: "150px",
            height: "170px",
            borderRadius: "32px",
            padding: "1rem",
          }}
          elevation={3}
        >
          <Stack height="100%" justifyContent="space-between">
            <Stack
              style={{
                height: "52px",
                width: "52px",
                backgroundColor: "#D5F2F2",
                borderRadius: "12px",
              }}
              justifyContent="center"
              alignItems={"center"}
            >
              <img src={avgResponseTimeIcon} alt="response icon" />
            </Stack>
            <Stack>
              <Typography color="#6C6E7C" fontSize="1rem" fontWeight="400">
                Response Time
              </Typography>
              <Typography color="#484A56" fontSize="2rem" fontWeight="400">
                {data.overall_latency_cost_token[0].total_latency.toFixed(2) || 12793} s
              </Typography>
            </Stack>
            <Typography color="#898B9B" fontSize="14px" fontWeight="400">
              {/* vs Last Month */}
            </Typography>
          </Stack>
        </Paper>
      </Stack>

      <Paper style={{ padding: "1rem" }} elevation={3}>
        <div style={{ margin: "1rem" }}>
          <h3>Execution Status</h3>
          <RadialBarChartComponent data={data.execution_status} />
        </div>
      </Paper>
      <br />
      <Paper style={{ padding: "1rem" }} elevation={3}>
        <div style={{ margin: "1rem" }}>
          <h3>Evaluation Metrics Status</h3>
          <BarChartComponent metricOptions={metricOptions} data={data.evaluation_metrics_status} />
        </div>
      </Paper>
      <br />
      <Paper style={{ padding: "1rem" }} elevation={3}>
        <div style={{ margin: "1rem" }}>
          <h3>Token, Latency & Cost Status</h3>
          <CustomBarChart data={data.evaluation_metrics_latency_cost_status} />
        </div>
      </Paper>
    </>
  );
};

export default PerformanceMetrics;
