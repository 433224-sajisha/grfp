import React, { useContext, useEffect, useState } from "react";
import styles from "./Topbar.module.css";
import { FormControl, MenuItem, Select } from "@mui/material";
import { AuthContext } from "./AuthContext";
import { getAllProjects } from "../_services/genai_dataset.service";

const Topbar = (props) => {
  const ctx = useContext(AuthContext);
  const [projectName, setProjectName] = useState(ctx.projectName);
  const [projectId, setProjectId] = useState(ctx.projectId);
  const [projectList, setProjectList] = useState([]);
  const [allProjects, setAllProjects] = useState([]);

  let project_list = [
    "KM_BOT",
    "JD_QUESTIONNAIRE",
    "adminproject",
    "Conversational_AI_LUIS",
    "Conversational_AI_CLU",
    "Movie_Recommendation",
    "Healthcare_DT",
    "Alaska_Airlines",
    "Traffic_Image_classification",
    "House_pricing",
    "GENAI",
    "Financial_AI_LEX-Bot",
  ];

  const handleChangeProjectName = (event) => {
    setProjectName(event.target.value, event.target.name);
    projectList.map((item, index) => {
      if (item.value === event.target.value) {
        ctx.updateProjectId(item.value);
        ctx.updateSelectedProject(item.label);
        ctx.updateProjectSubType(allProjects[index].modelCategorySubType);
        setProjectName(item.label)
        setProjectId(item.value);
      }
    })
    window.location.reload();
  };

  useEffect(() => { 
    getAllProjects().then(result => {
      let projects = [];
      result.data.map(item => {
        projects.push({ label: item.projectName, value: item._id });
      })
      setProjectList(projects);
      setAllProjects(result.data);
    })
  }, []);
  return (
    <div className={styles.content}>
      <div className={styles.title}>{ctx.header}</div>
      <div className={styles.projectSelection}>
        <FormControl
          sx={{
            margin: "16px",
            border: "1px solid #045db9",
            borderRadius: "10px",
            "& .MuiOutlinedInput-notchedOutline": {
              border: "none",
            },
            "& .MuiSelect-select": {
              color: "#045db9",
              padding: "10px 20px",
              fontSize: "16px",
              fontWeight: "500",
            },
          }}
        >
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            sx={{
              "& .MuiSelect-icon": {
                color: "#045db9",
              },
            }}
            value={projectId}
            label="Project"
            onChange={handleChangeProjectName}
          >
            {projectList.map((project) => (
              <MenuItem value={project.value}>{project.label}</MenuItem>
            ))}
          </Select>
        </FormControl>
      </div>
    </div>
  );
};

export default Topbar;
