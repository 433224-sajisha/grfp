import React, { useContext, useEffect, useState } from "react";
import { Menu, MenuItem, Sidebar } from "react-pro-sidebar";
import { SideBarData } from "./SideBarData";
import { useNavigate } from "react-router-dom";
import styles from "./SideBar.module.css";
import ailaLogo from "../assets/img/brand/LOGO_WHITE 1.png";
import collapsedAilaLogo from "../assets/img/brand/collapsedLogo.png";
import dashboardIcon from "../assets/genaiIcons/dashboard.png";
import collapseIcon from "../assets/genaiIcons/collapse.png";
import openIcon from "../assets/genaiIcons/open.png";
import { Typography } from "@mui/material";
import { AuthContext } from "../globals/AuthContext";
// let styles = {}
const SideBar = (props) => {
  const [selected, setSelected] = useState(SideBarData[0].title);
  const [collapsed, setCollapsed] = useState(true);

  const navigate = useNavigate();
  const ctx = useContext(AuthContext);

  const handleToggleSidebar = () => {
    setCollapsed(!collapsed);
  };

  let coverWidth = collapsed ? {} : { width: "100%" };

  useEffect(() => {
    if(ctx.projectName === "Observability") {
      navigate("/genai-assurance/genai_model");
    }
  }, [ctx.projectName]);

  return (
    <Sidebar
      style={coverWidth}
      className={styles.sidebar}
      collapsed={collapsed}
    >
      <Menu iconShape="square">
        <div className={styles.subheader}>
          <img
            src={collapsed ? collapsedAilaLogo : ailaLogo}
            height={40}
            alt="Aila Logo"
          />
        </div>
        <br/>
        <MenuItem
          className={styles.menubox}
          style={{
            backgroundColor:
              "Dashboard" === selected ? "#111270" : "transparent",
          }}
          active={selected==="Dashboard"}
          icon={<img src={dashboardIcon} alt="Dashboard Icon" />}
          onClick={() => { setSelected("Dashboard");  navigate("/genai-assurance/genai_dashboard")}}
        >
          Dashboard
        </MenuItem>
        {/* <Typography className={styles.sublabel}>MANAGE</Typography> */}
        {ctx.projectName !== "Observability" ? SideBarData.map(
          (data, index) =>
            index >= 0 &&
            index < 4 && (
              <MenuItem
                className={styles.menubox}
                icon={data.icon}
                active={data.title === selected}
                style={{
                  backgroundColor:
                    data.title === selected ? "#111270" : "transparent",
                }}
                onClick={() => {
                  setSelected(data.title);
                  navigate(data.path);
                }}
              >
                {data.title}
              </MenuItem>
            )
        ) : SideBarData.map(
          (data, index) =>
            index >= 1 &&
            index < 4 && (
              <MenuItem
                className={styles.menubox}
                icon={data.icon}
                active={data.title === selected}
                style={{
                  backgroundColor:
                    data.title === selected ? "#111270" : "transparent",
                }}
                onClick={() => {
                  setSelected(data.title);
                  navigate(data.path);
                }}
              >
                {data.title}
              </MenuItem>
            )
        )}
        {/* <Typography className={styles.sublabel}>USER</Typography>
        {SideBarData.map(
          (data, index) =>
            index >= 4 && (
              <MenuItem
                className={styles.menubox}
                icon={data.icon}
                active={data.title === selected}
                style={{
                  backgroundColor:
                    data.title === selected ? "#111270" : "transparent",
                }}
                onClick={() => {
                  setSelected(data.title);
                  navigate(data.path);
                }}
              >
                {data.title}
              </MenuItem>
            )
        )} */}
      </Menu>
      <div className={styles.footer}>
        <img
          src={collapsed ? openIcon : collapseIcon}
          alt="Collapse Sidebar"
          onClick={handleToggleSidebar}
        />
      </div>
    </Sidebar>
  );
};

export default SideBar;
