import axios from 'axios';
import React, { useEffect, useRef, useState } from 'react';
import './AugmentationPanel.css';
import { createAugmentation } from '../../../../_services/genai_dataset.service';
const CreateAugmentationModal = ({ onClose, onSave, existingAugmentNames }) => {
    const [step, setStep] = useState('details');
    const [augmentName, setAugmentName] = useState('');
    const [description, setDescription] = useState('');
    const [examples, setExamples] = useState([{ original: '', augmented: '' }]);
    const [prompt, setPrompt] = useState('');
    const [errors, setErrors] = useState({});
    const [generatedPrompt, setGeneratedPrompt] = useState('');
    const [error, setError] = useState('');
    const [newAugId, setNewAugId] = useState(null);
    const popupRef = useRef(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const handleClickOutside = (e) => {
            if (popupRef.current && !popupRef.current.contains(e.target)) {
                onClose();
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [onClose]);

    const handleExampleChange = (index, field, value) => {
        const newExamples = [...examples];
        newExamples[index][field] = value;
        setExamples(newExamples);
    };
    const addExample = () => {
        setExamples([...examples, { original: '', augmented: '' }]);
    };
    const validateDetails = () => {
        const errs = {};
        if (!augmentName.trim()) errs.augmentName = 'Required';
        else if (existingAugmentNames.includes(augmentName.trim())) errs.augmentName = 'Already exists';
        if (!description.trim()) errs.description = 'Required';
        const validExamples = examples.filter(ex => ex.original.trim() && ex.augmented.trim());
        if (validExamples.length === 0) errs.examples = 'At least one valid example required';
        setErrors(errs);
        return Object.keys(errs).length === 0;
    };
    const generatePrompt = () => {
        let promptText = "Transform the following inputs based on the provided examples:\n\n";
        examples.forEach((ex, idx) => {
            if (ex.original && ex.augmented) {
                promptText += `Example ${idx + 1}:\nInput: ${ex.original}\nOutput: ${ex.augmented}\n\n`;
            }
        });
        return promptText;
    };
    // const handleNext = () => {
    //     if (validateDetails()) {
    //         setPrompt(generatePrompt());
    //         setStep('prompt');
    //     }
    // };
    const handleNext = async () => {
        if (validateDetails()) {
            setLoading(true);
            const payload = {
                augmentation_name: augmentName,
                description: description,
                examples: examples.map(ex => ({
                    original_input: ex.original,
                    augmented_input: ex.augmented
                }))
            };
            try {
                const response = await createAugmentation(payload)
                const { id, generated_prompt } = response;
                setNewAugId(id);  // Save ID for updating prompt later
                setGeneratedPrompt(generated_prompt);  // Use API-provided prompt
                setStep('prompt');
                setError('');
            } catch (err) {
                let msg = 'Error:'
                if (err) {
                    msg = err?.response?.data?.error || err?.response?.statusText;
                } else if (err.request) {
                    msg = 'No response'
                }
                console.log(msg, "sddsd")
                setError(msg);
            } finally {
                setLoading(false);
            }
        }
    };
    const handleSave = () => {
        if (!prompt.trim()) {
            setErrors({ prompt: 'Prompt cannot be empty' });
            return;
        }
        const newAug = {
            name: augmentName.trim(),
            description: description.trim(),
            examples,
            prompt: prompt.trim()
        };
        onSave(newAug);
        onClose();
    };
    const handleFinalSave = async () => {
        if (!newAugId || !generatedPrompt.trim()) {
            setError('Prompt cannot be empty');
            return;
        }
        setLoading(true);
        try {
            await axios.post(`http://10.120.100.63:5000/data-gen/save-prompt`, {

                "augmentation_id": newAugId,
                "updated_prompt": generatedPrompt


            });
            const newAug = {
                id: newAugId,
                name: augmentName.trim(),
                description: description.trim(),
                groups: ['All']
            };
            onSave(newAug);  // Add to grid
            onClose();         // Close popup
        } catch (err) {
            const msg = err.response?.error?.message || 'Failed to update prompt';
            console.log(err)
            setError(msg);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="modal-overlay slide-in-right">
            <div className="modal wide">
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                    <h3>Create New Augmentation</h3>
                    <button onClick={onClose} style={{height:'20px',marginLeft:'30px',borderRadius:'50%',border:'solid 2px #1976d2',color:'#1976d2',cursor:'pointer'}}>X</button>
                </div>
                <div className="tab-header">
                    <span className={step === 'details' ? 'active' : ''}>Details</span>
                    <span className={step === 'prompt' ? 'active' : ''}>Generated Prompt</span>
                </div>
                {step === 'details' && (
                    <>
                        <label>Augment Name</label>
                        <input value={augmentName} onChange={(e) => setAugmentName(e.target.value)} />
                        {errors.augmentName && <div className="error">{errors.augmentName}</div>}
                        <label>Description</label>
                        <input value={description} onChange={(e) => setDescription(e.target.value)} />
                        {errors.description && <div className="error">{errors.description}</div>}
                        <label>Provide Examples</label>
                        {examples.map((ex, idx) => (
                            <div key={idx} className="example-pair">
                                <input
                                    placeholder="Original Input"
                                    value={ex.original}
                                    onChange={(e) => handleExampleChange(idx, 'original', e.target.value)}
                                />
                                <input
                                    placeholder="Augmented Input"
                                    value={ex.augmented}
                                    onChange={(e) => handleExampleChange(idx, 'augmented', e.target.value)}
                                />
                            </div>
                        ))}
                        {errors.examples && <div className="error">{errors.examples}</div>}
                        <button onClick={addExample}>Add More</button>

                        {errors.prompt && <div className="error">{errors.prompt}</div>}
                        <div className="modal-actions">
                            <button onClick={handleNext}>Continue & Generate Prompt</button>
                        </div>
                    </>
                )}
                {step === 'prompt' && (
                    <>
                        <label>Generated Prompt</label>
                        <textarea
                            rows="10"
                            value={generatedPrompt}
                            onChange={(e) => setPrompt(e.target.value)}
                        />
                        {error && <div className="error">{error}</div>}
                        <div className="modal-actions">
                            <button onClick={() => setStep('details')}>Back</button>
                            <button onClick={handleFinalSave}>Save & Continue</button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};
export default CreateAugmentationModal;