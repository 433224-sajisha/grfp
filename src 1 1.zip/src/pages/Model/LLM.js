import {
  Button,
  FormControl,
  FormLabel,
  IconButton,
  MenuItem,
  Paper,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  TextField,
} from "@mui/material";
import React, { useContext, useEffect, useState } from "react";
import classes from "./LLM.module.css";
import { getModelDetails } from "../../_services/genai_evaluation.service";
import { AuthContext } from "../../globals/AuthContext";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import {
  createNewModel,
  deleteLlmModelConfiguration,
  getExistingModels,
  updateModel,
} from "../../_services/model.service";
import Confirmation from "../../components/Confirmation/Confirmation";

const awsFields = [
  { label: "Service Name", key: "SERVICE_NAME" },
  { label: "Region Name", key: "REGION_NAME" },
  { label: "Access Key ID", key: "AWS_ACCESS_KEY_ID" },
  { label: "Secret Access Key", key: "AWS_SECRET_ACCESS_KEY" },
];

const azureFields = [
  { label: "OpenAI API Key", key: "OPENAI_API_KEY" },
  { label: "OpenAI API Version", key: "OPENAI_API_VERSION" },
  { label: "Deployment Name", key: "DEPLOYMENT_NAME" },
  { label: "OpenAI Endpoint", key: "OPENAI_ENDPOINT" },
];

const anthropicFields = [
  { label: "Anthropic API Key", key: "ANTHROPIC_API_KEY" },
];

const LLM = () => {
  const [provider, setProvider] = useState("");
  const [modelName, setModelName] = useState("");
  const [modelDetails, setModelDetails] = useState({});
  const [evaluatorName, setEvaluatorName] = useState("");
  const [providersList, setProvidersList] = useState([]);
  const [existingModels, setExistingModels] = useState([]);
  const [isEdit, setIsEdit] = useState(false);
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(5);
  const [confirm, setConfirm] = useState(false);
  const [selectedId, setSelectedId] = useState("");
  const [refresh, setRefresh] = useState(false);
  const [editId, setEditId] = useState("");

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const ctx = useContext(AuthContext);

  const handleCreate = () => {
    if (!isEdit) {
      let data = {
        projectName: ctx.projectName,
        customEvaluatorName: evaluatorName,
        model: modelName,
        provider: provider,
        modelDetails: modelDetails,
      };
      createNewModel(data).then((result) => {
        getExistingModels({
          projectName: ctx.projectName,
        }).then((res) => {
          setExistingModels(res);
        });
      });
    } else {
      let data = {
        customEvaluatorName: evaluatorName,
        model: modelName,
        provider: provider,
        modelDetails: modelDetails,
        id: editId,
      };
      updateModel(data).then((res) => {
        getExistingModels({
          projectName: ctx.projectName,
        }).then((res) => {
          setExistingModels(res);
        });
        setIsEdit(false);
      });
    }

    setEvaluatorName("");
    setModelDetails({});
    setModelName("");
    setProvider("");
  };

  const toggleConfirm = () => {
    setConfirm((prev) => !prev);
  };

  const handleDeleteModelConfiguration = (id) => {
    deleteLlmModelConfiguration(id).then((result) => {
      setRefresh(true);
    });
  };

  useEffect(() => {
    if (refresh) {
      getExistingModels({
        projectName: ctx.projectName,
      }).then((res) => {
        setExistingModels(res);
      });
      setRefresh(false);
    }
  }, [refresh]);

  useEffect(() => {
    getModelDetails().then((result) => {
      const parsedModels = JSON.parse(result.models);

      const providers = {};

      parsedModels.forEach((item) => {
        const provider = item.Provider;
        const models = item.Model;
        providers[provider] = models;
      });

      setProvidersList(providers);
    });

    getExistingModels({
      projectName: ctx.projectName,
    }).then((res) => {
      setExistingModels(res);
    });
  }, []);

  return (
    <>
      <div className={classes.content}>
        <Stack direction="column" spacing={2}>
          <Stack direction="row" alignItems="center" spacing={2}>
            <FormLabel sx={{ width: "10rem" }}>Generator Name</FormLabel>
            <FormLabel>:</FormLabel>
            <FormControl sx={{ m: 1, width: "70%" }}>
              <TextField
                // label="Generator Name"
                variant="outlined"
                disabled={isEdit}
                value={evaluatorName}
                onChange={(e) => {
                  setEvaluatorName(e.target.value);
                }}
              />
            </FormControl>
          </Stack>
          <Stack direction="row" alignItems="center" spacing={2}>
            <FormLabel sx={{ width: "10rem" }}>Provider</FormLabel>
            <FormLabel>:</FormLabel>
            <FormControl sx={{ m: 1, width: "70%" }}>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={provider}
                onChange={(e) => setProvider(e.target.value)}
              >
                {Object.keys(providersList).map((item) => (
                  <MenuItem key={item} value={item}>
                    {item}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Stack>

          <Stack direction="row" alignItems="center" spacing={2}>
            <FormLabel sx={{ width: "10rem" }}>Model</FormLabel>
            <FormLabel>:</FormLabel>
            <FormControl sx={{ m: 1, width: "70%" }}>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={modelName}
                onChange={(e) => setModelName(e.target.value)}
              >
                {provider === "AWS-Bedrock"
                  ? providersList["AWS-Bedrock"].map((item) => (
                      <MenuItem key={item} value={item}>
                        {item}
                      </MenuItem>
                    ))
                  : provider === "Azure"
                  ? providersList["Azure"].map((item) => (
                      <MenuItem key={item} value={item}>
                        {item}
                      </MenuItem>
                    ))
                  : provider === "Anthropic"
                  ? providersList["Anthropic"].map((item) => (
                      <MenuItem key={item} value={item}>
                        {item}
                      </MenuItem>
                    ))
                  : provider === "Cohere"
                  ? providersList["Cohere"].map((item) => (
                      <MenuItem key={item} value={item}>
                        {item}
                      </MenuItem>
                    ))
                  : provider === "Meta"
                  ? providersList["Meta"].map((item) => (
                      <MenuItem key={item} value={item}>
                        {item}
                      </MenuItem>
                    ))
                  : [].map((item) => (
                      <MenuItem key={item} value={item}>
                        {item}
                      </MenuItem>
                    ))}
              </Select>
            </FormControl>
          </Stack>

          {provider === "AWS-Bedrock"
            ? awsFields.map((item, index) => (
                <>
                  <Stack direction="row" alignItems="center" spacing={2}>
                    <FormLabel sx={{ width: "10rem" }}>{item.label}</FormLabel>
                    <FormLabel>:</FormLabel>
                    <FormControl sx={{ m: 1, width: "70%" }}>
                      <TextField
                        key={index}
                        label={item.label}
                        value={modelDetails[item.key]}
                        variant="outlined"
                        onChange={(e) => {
                          setModelDetails((prev) => {
                            let obj = { ...prev };
                            obj[item.key] = e.target.value;
                            return obj;
                          });
                        }}
                      />
                    </FormControl>
                  </Stack>
                </>
              ))
            : provider === "Azure"
            ? azureFields.map((item, index) => (
                <>
                  <Stack direction="row" alignItems="center" spacing={2}>
                    <FormLabel sx={{ width: "10rem" }}>{item.label}</FormLabel>
                    <FormLabel>:</FormLabel>
                    <FormControl sx={{ m: 1, width: "70%" }}>
                      <TextField
                        key={index}
                        label={item.label}
                        value={modelDetails[item.key]}
                        variant="outlined"
                        onChange={(e) => {
                          setModelDetails((prev) => {
                            let obj = { ...prev };
                            obj[item.key] = e.target.value;
                            return obj;
                          });
                        }}
                      />
                    </FormControl>
                  </Stack>
                </>
              ))
            : provider === "Anthropic"
            ? anthropicFields.map((item, index) => (
                <>
                  <Stack direction="row" alignItems="center" spacing={2}>
                    <FormLabel sx={{ width: "10rem" }}>{item.label}</FormLabel>
                    <FormLabel>:</FormLabel>
                    <FormControl sx={{ m: 1, width: "70%" }}>
                      <TextField
                        key={index}
                        label={item.label}
                        variant="outlined"
                        onChange={(e) => {
                          setModelDetails((prev) => {
                            let obj = { ...prev };
                            obj[item.key] = e.target.value;
                            return obj;
                          });
                        }}
                      />
                    </FormControl>
                  </Stack>
                </>
              ))
            : ""}
          <div
            style={{
              textAlign: "left",
              paddingTop: "1rem",
            }}
          >
            <Button
              style={{ marginBottom: "1rem" }}
              variant="contained"
              color="primary"
              onClick={handleCreate}
            >
              {isEdit ? "Update" : "Create"}
            </Button>
          </div>
        </Stack>
      </div>
      <br />
      <div className={classes.content}>
        {existingModels.length > 0 && (
          <div className={classes.saved_configurations}>
            <h3>Existing Models</h3>
            <TableContainer component={Paper}>
              <Table aria-label="Material-UI Table">
                <TableHead sx={{ background: "#111270", color: "#fff" }}>
                  <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                    <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                      Generator Name
                    </TableCell>
                    <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                      Model
                    </TableCell>
                    <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                      Action
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {existingModels
                    .slice(page * rowPage, page * rowPage + rowPage)
                    .map((model, index) => (
                      <TableRow
                        style={
                          index % 2
                            ? { background: "#F6F6F6" }
                            : { background: "white" }
                        }
                        key={index}
                      >
                        <TableCell>{model.customEvaluatorName}</TableCell>
                        <TableCell>{model.model}</TableCell>
                        <TableCell>
                          <Stack direction="row">
                            <IconButton
                              color="primary"
                              size="small"
                              onClick={() => {
                                setIsEdit(true);
                                setEvaluatorName(model.customEvaluatorName);
                                setModelDetails(model.details);
                                setModelName(model.model);
                                setProvider(model.provider);
                                setEditId(model.id);
                              }}
                            >
                              <EditIcon fontSize="inherit" />
                            </IconButton>
                            <IconButton color="error" size="small">
                              <DeleteIcon
                                fontSize="inherit"
                                onClick={() => {
                                  setSelectedId(model.id);
                                  toggleConfirm();
                                }}
                              />
                            </IconButton>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </TableContainer>
            <TablePagination
              rowsPerPageOptions={[5, 10, 25]}
              component="div"
              count={existingModels.length}
              rowsPerPage={rowPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            />
          </div>
        )}
        <Confirmation
          open={confirm}
          toggleConfirm={toggleConfirm}
          handleSubmit={() => {
            handleDeleteModelConfiguration(selectedId);
            toggleConfirm();
          }}
          message="Are you sure you want to delete this?"
        />
      </div>
    </>
  );
};

export default LLM;
