// Function to decode the ISO 8601 timestamp and display in readable format
export function formatTimestamp(isoString) {
    // Create a new Date object from the ISO 8601 string
    const date = new Date(isoString);

    // Extract the components
    const year = date.getFullYear();
    const month = date.getMonth() + 1; // Months are zero-indexed, so we add 1
    const day = date.getDate();
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();
    const milliseconds = date.getMilliseconds();

    // Format the components into a readable string
    const formattedDate = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const formattedTime = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(milliseconds).padStart(3, '0')}`;

    // Combine the date and time parts
    // const readableFormat = `${formattedDate} ${formattedTime}`;
    const readableFormat = `${formattedDate}`;

    return readableFormat;
}

// // Example usage
// const isoTimestamp = "2024-06-13T08:46:09.977785";
// console.log(formatTimestamp(isoTimestamp));
