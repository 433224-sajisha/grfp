export function handleResponse(response) {
    
    return response.text().then(text => {
        try {
            const data = text && JSON.parse(text);
            if (response.status === 200 || response.status === 201) {
                return data;
            } else {
                if (response.status === 401) {
                    logout();
                    window.location.reload(true);
                }
    
                const error = (data && data.message) || response.statusText;
                return Promise.reject(error);
            }
        } catch(e){
            logout();
            // window.location.reload(true);
        }
    });
}

function logout() {
    localStorage.removeItem('user');
    localStorage.setItem('sessionExpire', 'Session is expired. Please login again.');
}