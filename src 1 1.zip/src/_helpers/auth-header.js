export function authHeader() {
    return 'Bearer ' + localStorage.getItem('user');
    // return { 'Authorization': localStorage.getItem('user') };

    /* let user = JSON.parse(localStorage.getItem('user'));
    if (user && user.authdata) {
        return { 'Authorization': 'Basic ' + user.authdata };
    } else {
        return {};
    }*/
}