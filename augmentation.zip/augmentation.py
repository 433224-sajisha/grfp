import os
from dotenv import load_dotenv
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Neo4jVector
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from neo4j import GraphDatabase
from LLMManager import LLMManager

# Load environment
load_dotenv()

# Azure LLM Setup
llm_obj = LLMManager()
azure_openai = llm_obj.create_azure_openai_llm()

# Neo4j Config
NEO4J_URI = "bolt://localhost:7687"
NEO4J_USERNAME = "neo4j"
NEO4J_PASSWORD = "password"
NEO4J_DATABASE = "resdb1"

# Embedding Model
embedding_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    model_kwargs={"device": "cpu"},
    encode_kwargs={'normalize_embeddings': False}
)

# Vector Index from Neo4j
vector_index = Neo4jVector.from_existing_graph(
    embedding=embedding_model,
    url=NEO4J_URI,
    username=NEO4J_USERNAME,
    password=NEO4J_PASSWORD,
    database=NEO4J_DATABASE,
    index_name="vector",
    keyword_index_name="keyword",
    node_label="Augmentation",
    text_node_properties=["name", "description"],
    embedding_node_property="embedding",
    search_type="hybrid"
)

# Retriever for modality
retriever = vector_index.as_retriever(search_kwargs={"k": 5})

# Prompt Template for Modality Recommendation
MODALITY_PROMPT_TEMPLATE = """
You are a smart assistant designed to analyze a user summary and suggest the best fitting modality from the following list:

["Voice", "Text", "Code", "Image"]

Use the user summary, the prior question/answer pair, and the most relevant context from a knowledge graph to recommend 
**ONE OR MORE** suitable modalities. Justify your recommendation with a clear, brief explanation.

USER SUMMARY:
{user_summary}

QUESTION:
{question}

ANSWER:
{answer}

KNOWLEDGE GRAPH CONTEXT:
{context}

Your response format should be:

Modality: <chosen_modality>
Reason: <your explanation>
"""

prompt = PromptTemplate(
    input_variables=["user_summary", "question", "answer", "context"],
    template=MODALITY_PROMPT_TEMPLATE
)
llm_chain = LLMChain(llm=azure_openai, prompt=prompt)

# User Input
user_summary = ("The system records and transcribes travel agency calls, using generative AI to extract key details and provide structured summaries for agents, "
           "customers, and supervisors. It eliminates manual effort, improves response time, and ensures accurate documentation of customer requests. "
           "Primary users include travel agents, customer support teams, and supervisors for quality assurance. Risks involve incorrect or incomplete summaries, "
           "miscommunication, and potential bias in interpreting customer priorities. To mitigate bias, the system uses diverse training data, applies age-specific rules,"
           " and maintains gender balance in decision-making. It flags offensive or sensitive language for review and allows agents to manually correct or "
           "override AI-generated summaries. Performance is monitored through metrics on accuracy and hallucination, with flagged summaries reviewed offline "
           "by the business team. Feedback is used to refine the system through data-driven adjustments and model fine-tuning. The system processes only call "
           "transcripts and includes traceability to original conversations for validation.")

question="Can you briefly describe your applications functionality?",
answer="The system records travel agency calls, transcribes them, and uses Generative AI to extract key details, providing structured summaries for agents and customers."


# Step 1: Modality Retrieval & Recommendation
docs = retriever.get_relevant_documents(user_summary)
context_text = "\n\n".join([doc.page_content for doc in docs])
response = llm_chain.invoke({
    "user_summary": user_summary,
    "question": question,
    "answer": answer,
    "context": context_text
})
recommended_modality = response["text"].split(":")[1].strip()

print("\n🔍 Recommended Modality:")
print(response["text"])

# --- Show Source Documents (from Neo4j) ---
print("\n📚 Source Nodes from KG:")
for i, doc in enumerate(docs, 1):
    print(f"\n--- Node {i} ---")
    print(f"Content: {doc.page_content}")
    print(f"Metadata: {doc.metadata}")

# Step 2: Fetch relevant augmentations from the graph using Cypher
driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD))
session = driver.session(database=NEO4J_DATABASE)


# def get_relevant_augmentations(modality_string):
#     # Clean and parse list from string like '["voice/speech", "text/prompt"]'
#     import ast
#     try:
#         modalities = ast.literal_eval(modality_string)
#         if not isinstance(modalities, list):
#             modalities = [modalities]
#     except Exception:
#         modalities = [modality_string]
#
#     # Build safe query for dynamic values
#     modality_params = ', '.join([f'"{m}"' for m in modalities])
#
#     query = f"""
#     MATCH (md)-[:ENHANCED_BY]->(a:Augmentation)
#     WHERE md.name IN [{modality_params}]
#     RETURN a.name AS augmentation_name, a.description AS augmentation_description
#     """
#     result = session.run(query)
#     augmentations = []
#     for record in result:
#         augmentations.append({
#             "name": record["augmentation_name"],
#             "description": record["augmentation_description"]
#         })
#     print("Augmentations" , augmentations)
#     return augmentations
#
#
# # Fetch augmentations based on recommended modality
# relevant_augmentations = get_relevant_augmentations(recommended_modality)

# # Show the augmentations fetched from the graph
# print("\n📚 Relevant Augmentations from KG (via Cypher):")
# for i, aug in enumerate(relevant_augmentations, 1):
#     print(f"\n--- Augmentation {i} ---")
#     print(f"Name: {aug['name']}")
#     print(f"Description: {aug['description']}")

# Step 3: Filter augmentations using embeddings + LLM
augmentation_retriever = vector_index.as_retriever(search_kwargs={"k": 100})
augmentation_docs = augmentation_retriever.get_relevant_documents(user_summary)

# Prompt for Filtering Augmentations with LLM
AUG_FILTER_PROMPT = """
Based on the user's summary and question-answer context, choose only the most relevant augmentations from the following list.

USER SUMMARY:
{user_summary}

QUESTION:
{question}
ANSWER:
{answer}

AUGMENTATIONS:
{augmentations}

Return the top relevant augmentations only, with brief reasons for selection.
"""

augmentation_texts = "\n\n".join([f"- {doc.page_content}" for doc in augmentation_docs])

aug_filter_chain = LLMChain(
    llm=azure_openai,
    prompt=PromptTemplate(
        input_variables=["user_summary", "question", "answer", "augmentations"],
        template=AUG_FILTER_PROMPT
    )
)

filtered_augmentations = aug_filter_chain.invoke({
    "user_summary": user_summary,
    "question": question,
    "answer": answer,
    "augmentations": augmentation_texts
})

# Output Filtered Augmentations
print("\n📚 Filtered Relevant Augmentations (via Hybrid Embedding + LLM):")
print(filtered_augmentations["text"])

# Show Source Docs for Augmentations
print("\n📦 Source Nodes (Documents) Retrieved from KG for Augmentation Filtering:")
for i, doc in enumerate(augmentation_docs, 1):
    print(f"\n--- Source Document {i} ---")
    print(f"Content: {doc.page_content}")
    print(f"Metadata: {doc.metadata}")

# Close the session
session.close()
