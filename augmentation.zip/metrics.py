import os
from dotenv import load_dotenv
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Neo4jVector
from langchain_community.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from neo4j import GraphDatabase

from LLMManager import LLMManager

# Initialize the LLMManager and Azure OpenAI
llm_obj = LLMManager()
azure_openai = llm_obj.create_azure_openai_llm()

NEO4J_URI = "bolt://localhost:7687"
NEO4J_USERNAME = "neo4j"
NEO4J_PASSWORD = "password"
os.environ['NEO4J_URI'] = NEO4J_URI
os.environ['NEO4J_USERNAME'] = NEO4J_USERNAME
os.environ['NEO4J_PASSWORD'] = NEO4J_PASSWORD
NEO4J_DATABASE = "resdb1"

load_dotenv()

# --- Embedding Model ---
embedding_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    model_kwargs={"device": "cpu"},
    encode_kwargs={'normalize_embeddings': False}
)

# --- Vector Index from Graph for label Augmentation ---
vector_index = Neo4jVector.from_existing_graph(
    embedding=embedding_model,
    url=NEO4J_URI,
    username=NEO4J_USERNAME,
    password=NEO4J_PASSWORD,
    database=NEO4J_DATABASE,
    index_name="vector_metrics",
    keyword_index_name="keyword_metrics",
    node_label="SubMetrics",
    text_node_properties=["name", "description"],
    embedding_node_property="embedding",
    search_type="hybrid"
)

# --- Retriever ---
retriever = vector_index.as_retriever(search_kwargs={"k": 10})

# --- Prompt Template ---
USECASE_PROMPT_TEMPLATE = """
You are a smart assistant designed to analyze a user summary and suggest the best fitting usecase from the following list:

["Summarization", "Q&A", "Code Generation", "Image Generation"]

Use the user summary, the prior question/answer pair, and the most relevant context from a knowledge graph to recommend 
**ONE OR MORE** suitable usecase. Justify your recommendation with a clear, brief explanation.

USER SUMMARY:
{user_summary}

QUESTION:
{question}

ANSWER:
{answer}

KNOWLEDGE GRAPH CONTEXT:
{context}

Your response format should be:

Usecase: <chosen_usecase>
Reason: <your explanation>
"""

prompt = PromptTemplate(
    input_variables=["user_summary", "question", "answer", "context"],
    template=USECASE_PROMPT_TEMPLATE
)


# --- LLMChain (not RetrievalQA!) ---
llm_chain = LLMChain(llm=azure_openai, prompt=prompt)

# --- Your input ---
user_summary = "The system records and transcribes travel agency calls, using generative AI to extract key details and provide structured summaries for agents, "
"customers, and supervisors. It eliminates manual effort, improves response time, and ensures accurate documentation of customer requests. "
"Primary users include travel agents, customer support teams, and supervisors for quality assurance. Risks involve incorrect or incomplete summaries, "
"miscommunication, and potential bias in interpreting customer priorities. To mitigate bias, the system uses diverse training data, applies age-specific rules,"
" and maintains gender balance in decision-making. It flags offensive or sensitive language for review and allows agents to manually correct or "
"override AI-generated summaries. Performance is monitored through metrics on accuracy and hallucination, with flagged summaries reviewed offline "
"by the business team. Feedback is used to refine the system through data-driven adjustments and model fine-tuning. The system processes only call "
"transcripts and includes traceability to original conversations for validation."

#user_summary = "We want to analyze real-time customer feedback during voice calls to detect sentiment trends and emotional cues."
question="Can you briefly describe your applications functionality?",
answer="The system records travel agency calls, transcribes them, and uses Generative AI to extract key details, providing structured summaries for agents and customers."

# --- Step 1: Retrieve relevant context from KG ---
docs = retriever.get_relevant_documents(user_summary)
context_text = "\n\n".join([doc.page_content for doc in docs])

# --- Step 2: Run the LLMChain manually ---
response = llm_chain.invoke({
    "user_summary": user_summary,
    "question": question,
    "answer": answer,
    "context": context_text
})
recommended_metrics = response["text"].split(":")[1].strip()

# --- Output ---
print("\n🔍 Recommended Usecase:")
print(response["text"])

# --- Show Source Documents (from Neo4j) ---
print("\n📚 Source Nodes from KG:")
for i, doc in enumerate(docs, 1):
    print(f"\n--- Node {i} ---")
    print(f"Content: {doc.page_content}")
    print(f"Metadata: {doc.metadata}")


# Step 2: Fetch relevant augmentations from the graph using Cypher
driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD))
session = driver.session(database=NEO4J_DATABASE)


def get_relevant_submetrics(modality_string):
    # Clean and parse list from string like '["voice/speech", "text/prompt"]'
    import ast
    try:
        metrics = ast.literal_eval(modality_string)
        if not isinstance(metrics, list):
            modalities = [metrics]
    except Exception:
        metrics = [modality_string]

    # Build safe query for dynamic values
    modality_params = ', '.join([f'"{m}"' for m in metrics])

    query = f"""
    MATCH (md)-[:ENHANCED_BY]->(a:Augmentation)
    WHERE md.name IN [{modality_params}]
    RETURN a.name AS augmentation_name, a.description AS augmentation_description
    """
    result = session.run(query)
    submetrics = []
    for record in result:
        submetrics.append({
            "name": record["augmentation_name"],
            "description": record["augmentation_description"]
        })
    print("Augmentations" , submetrics)
    return submetrics


# Fetch augmentations based on recommended modality
relevant_metrics = get_relevant_submetrics(recommended_metrics)

# # Show the augmentations fetched from the graph
# print("\n📚 Relevant Metrics from KG (via Cypher):")
# for i, aug in enumerate(relevant_metrics, 1):
#     print(f"\n--- Submetrics {i} ---")
#     print(f"Name: {aug['name']}")
#     print(f"Description: {aug['description']}")

# Step 3: Filter augmentations using embeddings + LLM
metrics_retriever = vector_index.as_retriever(search_kwargs={"k": 100})
metrics_docs = metrics_retriever.get_relevant_documents(user_summary)

# Prompt for Filtering Augmentations with LLM
METRICS_FILTER_PROMPT = """
Based on the user's summary and question-answer context, choose only the most relevant submetrics from the following list.

USER SUMMARY:
{user_summary}

QUESTION:
{question}
ANSWER:
{answer}

SUBMETRICS:
{submetrics}

Return the top relevant submetrics only, with brief reasons for selection.
"""

metrics_texts = "\n\n".join([f"- {doc.page_content}" for doc in metrics_docs])

metrics_filter_chain = LLMChain(
    llm=azure_openai,
    prompt=PromptTemplate(
        input_variables=["user_summary", "question", "answer", "submetrics"],
        template=METRICS_FILTER_PROMPT
    )
)

filtered_metrics = metrics_filter_chain.invoke({
    "user_summary": user_summary,
    "question": question,
    "answer": answer,
    "submetrics": metrics_texts
})

# Output Filtered Augmentations
print("\n📚 Filtered Relevant SubMetrics (via Hybrid Embedding + LLM):")
print(filtered_metrics["text"])

# Show Source Docs for Augmentations
print("\n📦 Source Nodes (Documents) Retrieved from KG for SubMetrics Filtering:")
for i, doc in enumerate(metrics_docs, 1):
    print(f"\n--- Source Document {i} ---")
    print(f"Content: {doc.page_content}")
    print(f"Metadata: {doc.metadata}")

# Close the session
session.close()
