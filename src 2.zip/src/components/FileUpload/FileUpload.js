import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import { styled } from "@mui/material/styles";
import excelFile from "../../assets/genaiIcons/excel_file_icon.png";
import txtFile from "../../assets/genaiIcons/txt.png";
import ClearIcon from "@mui/icons-material/Clear";
import deleteIcon from "../../assets/genaiIcons/delete.png";
import wordIcon from "../../assets/genaiIcons/word.png";
import excelIcon from "../../assets/genaiIcons/excel.png";
import csvIcon from "../../assets/genaiIcons/csv.png";
import pdfIcon from "../../assets/genaiIcons/pdf.png";
import completeIcon from "../../assets/genaiIcons/all_match.png";
import DescriptionIcon from "@mui/icons-material/Description";
import classes from "./FileUpload.module.css";
import { LinearProgress, Stack } from "@mui/material";
import { useState } from "react";

const VisuallyHiddenInput = styled("input")`
  clip: rect(0 0 0 0);
  clip-path: inset(50%);
  height: 1px;
  overflow: hidden;
  position: absolute;
  bottom: 0;
  left: 0;
  white-space: nowrap;
  width: 1px;
`;

const FileUpload = ({ acceptType = "/*", inProgress=false, ...props }) => {
  const [progress, setProgress] = useState(0);
  const handleProgress = (event) => {
    let currentProgress = event.loaded / event.total;
    // Update the progress bar here
    setProgress(currentProgress);
  };

  return (
    <>
      <div className={classes.fileInput}>
        <h5 className={classes.file}>
          To upload file
          <Button component="label" onChange={props.handleFileUpload}>
            Browse
            {props.multi && (
              <VisuallyHiddenInput
                type="file"
                onProgress={handleProgress}
                accept={acceptType}
                multiple
              />
            )}
            {!props.multi && (
              <VisuallyHiddenInput
                ref={props.fileInputRef}
                type="file"
                accept={acceptType}
              />
            )}
          </Button>
        </h5>
        <p className={classes.fileLimit}>Max upload file size 10mb</p>
      </div>
      { props.uploadedFiles.length > 0 && 
        <Stack maxHeight="15rem" style={{overflowY: "auto", border: "1px solid #BFBFBF", borderRadius: "1rem", margin: "0.5rem 0"}}>
          <div className={classes.uploadedFiles}>
            {props.uploadedFiles.map((file, index) => (
              <div className={classes.fileContainer}>
                <div key={index} className={classes.uploadedFile}>
                  <div className={classes.iconContainer}>
                    <img
                      alt="File Icon"
                      src={
                        file.name.endsWith(".xlsx")
                          ? excelIcon
                          : file.name.endsWith(".docx")
                          ? wordIcon
                          : file.name.endsWith(".csv")
                          ? csvIcon
                          : file.name.endsWith(".pdf")
                          ? pdfIcon
                          : txtFile
                      }
                    />
                  </div>
                  <div className={classes.fileDetails}>
                    {file.name}
                    <p>{(file.size / 1000).toFixed(2)}kb</p>
                  </div>
                  <div className={classes.fileAction}>
                    {true && (
                      <div className={classes.uploadComplete}>
                        <img src={completeIcon} alt="completed" />
                      </div>
                    )}
                    <IconButton
                      className={classes.removeFile}
                      onClick={() => props.removeFile(file)}
                    >
                      <img src={deleteIcon} alt="deleteIcon" />
                    </IconButton>
                  </div>
                </div>
                {/* <div className={classes.progressbar}>
                  <LinearProgress />
                  //<LinearProgress variant="determinate" value={progress} />
                </div> */}
              </div>
            ))}
          </div>
        </Stack>
      }
      {props.uploadedFiles.length===0 && <br/>}
      {/* {props.uploadedFiles && !props.multi && (
        <div className={classes.uploadedFiles}>
          <div className={classes.uploadedFile}>
            <div className={classes.iconContainer}>
              <img alt="File Icon" src={excelFile} />
            </div>
            <div className={classes.fileDetails}>
              {props.uploadedFiles.name}
              <br />
              {(props.uploadedFiles.size / 1000).toFixed(2)}kb
            </div>
            <IconButton
              className={classes.removeFile}
              onClick={() => props.removeFile(props.uploadedFile)}
            >
              <ClearIcon fontSize="small" />
            </IconButton>
          </div>
        </div>
      )} */}
      <div className={classes.btnContainer}>
        <Button
          variant="contained"
          color="primary"
          disabled={Array.from(props.uploadedFiles).length === 0 || inProgress}
          onClick={props.handleFileUploadSubmit}
        >
          Upload & Fetch Data
        </Button>
      </div>
    </>
  );
};

export default FileUpload;
