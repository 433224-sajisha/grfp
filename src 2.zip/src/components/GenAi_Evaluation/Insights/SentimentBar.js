import React, { useState } from "react";
import "./SentimentBar.css";

const SentimentBar = (props) => {
  const [activeSegment, setActiveSegment] = useState(null);

  const handleClick = (id) => {
    setActiveSegment(id);
  };

  return (
    <div className="sentiment-bar">
      <h2>
        {props.heading} : {props.totalPercentage.toFixed(2)} %
      </h2>
      <div className="bar">
        {props.segments.map((segment) => (
          <div
            key={segment.id}
            className="segment"
            style={{
              backgroundColor: segment.color,
              width: `${segment.percentage}%`,
            }}
            onClick={() => handleClick(segment.id)}
          >
            {segment.percentage.toFixed(2)}%
          </div>
        ))}
      </div>
      {activeSegment && (
        <p
          className="description"
          style={{
            color: props.segments.find(
              (segment) => segment.id === activeSegment
            )?.color,
          }}
        >
          {
            props.segments.find((segment) => segment.id === activeSegment)
              ?.label
          }
        </p>
      )}
    </div>
  );
};

export default SentimentBar;
