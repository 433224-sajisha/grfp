import React, { useContext, useState } from "react";
import {
  RadialBarChart,
  RadialBar,
  Legend,
  ResponsiveContainer,
  Cell,
  Tooltip,
} from "recharts";
import Select from "react-select";
import { Stack } from "@mui/material";
import { AuthContext } from "../../../globals/AuthContext";

const data = [
  { name: "Total Failed", value: 16793 },
  { name: "Total Passed", value: 95785 },
  // { name: "Total Executed", value: 112578 },
];

const colors = ["#f43f5e", "#14b8a6", "#4c51bf"];

const CustomTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const { name, value } = payload[0].payload;
    return (
      <div
        className="custom-tooltip-container"
        style={{
          position: "relative",
          backgroundColor: "white",
          padding: "6px",
          borderRadius: "5px",
          boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
        }}
      >
        <strong>{`${name}`}</strong>
        <p>{value}</p>
      </div>
    );
  }

  return null;
};

const customStyles = {
  control: (provided) => ({
    ...provided,
    width: 250,
  }),
};

const options = [
  { value: "Wealth Management Coach", label: "Wealth Management Coach" },
  { value: "Sr Design Ops Specialist", label: "Sr Design Ops Specialist" },
  { value: "Senior Specialist", label: "Senior Specialist" },
  {
    value: "Senior Analyst - Data Visualization - IN",
    label: "Senior Analyst - Data Visualization - IN",
  },
  { value: "Associate - Data Analytics", label: "Associate - Data Analytics" },
];

const RadialBarChartComponent = (props) => {
  const [selectedOptions, setSelectedOptions] = useState([options[0]]);

  const ctx = useContext(AuthContext);

  const radialData = props.data || data;

  const handleChange = (selected) => {
    setSelectedOptions(selected);
  };

  return (
    <>
      {ctx.projectName === "JD_QUESTIONNAIRE" && (
        <Stack direction="row" justifyContent="flex-end">
          <Select
            value={selectedOptions}
            // onChange={handleChange}
            options={options}
            onChange={handleChange}
            styles={customStyles}
            placeholder="Select JD"
          />
        </Stack>
      )}
      <ResponsiveContainer width="100%" height={300}>
        <RadialBarChart
          cx="70%"
          cy="50%"
          innerRadius="60%"
          outerRadius="90%"
          barSize={20}
          data={radialData}
          startAngle={90}
          endAngle={-180}
        >
          <RadialBar
            minAngle={15}
            background
            clockWise={false}
            dataKey="value"
            cornerRadius={10}
            // label={{
            //   position: 'insideStart',
            //   fill: '#fff',
            // }}
          >
            {radialData.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={colors[index % colors.length]}
              />
            ))}
          </RadialBar>
          <Legend
            iconSize={12}
            iconType="circle"
            layout="vertical" 
            verticalAlign="middle"
            align="left"
            width={"12rem"}
            wrapperStyle={{ marginLeft: 50 }}
            formatter={(value, entry) => (
              <span>
                {value}
                <strong style={{ color: "black", float: "right" }}>
                  {entry.payload.value}
                </strong>
              </span>
            )}
          />
          <Tooltip content={<CustomTooltip />} />
        </RadialBarChart>
      </ResponsiveContainer>
    </>
  );
};

export default RadialBarChartComponent;
