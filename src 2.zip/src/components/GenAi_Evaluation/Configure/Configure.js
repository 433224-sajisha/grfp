import {
  Button,
  CircularProgress,
  IconButton,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
} from "@mui/material";
import React, { useContext, useEffect, useState } from "react";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";
import BoltIcon from "@mui/icons-material/Bolt";
import EditIcon from "@mui/icons-material/Edit";
import styles from "./Configure.module.css";
import { Link, useNavigate } from "react-router-dom";
import {
  deleteConfiguration,
  getAllConfigurations,
} from "../../../_services/genai_evaluation.service";
import { AuthContext } from "../../../globals/AuthContext";
import { formatTimestamp } from "../../../_helpers/formatTime";
import Confirmation from "../../Confirmation/Confirmation";
import Switch from '@mui/material/Switch';

const Configure = () => {
  const [loading, setLoading] = useState(false);
  const [executionData, setExecutionData] = useState([]);
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(5);
  const [refresh, setRefresh] = useState(true);
  const [open, setOpen] = useState(false);
  const [selectedId, setSelectedId] = useState("");
  const [activationStatus, setActivationStatus] = useState(null);

  const handleChange = (event, index) => {
    setActivationStatus(prev => {
      const newStatus = [...prev];
      newStatus[index] = !newStatus[index];
      return newStatus;
    });
  };

  const ctx = useContext(AuthContext);
  const navigate = useNavigate();

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleDeleteConfiguration = (configId) => {
    deleteConfiguration(configId).then((result) => {
      setRefresh(true);
    });
  };

  const toggleConfirm = () => {
    setOpen((prev) => !prev);
  };

  useEffect(() => {
    if (refresh) {
      setLoading(true);
      getAllConfigurations(ctx.projectName).then((result) => {
        setLoading(false);
        setExecutionData(result.evaluationList);
        ctx.projectName === "Observability" && setActivationStatus(Array(result.evaluationList.length).fill(false))
      });
      setRefresh(false);
    }
  }, [refresh, ctx.projectName]);

  return (
    <div style={{ height: "calc(100vh - 75px)" }}>
      <Confirmation
        open={open}
        toggleConfirm={toggleConfirm}
        handleSubmit={() => {
          handleDeleteConfiguration(selectedId);
          toggleConfirm();
        }}
        message="Are you sure you want to delete this?"
      />
      <>
        <div className={styles.buttonContainer}>
          <Button variant="contained">
            <Link
              style={{ textDecoration: "none", color: "white" }}
              to="configuration"
            >
              Create Configuration
            </Link>
            <AddIcon />
          </Button>
        </div>
        <TableContainer component={Paper}>
          <Table aria-label="Material-UI Table">
            <TableHead
              sx={{
                background: "#7d96a8",
                whiteSpace: "nowrap",
                alignItems: "center",
              }}
            >
              <TableRow sx={{ alignItems: "center" }}>
                <TableCell
                  sx={{
                    color: "#fff",
                    textAlign: "center",
                    fontSize: "16px",
                    fontWeight: "600px",
                  }}
                >
                  S No.
                </TableCell>
                <TableCell
                  sx={{
                    color: "#fff",
                    textAlign: "center",
                    fontSize: "16px",
                    fontWeight: "600px",
                  }}
                >
                  Name
                </TableCell>
                <TableCell
                  sx={{
                    color: "#fff",
                    textAlign: "center",
                    fontSize: "16px",
                    fontWeight: "600px",
                  }}
                >
                  Description
                </TableCell>
                <TableCell
                  sx={{
                    color: "#fff",
                    textAlign: "center",
                    fontSize: "16px",
                    fontWeight: "600px",
                  }}
                >
                  Total Metrices
                </TableCell>
                <TableCell
                  sx={{
                    color: "#fff",
                    textAlign: "center",
                    fontSize: "16px",
                    fontWeight: "600px",
                  }}
                >
                  Created By
                </TableCell>
                <TableCell
                  sx={{
                    color: "#fff",
                    textAlign: "center",
                    fontSize: "16px",
                    fontWeight: "600px",
                  }}
                >
                  Last Modified By
                </TableCell>
                <TableCell
                  sx={{
                    color: "#fff",
                    textAlign: "center",
                    fontSize: "16px",
                    fontWeight: "600px",
                  }}
                >
                  Last Modified Date
                </TableCell>
                <TableCell
                  sx={{
                    color: "#fff",
                    textAlign: "center",
                    fontSize: "16px",
                    fontWeight: "600px",
                  }}
                >
                  Action
                </TableCell>
                {ctx.projectName === "Observability" &&
                  <TableCell
                    sx={{
                      color: "#fff",
                      textAlign: "center",
                      fontSize: "16px",
                      fontWeight: "600px",
                    }}
                  >
                    Activation Status
                  </TableCell>}
              </TableRow>
            </TableHead>
            {loading === true ? (
              <TableBody>
                <TableRow>
                  <TableCell colSpan={8}>
                    <Stack width="100%" direction="row" justifyContent="center">
                      <CircularProgress />
                    </Stack>
                  </TableCell>
                </TableRow>
              </TableBody>
            ) : executionData.length === 0 ? (
              <TableBody>
                <TableRow>
                  <TableCell colSpan={8}>
                    <Stack width="100%" direction="row" justifyContent="center">
                      No Data Available
                    </Stack>
                  </TableCell>
                </TableRow>
              </TableBody>
            ) : (
              <TableBody>
                {executionData
                  .slice(page * rowPage, page * rowPage + rowPage)
                  .map((row, index) => {
                    const uniqueRowNumber = page * rowPage + index + 1;
                    return (
                      <TableRow
                        key={index}
                        style={
                          index % 2
                            ? { background: "#F6F6F6" }
                            : { background: "white" }
                        }
                      >
                        <TableCell
                          sx={{
                            fontSize: "13px",
                            fontWeight: "400px",
                            color: "#464E5F",
                          }}
                        >
                          {uniqueRowNumber}
                        </TableCell>
                        <TableCell
                          sx={{
                            fontSize: "13px",
                            fontWeight: "400px",
                            color: "#464E5F",
                          }}
                        >
                          {row.name}
                        </TableCell>
                        <TableCell
                          sx={{
                            fontSize: "13px",
                            fontWeight: "400px",
                            color: "#464E5F",
                          }}
                        >
                          {row.desc}
                        </TableCell>
                        <TableCell
                          sx={{
                            fontSize: "13px",
                            fontWeight: "400px",
                            color: "#464E5F",
                          }}
                        >
                          {row.total_count}
                        </TableCell>
                        <TableCell
                          sx={{
                            fontSize: "13px",
                            fontWeight: "400px",
                            color: "#464E5F",
                          }}
                        >
                          {row.createdBy}
                        </TableCell>
                        <TableCell
                          sx={{
                            fontSize: "13px",
                            fontWeight: "400px",
                            color: "#464E5F",
                          }}
                        >
                          {row.createdBy}
                        </TableCell>
                        <TableCell
                          sx={{
                            fontSize: "13px",
                            fontWeight: "400px",
                            color: "#464E5F",
                          }}
                        >
                          {formatTimestamp(row.modifiedDate.toString())}
                        </TableCell>
                        <TableCell
                          sx={{
                            fontSize: "13px",
                            fontWeight: "400px",
                            color: "#464E5F",
                          }}
                        >
                          <Stack direction="row">
                            {ctx.projectName !== "Observability" && <IconButton
                              color="success"
                              size="small"
                              onClick={() =>
                                navigate("runConfiguration/" + row._id, {
                                  state: { configurationName: row.name, configId: row._id },
                                })
                              }
                            >
                              <BoltIcon fontSize="inherit" />
                            </IconButton>}
                            <IconButton color="primary" size="small" onClick={() => {
                              navigate("configuration/" + row._id)
                            }}>
                              <EditIcon fontSize="inherit" />
                            </IconButton>
                            <IconButton
                              onClick={() => {
                                setSelectedId(row._id)
                                toggleConfirm();
                              }}
                              color="error"
                              size="small"
                            >
                              <DeleteIcon fontSize="inherit" />
                            </IconButton>
                          </Stack>
                        </TableCell>
                        {ctx.projectName === "Observability" &&
                          <TableCell
                            sx={{
                              fontSize: "14px",
                              fontWeight: "400px",
                              color: "#464E5F",
                            }}
                          >
                            {activationStatus[index] === false ? "Deactivated" : "Activated"}
                            <Switch
                              checked={activationStatus[index]}
                              onChange={(e) => { handleChange(e, index) }}
                              inputProps={{ 'aria-label': 'controlled' }}
                            />
                          </TableCell>}
                      </TableRow>
                    );
                  })}
              </TableBody>
            )}
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={executionData.length}
          rowsPerPage={rowPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </>
    </div>
  );
};

export default Configure;
