import {
  CircularProgress,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
} from "@mui/material";
import React, { useState } from "react";

const CoverageResults = (props) => {
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(5);

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  return (
    <div>
      <TableContainer component={Paper}>
        <Table aria-label="Material-UI Table">
          <TableHead sx={{ background: "#111270", color: "#fff" }}>
            <TableRow sx={{ alignItems: "center", color: "#fff" }}>
              <TableCell
                sx={{
                  width: "2.5rem",
                  color: "#fff",
                  textAlign: "left",
                }}
              >
                <strong>S No.</strong>
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                <strong>String</strong>
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                <strong>Match</strong>
              </TableCell>
              <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                <strong>Topic Coverage</strong>
              </TableCell>
            </TableRow>
          </TableHead>
          {loading === true ? (
            <TableBody>
              <TableRow>
                <TableCell colSpan={4}>
                  <Stack width="100%" direction="row" justifyContent="center">
                    <CircularProgress />
                  </Stack>
                </TableCell>
              </TableRow>
            </TableBody>
          ) : Object.entries(props.evaluationData.evaluation)[props.indice][1]
              .overall.length === 0 ? (
            <TableBody>
              <TableRow>
                <TableCell colSpan={4}>
                  <Stack width="100%" direction="row" justifyContent="center">
                    No Data Availble
                  </Stack>
                </TableCell>
              </TableRow>
            </TableBody>
          ) : (
            <TableBody>
              {Object.entries(props.evaluationData.evaluation)
                [props.indice][1].overall.slice(
                  page * rowPage,
                  page * rowPage + rowPage
                )
                .map((row, index) => {
                  const uniqueRowNumber = page * rowPage + index + 1;
                  return (
                    <TableRow
                      key={index}
                      style={
                        index % 2
                          ? { background: "#F6F6F6" }
                          : { background: "white" }
                      }
                    >
                      <TableCell>{uniqueRowNumber}</TableCell>
                      {/* <TableCell>{row.description}</TableCell> */}
                      <TableCell>
                        {row.String} {/*<Link to={row.id}>{row.name}</Link>*/}
                      </TableCell>
                      <TableCell>{row.Matching_questions}</TableCell>
                      <TableCell>{row["Topic_coverage(%)"]}</TableCell>
                    </TableRow>
                  );
                })}
            </TableBody>
          )}
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={
          Object.entries(props.evaluationData.evaluation)[props.indice][1]
            .overall.length
        }
        rowsPerPage={rowPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </div>
  );
};

export default CoverageResults;
