import React, { Component, useEffect } from "react";
// import { Card, CardGroup, Col, Container, Form, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';
import { userService } from "../_services/user.service";
import bgimg from "../assets/img/ailaBG.png";
import btoa from "btoa";
import logoImg from "../assets/img/brand/CTS.png";
import DOMPurify from "dompurify";
import {
  Container,
  Paper,
  Card,
  Grid,
  Box,
  TextField,
  Button,
} from "@mui/material";
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
// import "./style.css";

const Login = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const [state, setState] = useState({
    username: "",
    password: "",
    submitted: false,
    loading: false,
    error: "",
    sessionError: "",
    keySize: 256,
    iterations: 100,
    _key: null,
    temp: null,
    passwordType: "password",
  });

  useEffect(() => {
    // userService.logout();
    if (localStorage.getItem("sessionExpire")) {
      setState((prevState) => ({
        ...prevState,
        sessionError: localStorage.getItem("sessionExpire"),
      }));
    }
  }, []);

  const gk = () => {
    const randomString="bFMeD57hA97tRDTSmrdO4VApgt9un5ng2AQwV57iuUm3X8BB3WIP3hRIn92NQCIU7WojIwmysnGWqHC3ZA4fp2QcJPNdVRhcMKkAbct".split("");
		for(var t="",n="",r=0;r<10;r++){
			var o=Math.floor(100*Math.random());
			t+=randomString[o];
			n+=("0"+o).slice(-2)
    }
		return[n,t];
  };

  const encode = (data) => {
    const CryptoJS1 = require('crypto-js');
    const CryptoJS = require('react-native-crypto-js');
  
    let authHeader = null;
    if (data.includes('null'))
      return '';
    let temp;
    if (state.temp == null) {
      temp = gk();
      setState(prevState => ({
        ...prevState,
        temp: temp
      }));
    }
    
    const salt = CryptoJS.lib.WordArray.random(128 / 8);
    if (state._key == null) {
      setState(prevState => ({
        ...prevState,
        _key: temp[1]
      }));
    }
    
    const key = CryptoJS1.PBKDF2(temp[1], salt, {
        keySize: state.keySize / 32,
        iterations: state.iterations
      });
    const iv = CryptoJS.lib.WordArray.random(128 / 8);
    const encrypted = CryptoJS.AES.encrypt(data, key, {
      iv: iv,
      padding: CryptoJS.pad.Pkcs7,
      mode: CryptoJS.mode.CBC
    });
    authHeader = btoa(salt.toString() + ":" + iv.toString() + ":" + encrypted.toString() + ":" +
      temp[0]);
    return authHeader;
  };
  

  // const encode = (data) => {
  //   var CryptoJS1 = require('crypto-js');
	// 	var CryptoJS = require('react-native-crypto-js');
		
	// 	let authHeader = null;
	// 	if (data.includes('null'))
	// 		return '';
	// 	if (state.temp == null)
	// 		state.temp = gk();
		
	// 	const salt = CryptoJS.lib.WordArray.random(128 / 8);
	// 	if (state._key == null) {
	// 		state._key = state.temp[1];
	// 	}		

	// 	const key = CryptoJS1.PBKDF2(state._key, salt, {
	// 		keySize: state.keySize / 32,
	// 		iterations: state.iterations
	// 	});
    
	// 	const iv = CryptoJS.lib.WordArray.random(128 / 8);
	// 	const encrypted = CryptoJS.AES.encrypt(data, key, {
	// 		iv: iv,
	// 		padding: CryptoJS.pad.Pkcs7,
	// 		mode: CryptoJS.mode.CBC
	// 	});

	// 	authHeader = btoa(salt.toString() + ":" + iv.toString() + ":" + encrypted.toString() + ":" +
	// 			state.temp[0]);
	// 	return authHeader
  // };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = () => {
    // e.preventDefault();
    setState((prevState) => ({
      ...prevState,
      submitted: true,
      loading: true,
    }));
    const { username, password } = state;
    if (!(username && password)) {
      return;
    }
    const authToken = encode(`${username}:${password}`);
    // userService.login(authToken).then(
    //   (user) => {
    //     const sanitizedUserName = DOMPurify.sanitize(
    //       localStorage.getItem("username")
    //     );
    //     if (sanitizedUserName === username) {
    //       const { from } = location.state || {
    //         from: {
    //           pathname: process.env.REACT_APP_CONTEXT_ROOT + "/dashboard",
    //         },
    //       };
    //       navigate(from);
    //     } else {
    //       setState((prevState) => ({
    //         ...prevState,
    //         loading: false,
    //         sessionError: "Error in the response.",
    //       }));
    //     }
    //   },
    //   (error) =>
    //     setState((prevState) => ({
    //       ...prevState,
    //       error,
    //       loading: false,
    //       sessionError: "",
    //     }))
    // );
  };

  const onHandlePassword = () => {
    setState((prevState) => ({
      ...prevState,
      passwordType: prevState.passwordType === "password" ? "text" : "password",
    }));
  };

  const { username, password, loading, error, sessionError, passwordType } =
    state;

  return (
    <div
      style={{
        backgroundImage: `url(${bgimg})`,
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
        height: "102.5vh",
        margin: "0",
      }}
    >
      <Grid container spacing={2}>
        <Grid item xs={8} style={{ marginLeft: "2rem" }}>
          <div xs={12}>
            <img src={logoImg} style={{ width: "180px", height: "40px" }} />
          </div>
          <div xs={12}>
            <p
              style={{
                fontWeight: "Regular",
                marginLeft: "1rem",
                marginTop: "0",
                fontSize: "20px",
                color: "white",
              }}
            >
              Artificial Intelligence Lifecycle Assurance
            </p>
          </div>
        </Grid>
        <Grid item xs={4}></Grid>
      </Grid>

      <Grid container spacing={2}>
        <Grid item xs={8}></Grid>
        <Grid item xs={4} style={{ padding: "2rem", position: "relative" }}>
          <Box
            style={{
              margin: "0",
              backgroundColor: "#0800FF",
              borderRadius: "20px",
              width: "calc(100% - 6rem)",
              height: "22rem",
              opacity: "28%",
              textAlign: "center",
              zIndex: 0,
              position: "absolute",
              top: "2rem",
              left: "2rem",
            }}
          ></Box>

          <Box
            style={{
              width: "calc(100% - 6rem)",
              zIndex: 1,
              position: "absolute",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
            }}
          >
            <h3 style={{ color: "white", opacity: "1", textAlign: "center" }}>
              AILA - QA FOR AI
            </h3>

            <Box
              sx={{
                width: "70%",
                maxWidth: "100%",
                display: "flex",
                alignItems: "flex-end",
                opacity: "1",
                textAlign: "center",
                marginTop: "1rem",
              }}
            >
              <AccountCircleIcon sx={{ mr: 1, my: 0.5 }}/>
              <TextField
                fullWidth
                id="input-with-sx"
                label="Username"
                variant="standard"
                value={username}
                name="username"
                onChange={handleChange}
              />
            </Box>

            <Box
              sx={{
                width: "70%",
                maxWidth: "100%",
                display: "flex",
                alignItems: "flex-end",
                marginTop: "1rem",  
              }}
            >
              <AccountCircleIcon sx={{ mr: 1, my: 0.5 }} />
              <TextField
                fullWidth
                id="standard-password-input"
                label="Password"
                type="password"
                autoComplete="current-password"
                variant="standard"
                name="password"
                onChange={handleChange}
              />
            </Box>

            <Box
              sx={{
                width: "70%",
                maxWidth: "100%",
                marginTop: "5rem",
              }}
            >
              <Button
                variant="contained"
                color="success"
                disabled={loading}
                onClick={handleSubmit}
                fullWidth
              >
                Login
              </Button>

              {loading && (
                <img
                  src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA=="
                  alt="Loading"
                />
              )}
              {error && <div className={"alert alert-danger"}>{error}</div>}
              {sessionError && (
                <div
                  style={{ width: "280px", textAlign: "left" }}
                  className={"alert alert-danger"}
                >
                  {sessionError}
                </div>
              )}
            </Box>
          </Box>

          <Box
            style={{
              width: "calc(100% - 6rem)",
              zIndex: 0,
              position: "absolute",
              top: "24em",
              left: "2rem",
            }}
          >
            <p
              style={{
                fontWeight: "Regular",
                fontSize: "12px",
                color: "white",
              }}
            >
              © 2023 Cognizant. All rights reserved. Click here for &nbsp;
              <a
                href="https://www.cognizant.com/us/en/privacy-notice"
                target="_blank"
                style={{ color: "#fff" }}
              >
                Cognizant’s Privacy Statement
              </a>
            </p>
          </Box>
        </Grid>
      </Grid>
    </div>
  );
};

// class Login extends Component {

//   constructor(props) {
//     super(props);

//     userService.logout();

//     this.state = {
//         username: '',
//         password: '',
//         submitted: false,
//         loading: false,
//         error: '',
//         sessionError: '',
//         keySize:256,
// 				iterations:100,
// 				_key:null,
// 				temp:null,
//         passwordType:'password',
//     };

//     this.handleChange = this.handleChange.bind(this);
//     this.handleSubmit = this.handleSubmit.bind(this);
//     this.onHandlePassword=this.onHandlePassword.bind(this);
//     //this.encode = this.encode.bind(this);
//     //this.gk = this.gk.bind(this);
//   }

//   componentDidMount() {
//     // this.props.onresetTimeout();
//     if(localStorage.getItem('sessionExpire')){
//       this.setState({
//         sessionError: localStorage.getItem('sessionExpire')
//       })
//     }
//   }

//   gk(){
// 		const randomString="bFMeD57hA97tRDTSmrdO4VApgt9un5ng2AQwV57iuUm3X8BB3WIP3hRIn92NQCIU7WojIwmysnGWqHC3ZA4fp2QcJPNdVRhcMKkAbct".split("");
// 		for(var t="",n="",r=0;r<10;r++){
// 			var o=Math.floor(100*Math.random());
// 			t+=randomString[o];
// 			n+=("0"+o).slice(-2)
// 		}
// 		return[n,t];
//   }

//   encode(data) {
//     var CryptoJS1 = require('crypto-js');
// 		var CryptoJS = require('react-native-crypto-js');

// 		let authHeader = null;
// 		if (data.includes('null'))
// 			return '';
// 		if (this.state.temp == null)
// 			this.state.temp = this.gk();

// 		const salt = CryptoJS.lib.WordArray.random(128 / 8);
// 		if (this.state._key == null) {
// 			this.state._key = this.state.temp[1];
// 		}

// 		const key = CryptoJS1.PBKDF2(this.state._key, salt, {
// 			keySize: this.state.keySize / 32,
// 			iterations: this.state.iterations
// 		});

// 		const iv = CryptoJS.lib.WordArray.random(128 / 8);
// 		const encrypted = CryptoJS.AES.encrypt(data, key, {
// 			iv: iv,
// 			padding: CryptoJS.pad.Pkcs7,
// 			mode: CryptoJS.mode.CBC
// 		});

// 		authHeader = btoa(salt.toString() + ":" + iv.toString() + ":" + encrypted.toString() + ":" +
// 				this.state.temp[0]);
// 		return authHeader
//   }

//   handleChange(e) {
//     const { name, value } = e.target;
//     this.setState({ [name]: value });
//   }

//   handleSubmit(e) {
//     e.preventDefault();

//     this.setState({ submitted: true });
//     const { username, password, returnUrl } = this.state;
//     // let authToken = base64.encode(this.state.username + ":" + this.state.password);
//     // stop here if form is invalid
//     if (!(username && password)) {
//         return;
//     }

//     let authToken = this.encode(username+":"+password);
//     this.setState({ loading: true });
//     userService.login(authToken)
//       .then(
//           user => {
//             const sanitizedUserName=DOMPurify.sanitize(localStorage.getItem('username'))
//             if(sanitizedUserName === username){
//               // this.props.onresetTimeout();
//               const { from } = this.props.location.state || { from: { pathname: process.env.REACT_APP_CONTEXT_ROOT+"/dashboard" } };
//               this.props.history.push(from);
//               // licenseService.checkInstanceValidity();
//             } else {
//               this.setState({ loading: false, sessionError: 'Error in the response.' })
//             }
//           },
//           error => this.setState({ error, loading: false, sessionError: '' })
//       );
//   }

//   onHandlePassword(){
//     if(this.state.passwordType=='password'){
//       this.setState({
//         passwordType:'text',
//       })
//     }else{
//       this.setState({
//         passwordType:'password',
//       })
//     }
//   }

//   render() {
//     const { username, password, submitted, loading, error, sessionError } = this.state;

//     return (
//       <div className="app flex" style={{ backgroundImage: `url(${bgimg})`,backgroundRepeat: 'round',
//       backgroundSize: 'contain',
//       height: 720,
//       }}>
//         <Container style={{marginTop:"20px",marginLeft: "20px"}}>
//         <Row>
//               <Col xs={12}>
//                 <img src={logoImg} style={{ width: "180px", height: "40px" }} />
//               </Col>
//               <Col xs={12}>
//                 <p style={{ fontWeight: "Regular", marginLeft: '30px', fontSize: "20px", color: "white" }}>Artificial Intelligence Lifecycle Assurance</p>
//               </Col>
//           </Row>
//         </Container>
//         <Container style={{marginTop:"50px"}}>
//           <Row>
//             <Col xl={4}>
//             </Col>
//             <Col xl={4}>
//             </Col>

//             <Col xl={4}>
//               <CardGroup >
//                 <Card style={{backgroundColor: "#0800FF",borderRadius: "20px", top:"10px",height:"400px",opacity:"28%",marginLeft:"60px",marginRight:"-290px"}}>
//                 </Card>
//                 <Form name="form" onSubmit={this.handleSubmit}>
//                       <div style={{textAlign: "center"}}>
//                         <p style={{fontSize: "30px", color: "white", position: "relative", display: "inline-block", lineHeight: "5", top: "15px"}}>AILA <span style={{fontSize:"15px"}}> - QA FOR AI</span></p>

//                       {/*
//                         <p className="text-muted">Sign In to your account</p>
//                       */
//                       }

//                       <Box sx={{ display: 'flex', alignItems: 'flex-end' }}>
//                         <AccountCircle sx={{ color: 'action.active', mr: 1, my: 0.5 }} />
//                         <TextField id="input-with-sx" label="With sx" variant="standard" />
//                       </Box>
//                       {/* <InputGroup className="mb-3">
//                         <InputGroupAddon addonType="prepend">
//                           <InputGroupText style={{background:"none",border:"none",borderBottom:"2px solid white"}}>
//                             <i className="icon-user"></i>
//                           </InputGroupText>
//                         </InputGroupAddon>
//                         <input type="text" style={{color: "white",border:"none",borderBottom:"2px solid white",background:"none",width:"200px",outline:"none"}} placeholder="Username" autoComplete="username" name="username" value={username} onChange={this.handleChange} />
//                       </InputGroup> */}
//                       {/* <InputGroup className="mb-4">
//                         <InputGroupAddon addonType="prepend">
//                           <InputGroupText style={{background:"none",border:"none",borderBottom:"2px solid white"}}>
//                             <i className="icon-lock"></i>
//                           </InputGroupText>
//                         </InputGroupAddon>
//                         <input type={this.state.passwordType} style={{color: "white",border:"none",borderBottom:"2px solid white",background:"none",width:"200px",outline:"none"}} placeholder="Password" autoComplete="current-password" name="password" value={password} onChange={this.handleChange}/>
//                         <i className={`${this.state.passwordType=="password" ? "fa fa-eye" : "fa fa-eye-slash" }`} onClick={this.onHandlePassword}></i>
//                       </InputGroup> */}
//                       <Row>
//                         <Col style={{textAlign: "center",top:"20px"}}>
//                           <button class="login-button" style={{backgroundColor:"#1D72F1", border:"1px solid #707070", borderRadius: "20px",width:"200px",color:"#00FFF7",height:"50px"}} disabled={loading} >LOGIN</button>
//                         </Col>
//                         {
//                           /*
//                             <Col xs="6" className="text-right">
//                               <Button color="link" className="px-0">Forgot password?</Button>
//                             </Col>
//                           */
//                         }

//                         {loading &&
//                             <img src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
//                         }
//                       </Row>
//                       <br/>
//                       <br/>
//                       { error &&
//                         <div className={'alert alert-danger'}>{error}</div>
//                       }
//                       { sessionError &&
//                         <div style={{width:"280px",textAlign:"left"}} className={'alert alert-danger'}>{sessionError}</div>
//                       }
//                       </div>
//                     </Form>
//                 {
//                   /*
//                     <Card className="text-white bg-primary py-5 d-md-down-none" style={{ width: '44%' }}>
//                       <CardBody className="text-center">
//                         <div>
//                           <h2>Sign up</h2>
//                           <Link to="/register">
//                             <Button color="primary" className="mt-3" active tabIndex={-1}>Register Now!</Button>
//                           </Link>
//                         </div>
//                       </CardBody>
//                     </Card>
//                   */
//                 }

//               </CardGroup>
//               <Row>
//               <p style={{fontWeight:"Regular",fontSize: "10px", color: "white",padding:"20px",float:"left",marginLeft:"60px"}}>© 2023 Cognizant. All rights reserved. Click here for &nbsp;
//                   <a href="https://www.cognizant.com/us/en/privacy-notice" target="_blank" style={{color:"#fff"}}>
//                     Cognizant’s Privacy Statement</a></p>
//               </Row>
//             </Col>
//           </Row>
//         </Container>
//         {/* <Container>
//           <Row style={{marginTop:"75px"}}>
//             <Col xs={7}>
//             <p style={{fontWeight:"Regular", fontSize: "30px", color: "white"}}>Artificial Intelligence Lifecycle Assurance</p>
//             </Col>
//             <Col>
//             <p style={{fontWeight:"Regular",fontSize: "10px", color: "white",padding:"20px",float:"right"}}>© 2023 Cognizant. All rights reserved. Click here for &nbsp;
//                   <a href="https://www.cognizant.com/us/en/privacy-notice" target="_blank" style={{color:"#fff"}}>
//                     Cognizant’s Privacy Statement</a></p>
//             </Col>
//             </Row>
//         </Container> */}
//       </div>
//     );
//   }
// }

export default Login;

// © [2023] Cognizant. All rights reserved.  Cognizant Confidential and/or Trade Secret.
// NOTICE: This unpublished material is proprietary to Cognizant and its suppliers,
// if any. The methods, techniques and technical concepts herein are considered Cognizant confidential
// and/or trade secret information. This material may be covered by U.S. and/or foreign patents or patent
// applications. Use, distribution or copying, in whole or in part, is forbidden,
// except by express written permission of Cognizant.
