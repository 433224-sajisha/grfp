import React, { Component } from 'react';
import { Button, Card, CardBody, CardFooter, CardHeader, Col, FormGroup,Input, Label, Row, FormText} from 'reactstrap';
import Select from 'react-select';
import { Link } from 'react-router-dom';
import { userService, projectService, validationService} from '../../_services';
import DOMPurify from 'dompurify';
import { CircularProgress } from '@mui/material';
class CreateProject extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showModelCatog: false,
      project: {},
      projectName: '',
      projectDesc: '',
      modelCategory: '',
      modelCategorySubType: 'Rasa',
      metaDataList: [{
        name: "",
        description: "",
        dataType : "",
        type: "", 
        Numeric_Values_Count: 0,
        Catagorical_Values_Count: 0,
        Free_Text_Count: 0,
        Numeric_list: [], 
        Categorical_Columns: [], 
        Text_Colums: [],
        classLabel: "",
        labelName: "",
      }],
      userRoleList: [],
      dataTypes : [
        { label: "Numeric", value: "Numeric" },
        { label: "Categorical", value: "Categorical" },
        { label: "Free-text", value: "Free-text" },
      ],
      users: [{}],
      originalUsers: [],
      submitted: false,
      loading: false,
      error: '',
      action: '',
      gcpDataFile: [],
      fileUploaded: false,
      saveClick: false,
      azureSubscriptionKey: '',
      azureRegion: '',
      successMessage: '',
      languageTranslationKey:'',
      languageTranslationEndpoint:'',
      languageTranslationRegion:'',
      usrError: '',
      assignedUserRole: '',
      userTypeProject:'devProject',
      awsAccessKey:'',
      awsSecretKey:'',
      awsRegion:''
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.updateProject = this.updateProject.bind(this);
    this.handleMetaDataChange = this.handleMetaDataChange.bind(this);
    this.handleRemoveRow = this.handleRemoveRow.bind(this);
    this.handleAddRow = this.handleAddRow.bind(this);
    this.handleRemoveSpecificRow = this.handleRemoveSpecificRow.bind(this);

    this.dataTypeDropdownchange = this.dataTypeDropdownchange.bind(this);
    this.variableTypeDropdownchange = this.variableTypeDropdownchange.bind(this); 
    this.userDropdownchange = this.userDropdownchange.bind(this); 
    this.modelCategoryDropdownchange = this.modelCategoryDropdownchange.bind(this); 
    this.checkBoxSelected = this.checkBoxSelected.bind(this);
    this.handleErrorClose = this.handleErrorClose.bind(this);
    this.fileUpload = this.fileUpload.bind(this);
    this.setUserProjectType=this.setUserProjectType.bind(this);
  }

  componentDidMount() {
    this.setState({loading: true});
    const action = this.props.match.params.action;
    const projectName = this.props.match.params.id;
    this.setState({ action: action});
    const sanitizedUserName=DOMPurify.sanitize(localStorage.getItem('username'))
    userService.getUserDetails(sanitizedUserName).then(data => {
      this.setState({
        selectedUserPrivilege: data.selectedRolePrivilege,
        assignedUserRole: data.userRolesList[projectName],
      })
    if(action === 'create') {
      if(this.state.selectedUserPrivilege == 'superAdmin'){
        this.setUserProjectType({'target':{'value':"devProject"}});
      this.setState({
        loading: false,
        modelCategory: 'Conversational AI'
      }) 
      } else{
        this.setState({
          userError: 'You do not have permission to access this tab.',
          loading: false,
        })
      }
    } else {
        if(this.state.assignedUserRole == 'projectOwner' || this.state.assignedUserRole == 'superAdmin')
        {
          projectService.getProjectDetails(this.props.match.params.id).then( data => {
            this.setState({
              project: data,
              projectName: data.projectName,
              projectDesc: data.projectDesc,
              modelCategory: data.modelCategory,
              metaDataList: data.metaDataList,
              userTypeProject:data.userTypeProject!=null?data.userTypeProject:this.state.userTypeProject
            })
            this.setUserProjectType({'target':{'value':this.state.userTypeProject}});
            if(this.state.modelCategory === 'Recommendation') {
              let types = [
                { label: "Index", value: "Index" },
                { label: "Rating", value: "Rating" }
              ]
              this.setState({
                dataTypes: types
              })
            }
            if(this.state.modelCategory==='Conversational AI'){
              let checkLambda = false;
              if (data.modelCategorySubType === "AWSLambdaClient"){
                checkLambda = true;
              }
              this.setState({
                showModelCatog: checkLambda,
                modelCategorySubType:data.modelCategorySubType,
                azureSubscriptionKey: data.azureSubscriptionKey,
                azureRegion: data.azureRegion,
                gcpDataFile:data.gcpDataFile,
                languageTranslationEndpoint:data.languageTranslationEndpoint,
                languageTranslationKey:data.languageTranslationKey,
                languageTranslationRegion:data.languageTranslationRegion,
                awsAccessKey:data.awsAccessKey!=null?data.awsAccessKey:this.state.awsAccessKey,
                awsSecretKey:data.awsSecretKey!=null?data.awsSecretKey:this.state.awsSecretKey,
                awsRegion:data.awsRegion!=null?data.awsRegion:this.state.awsRegion
              })
            }
            else{
              this.setState({
                showModelCatog: true
              })
            }
            
            if(this.state.metaDataList === null || this.state.metaDataList === undefined || this.state.metaDataList.length === 0 ){
              this.setState({
                metaDataList: [{
                  name: "",
                  description: "",
                  dataType : "",
                  type: ""
                }]
              })
            }
            this.setState({
              loading: false
            })
          });
      }
      else {
        this.setState({
          userError: 'You do not have permission to access this tab.',
          loading: false,
        })
      }
    } 
  })
  }

  handleChange(e) {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  }

  handleSubmit() {
    let userRoleList =[];  
    // let projectUserRoleList = [];  
      this.state.userRoleList.map((user, index) => {        
        if (user.username !== '') {
          let userTemp = {};
          if((user.selectedRolePrivilege == 'executionRole' || user.selectedRolePrivilege == 'projectUser' ) && user.isAdmin == true){
             userTemp = {
              username: user.username,
              roles: ['projectOwner']
            }
          } else if((user.selectedRolePrivilege == 'executionRole' || user.selectedRolePrivilege == 'projectUser' ) && user.isAdmin == false){
            userTemp = {
              username: user.username,
              roles: ['projectUser']
            }
          } else if(user.selectedRolePrivilege == 'readOnlyRole'){
            userTemp = {
              username: user.username,
              roles: ['readOnlyRole']
            }
          }
          userRoleList.push(userTemp)
        }
      })
       let adminTemp = {
        username: 'admin',
        roles: ['superAdmin']
      }
      userRoleList.push(adminTemp)

    let updateMetadData = [];
    let free_text_attribute = false;
    let non_free_text_attribute = false;
    this.state.metaDataList.map((entry) => {
      if (entry.name && entry.description && entry.dataType && entry.type) {
        updateMetadData.push(entry);
      }
      if(entry['dataType'] === 'Free-text' && entry['type'] === 'Input Feature') {
        free_text_attribute = true;
      } else if (entry['dataType'] !== 'Free-text' && entry['type'] === 'Input Feature') {
        non_free_text_attribute = true;
      }
    })    
    
    /*
    if(free_text_attribute && non_free_text_attribute) {
      this.setState({
        error: 'Project Meta Data cannot have Free-text attribute along with other input attributes.', 
        loading: false
      })
      return Promise.reject(this.state.error);
    }*/

    const {projectDesc, metaDataList, modelCategory, modelCategorySubType, azureSubscriptionKey, azureRegion, gcpDataFile,
      languageTranslationKey, languageTranslationEndpoint, languageTranslationRegion,userTypeProject,awsAccessKey,awsRegion,awsSecretKey} = this.state;
    let {projectName} = this.state;
    projectName = projectName.trim();
    let projectObj;
    this.setState({ submitted: true });
    this.setState({ loading: true });
    
    if(this.state.action === 'edit') {
      this.updateProject(userRoleList);
      return;
    } else {
      if(modelCategory==="Generative AI"){
        projectObj = JSON.stringify({projectName, projectDesc, userRoleList, modelCategory,userTypeProject});
      }else{
        if(modelCategory !== 'Conversational AI') {
          projectObj = JSON.stringify({projectName, projectDesc, metaDataList, userRoleList, modelCategory,userTypeProject});
        } else {
          if (modelCategorySubType === 'AWSLambdaClient'){
            projectObj = JSON.stringify({projectName, projectDesc, userRoleList,metaDataList, modelCategory, modelCategorySubType, languageTranslationKey, languageTranslationEndpoint, languageTranslationRegion,userTypeProject});
          } else {
            projectObj = JSON.stringify({projectName, projectDesc, userRoleList, modelCategory, modelCategorySubType, azureSubscriptionKey, azureRegion, gcpDataFile, languageTranslationKey, languageTranslationEndpoint, languageTranslationRegion,userTypeProject,awsAccessKey,awsSecretKey,awsRegion});
          }
        }
      }

      if (validationService.forNames(projectName) ){
        this.setState({
           error: 'Project ' + validationService.forNames(projectName), 
        loading: false })
        return Promise.reject(this.state.error);
      }
    }
    if (this.state.metaDataList === null || this.state.metaDataList === undefined ){
      this.setState({error: 'metadatalist is empty, so it appears null.' ,loading: false})
      return Promise.reject(this.state.error);
    }
    
    if (this.state.metaDataList !== null)
    { 
        projectService.createProject(projectObj)
        .then(
          response => {
            if(this.state.fileUploaded == true){ 
              projectService.gcpDataFilePath(response.projectName, this.state.gcpDataFile).then(
                response => {
                  const { from } = { from: { pathname: "/settings/projects" } };
                  this.props.history.push(from);
                  window.location.reload(true);
                },
                error=>{
                  this.setState({
                    error: 'Error while adding gcpfile: ' + error,
                    loading: false,
                  })
                }
              )
            }
            else {
              const { from } = { from: { pathname: "/settings/projects" } };
              this.props.history.push(from);
              window.location.reload(true);
            }
          },
          error => {
            this.setState({ 
              error, loading: false 
            })
          }
        );  
    }
  }

  updateProject(userRoleList) {
    this.state.project.projectName = this.state.projectName;
    this.state.project.projectDesc = this.state.projectDesc;
    this.state.project.modelCategory = this.state.modelCategory;
    this.state.project.azureSubscriptionKey = this.state.azureSubscriptionKey;
    this.state.project.azureRegion = this.state.azureRegion;
    this.state.project.languageTranslationKey = this.state.languageTranslationKey;
    this.state.project.languageTranslationEndpoint = this.state.languageTranslationEndpoint;
    this.state.project.languageTranslationRegion = this.state.languageTranslationRegion;
    this.state.project.userTypeProject=this.state.userTypeProject;
    this.state.project.awsAccessKey = this.state.awsAccessKey;
    this.state.project.awsSecretKey = this.state.awsSecretKey;
    this.state.project.awsRegion = this.state.awsRegion;
    
    if(this.state.project.modelCategory !== 'Conversational AI' && this.state.modelCategory!="Generative AI") {
      this.state.project.metaDataList = this.state.metaDataList;
    } else {
      if (this.state.project.modelCategorySubType === "AWSLambdaClient"){
        this.state.project.metaDataList = this.state.metaDataList;
      }
      // this.state.project.metaDataList = null;
      this.state.project.modelCategorySubType = this.state.modelCategorySubType;
    }
    this.state.project.userRoleList = userRoleList;
    this.state.project = JSON.stringify(this.state.project);
    
    projectService.updateProject(this.state.project)
    .then(
        response => {
          if(this.state.fileUploaded == true){ 
            projectService.gcpDataFilePath(this.state.projectName, this.state.gcpDataFile).then(
              response => {
                const { from } = { from: { pathname: "/settings/projects" } };
                this.props.history.push(from);
                window.location.reload(true);
              },
              error=>{
                this.setState({
                  error: 'Error while adding gcpfile: ' + error,
                  loading: false,
                })
              }
            )
          }
          else{
            const { from } = { from: { pathname: "/settings/projects" } };
            this.props.history.push(from);
            window.location.reload(true);
          } 
        },
        error => {
          this.setState({ 
            error, loading: false 
          })
        }
    );
      
  }

  handleMetaDataChange = idx => e => {
    const { name, value } = e.target;
    const metaDataList = [...this.state.metaDataList];
    metaDataList[idx][name] = value;

    this.setState({
      metaDataList
    });
  };

  dataTypeDropdownchange = idx => e => {
    const metaDataList = [...this.state.metaDataList];
    metaDataList[idx]['dataType'] = e.value;
    this.setState({
      metaDataList
    });
  }

  variableTypeDropdownchange = idx => e => {
    const metaDataList = [...this.state.metaDataList];
    metaDataList[idx]['type'] = e.value;
    this.setState({
     metaDataList
    });
  }

  userDropdownchange = idx => e => {
    const userRoleList = [...this.state.userRoleList];
    userRoleList[idx]['username'] = e.value;
    userRoleList[idx]['selectedRolePrivilege'] = e.selectedRolePrivilege;
    let userObj=this.state.users.filter(o => o.value === e.value)
    if(this.state.userTypeProject=="devProject" && userObj[0].userType=="qaUser" && userObj[0].selectedRolePrivilege=="executionRole"){
      userRoleList[idx]['qaProjectUser'] = true;
    }else{
      userRoleList[idx]['qaProjectUser'] = false;
    }
    this.setState({
      userRoleList
    });
  }

  modelCategorySubTypeDropdownchange = e => {
    let checkLambda = false;
    if (e.value === "AWSLambdaClient"){
      checkLambda  = true;
    }
    this.setState({
      modelCategorySubType:e.value,
      showModelCatog: checkLambda
    });
  }

  fileUpload = (e) => {
    e.preventDefault();
    let file = e.target.files[0];
    if (this.state.modelCategory === 'Conversational AI') {
        this.setState({
          gcpDataFile: file,
          fileUploaded: true,
          error: ''
        }) 
    }
  }

  modelCategoryDropdownchange = e => {
    const metaDataList = [{
      name: "",
      description: "",
      dataType : "",
      type: "", 
      Numeric_Values_Count: 0,
      Catagorical_Values_Count: 0,
      Free_Text_Count: 0,
      Numeric_list: [], 
      Categorical_Columns: [], 
      Text_Colums: []
    }]

    if(e.value === 'Recommendation') {
      let types = [
        { label: "Index", value: "Index" },
        { label: "Rating", value: "Rating" }
      ]

      this.setState({
        dataTypes: types,
        metaDataList: metaDataList
      });

    } else if (e.value !== 'Recommendation' && this.state.modelCategory === 'Recommendation') {
      let types = [
        { label: "Numeric", value: "Numeric" },
        { label: "Categorical", value: "Categorical" },
        { label: "Free-text", value: "Free-text" },
      ]
      
      this.setState({
        dataTypes: types,
        metaDataList: metaDataList
      });
    }
    
    if (e.value === 'Conversational AI') {
      this.setState({
        showModelCatog : false,
        showSubTypeList: true
      });
    } else {
      this.setState({
        showModelCatog : true,
        showSubTypeList: false
      });
    }

    this.setState({
      modelCategory: e.value,
    });
  }

  checkBoxSelected = idx => e => {
    const userRoleList = [...this.state.userRoleList];
    userRoleList[idx][e.target.name] = e.target.checked;
    this.setState({
      userRoleList
    });
  }

  handleAddRow = (section) => {
    if(section === 'metaData'){
      const item = {
        name: "",
        description: "",
        dataType : "",
        type: ""
      };
      this.setState({
        metaDataList: [...this.state.metaDataList, item]
      });
    } else {
      const item = {
        username: "",
        isAdmin: false,
        selectedRolePrivilege: '',
        qaProjectUser:false
      };
      this.setState({
        userRoleList: [...this.state.userRoleList, item]
      });
    }
    
  };

  handleRemoveRow = (section) => {
    if(section === 'metaData'){
      this.setState({
        metaDataList: this.state.metaDataList.slice(0, -1)
      });
    } else {
      this.setState({
        userRoleList: this.state.userRoleList.slice(0, -1)
      });
    }
  };

  handleRemoveSpecificRow = (idx, section) => () => {
    if(section === 'metaData'){
      const metaDataList = [...this.state.metaDataList]
      metaDataList.splice(idx, 1)
      this.setState({ metaDataList })
    } else {
      const userRoleList = [...this.state.userRoleList]
      userRoleList.splice(idx, 1)
      this.setState({ userRoleList })
    }
  }

  handleErrorClose() {
    this.setState({ error : '' });
  }

  setUserProjectType(e){
    const userType=e.target.value;
    this.setState({
      userTypeProject: userType,
      userRoleList: []
    });
    const projectName=this.props.match.params.id;
    let usertemp = [];
    let userRole = [];
    userService.getAllUsers().then(data => { 
      this.setState({originalUsers: data})
      this.state.originalUsers.map((user, index) => {
        if(user.username != 'admin'){
          if(!(userType=="qaProject" && user.executeUserRole=="devUser")){
              usertemp.push({ 
                'label': user.firstName + " "+ user.lastName, 
                'value': user.username,
                'selectedRolePrivilege': user.selectedRolePrivilege,
                'userType':user.selectedRolePrivilege!="readOnlyRole" ? (user.executeUserRole!=null && user.executeUserRole=="qaUser"? "qaUser":"devUser" ): "readUser"
              })
            }
        }
        if (user.userRolesList[projectName]) {
          let temp = {
            username: user.username,
            isAdmin: false,  
            selectedRolePrivilege : '',
            qaProjectUser:false
          }
          if(user.username != 'admin'){
            user.userRolesList[projectName].forEach((entry) => {
              if (entry === 'projectOwner') {
                temp.isAdmin = true;
                temp.selectedRolePrivilege = 'executionRole';
                temp.qaProjectUser=false
              } else if(entry === 'projectUser'){
                temp.isAdmin = false;
                temp.selectedRolePrivilege = 'projectUser';
                temp.qaProjectUser=user.executeUserRole=="qaUser"&&userType=="devProject"?true:false
              } else if(entry === 'readOnlyRole'){
                temp.isAdmin = false;
                temp.selectedRolePrivilege = 'readOnlyRole';
                temp.qaProjectUser=false
              }
            })
            userRole.push(temp);
          }          
        }
      });
      
      if(userRole.length === 0) {
        userRole = [{
          username: '',
          isAdmin: false,
          selectedRolePrivilege : '',
          qaProjectUser:false
        }]
      }
      this.setState({
        users:usertemp,
        userRoleList: userRole
      })
   });
  }

  render() {
    const { projectName, projectDesc, loading, error, dataTypes, azureSubscriptionKey, azureRegion, gcpDataFile,
      languageTranslationKey, languageTranslationEndpoint, languageTranslationRegion,awsAccessKey,awsSecretKey,awsRegion} = this.state;
    const dataTypes1 = [
      { label: "Numeric", value: "Numeric" },
      { label: "Categorical", value: "Categorical" },
      { label: "Free-text", value: "Free-text" },
    ];

    const variableTypes = [
      { label: "Input Feature", value: "Input Feature" },
      { label: "Output Label", value: "Output Label" },
    ];

    const variableTypesForAWSCustom = [
      { label: "Utterance - Input Feature", value: "Utterance - Input Feature"},
      { label: "Input Feature", value: "Input Feature" },
      { label: "Output Label", value: "Output Label" },
    ];

    const modelCategories = [
      { label: "Conversational AI", value: "Conversational AI" },
      { label: "Classification", value: "Classification" },
      { label: "Regression", value: "Regression" },
      { label: "Recommendation", value: "Recommendation" },
      { label: "Image Classification", value: "Image Classification" },
      { label: "Generative AI", value: "Generative AI" },
    ];

    const conversationalAISubType = [
      { label: "Rasa", value: "Rasa" },
      { label: "Microsoft LUIS", value: "LUIS" },
      { label: "Amazon Lex", value: "LEX" },
      { label: "AWS Custom", value: "AWSLambdaClient" },
      { label: "Voice Assistant", value: "Voice Assistant"},
      { label: "Microsoft CLU", value: "CLU" }
    ];

    if (loading) {
      return <CircularProgress/>;
    }

    return (
      <div className="animated fadeIn">
      
        {
          this.state.userError &&
          <div className="alertmessage alert alert-danger">
              <a className="close">
                <span aria-hidden="true">&nbsp;&times;</span>
              </a>
              <span className="span-message">{this.state.userError}</span>
            </div>
        }
        { !this.state.userError &&
        <Row>
          <Col xs="12" sm="12">
            <Card>
              <CardHeader>
                <strong>Project</strong>
              </CardHeader>
              <CardBody>
                {error && 
                    <div className="alertmessage alert alert-danger">
                      <a className="close" onClick={this.handleErrorClose}>
                          <span aria-hidden="true">&nbsp;&times;</span>
                      </a>
                      <span className="span-message">{error}</span>
                    </div>
                }
                <FormGroup row className="my-0">
                  <Col xs="6">
                    <FormGroup>
                      { this.state.action === 'create' &&
                        <Label style={{color: 'red'}}>* </Label>
                      }
                      <Label htmlFor="mandatory">Project Name</Label>
                  {  this.state.action === 'create' &&

                    <Input type="text" id="firstName"
                     placeholder="Enter Project Name" name="projectName" value={projectName} onChange={this.handleChange}/>
                  }
                {  
                  this.state.action === 'edit' &&
                     <Input type="text" id="firstName" 
                     disabled={this.state.projectName}
                     placeholder="Enter Project Name" name="projectName" value={projectName} onChange={this.handleChange}/>
                 }
                      </FormGroup>
                  </Col>
                  <Col xs="6">
                    <FormGroup>
                      <Label htmlFor="postal-code">Project Description</Label>
                      <Input type="text" id="lastName" placeholder="Enter Project Description" name="projectDesc" value={projectDesc} onChange={this.handleChange}/>
                    </FormGroup>
                  </Col>
                </FormGroup>
                <br/>
                <FormGroup row className="my-0">
                  <Col xs="6">
                    <FormGroup>
                      { this.state.action === 'create' &&
                        <Label style={{color: 'red'}}>* </Label>
                      }
                      <Label htmlFor="postal-code">Project Type</Label>
                      {
                        this.state.action === 'create' &&
                        <Select name="dataType" value={modelCategories.filter(option => option.value === this.state.modelCategory)} 
                          options={ modelCategories } onChange={this.modelCategoryDropdownchange}/>
                      }
                      {
                        this.state.action === 'edit' &&
                        <Input name="dataType" value={this.state.modelCategory}  readOnly/>
                      }
                    </FormGroup>
                  </Col>
                {
                  this.state.modelCategory === 'Conversational AI' && 
                  <Col xs="6">
                    <FormGroup>
                      { this.state.action === 'create' &&
                        <Label style={{color: 'red'}}>* </Label>
                      }
                      <Label htmlFor="postal-code">Conversational AI Engine</Label>
                      {
                        this.state.action === 'create' &&
                        <Select name="dataType" value={conversationalAISubType.filter(option => option.value === this.state.modelCategorySubType)} 
                          options={ conversationalAISubType } onChange={this.modelCategorySubTypeDropdownchange}/>
                      }
                      {
                        this.state.action === 'edit' &&
                        <Input name="dataType" value={this.state.modelCategorySubType}  readOnly/>
                      }
                    </FormGroup>
                    
                    </Col>
                }
                  <Col xs="6">
                    <FormGroup>
                      <Label htmlFor="devQAProject">Project Life Cycle Stage</Label><br></br>
                      <FormGroup check inline>
                        <input className="form-check-input" type= "radio" id="devProject" name="devProject" value="devProject" checked={this.state.userTypeProject == "devProject"}
                          onChange={this.setUserProjectType} disabled={this.state.action=='edit'}/>
                        <Label className="form-check-label"  htmlFor="devProject">Dev self testing project &nbsp;&nbsp;&nbsp;</Label>
                      </FormGroup>
                      <FormGroup check inline>
                        <input className="form-check-input" type= "radio" id="qaProject" name="qaProject" value="qaProject" checked={this.state.userTypeProject == "qaProject"}
                            onChange={this.setUserProjectType} disabled={this.state.action=='edit'}/>                       
                        <Label className="form-check-label"  htmlFor="qaProject">QA project&nbsp;&nbsp;&nbsp;</Label>
                      </FormGroup>
                    </FormGroup>
                  </Col>
                </FormGroup>

                {
                  this.state.modelCategory === 'Image Classification' && 
                  <div className='form_grp'>
                    <h5>Project Meta Data for {this.state.modelCategory}</h5>
                      <Card>
                        <CardBody style={{maxHeight: '300px', overflowY: 'auto'}}>
                          <table className="table table-bordered table-hover" id="tab_logic">
                            <thead>
                              <tr>
                                <th className="text-center"> # </th>
                                <th className="text-center"> Label Name </th>
                                <th className="text-center"> Description </th>
                                <th className="text-center"> Class Label  </th>                               
                                <th className="text-center"> Action</th>                              
                              </tr>
                            </thead>
                            <tbody>

                        {   this.state.metaDataList !== null &&
                          
                          this.state.metaDataList.map((item, idx) => (
                          <tr id="addr0" key={idx}>
                            <td className="text-center">{idx+1}</td>
                            <td>
                              <input type="text" name="name" value={this.state.metaDataList[idx].name} onChange={this.handleMetaDataChange(idx)}
                                className="form-control"/>
                            </td>
                            <td>
                              <input type="text" name="description" value={this.state.metaDataList[idx].description} onChange={this.handleMetaDataChange(idx)}
                                className="form-control"/>
                            </td>
                            <td>
                              <input type="text" name="type" value={this.state.metaDataList[idx].type} onChange={this.handleMetaDataChange(idx)}
                                className="form-control"/>
                            </td>                          
                          
                            <td className="text-center">
                              <button className="btn btn-danger btn-sm" onClick={this.handleRemoveSpecificRow(idx, 'metaData')}>
                                Remove
                              </button>
                            </td>
                          </tr>
                        ))                     
                                              
                        }

                          </tbody>
                          </table>
                          <button onClick={() => this.handleAddRow('metaData')} className="btn btn-primary">Add MetaData</button>&nbsp;&nbsp;
                          <button onClick={() => this.handleRemoveRow('metaData')} className="btn btn-danger">
                            Delete Last MetaData Row
                          </button>
                        </CardBody>
                      </Card>
                    </div>
                  }

                
                {
                  this.state.showModelCatog && 
                  this.state.modelCategory !== 'Image Classification' && this.state.modelCategory !== 'Generative AI' && 
                  <div className='form_grp'>
                    <h5>Project Meta Data for {this.state.modelCategory}</h5>
                      <Card>
                        <CardBody style={{maxHeight: '300px', overflowY: 'auto'}}>
                          <table className="table table-bordered table-hover" id="tab_logic">
                            <thead>
                              <tr>
                                <th className="text-center"> # </th>
                                <th className="text-center"> Name </th>
                                <th className="text-center"> Description </th>
                                <th className="text-center"> Data Type </th>
                                <th className="text-center"> Variable Type </th>
                                <th className="text-center"> Action</th>
                              </tr>
                            </thead>
                            <tbody>

                        {   this.state.metaDataList !== null &&
                          
                          this.state.metaDataList.map((item, idx) => (
                          <tr id="addr0" key={idx}>
                            <td className="text-center">{idx+1}</td>
                            <td>
                              <input type="text" name="name" value={this.state.metaDataList[idx].name} onChange={this.handleMetaDataChange(idx)}
                                className="form-control"/>
                            </td>
                            <td>
                              <input type="text" name="description" value={this.state.metaDataList[idx].description} onChange={this.handleMetaDataChange(idx)}
                                className="form-control"/>
                            </td>
                            <td>
                              <Select name="dataType" value={dataTypes.filter(option => option.value === this.state.metaDataList[idx]['dataType'])} 
                              options={ dataTypes } onChange={this.dataTypeDropdownchange(idx) }/>
                            </td>
                            <td>{(this.state.modelCategorySubType === 'AWSLambdaClient' && this.state.modelCategory === 'Conversational AI')? 
                            <Select name="type" value={variableTypesForAWSCustom.filter(option => option.value === this.state.metaDataList[idx]['type'])} options={ variableTypesForAWSCustom } onChange={this.variableTypeDropdownchange(idx) }/> :
                            <Select name="type" value={variableTypes.filter(option => option.value === this.state.metaDataList[idx]['type'])} options={ variableTypes } onChange={this.variableTypeDropdownchange(idx) }/>
                            }
                             
                            </td>

                            <td className="text-center">
                              <button className="btn btn-danger btn-sm" onClick={this.handleRemoveSpecificRow(idx, 'metaData')}>
                                Remove
                              </button>
                            </td>
                          </tr>
                        ))                     
                    
                        }
                          </tbody>
                          </table>
                          <button onClick={() => this.handleAddRow('metaData')} className="btn btn-primary">Add MetaData</button>&nbsp;&nbsp;
                          <button onClick={() => this.handleRemoveRow('metaData')} className="btn btn-danger">
                            Delete Last MetaData Row
                          </button>
                        </CardBody>
                      </Card>
                    </div>
                 }
                <br />
                <h5><span style={{ color: 'red'}}>*</span>User Association</h5>
                <Card>
                  <CardBody style={{maxHeight: '300px', overflowY: 'auto'}}>
                    <table className="table table-bordered table-hover" id="tab_logic">
                      <thead>
                        <tr>
                          <th className="text-center"> # </th>
                          <th className="text-center"> User Name </th>
                          <th className="text-center"> Role </th>
                          <th className="text-center"> Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {this.state.userRoleList.map((item, idx) => (
                          <tr id="addr0" key={idx}>
                            <td className="text-center">{idx+1}</td>
                            <td>
                              <Select name="username" value={ this.state.users.filter(option => option.value === this.state.userRoleList[idx]['username'])} 
                                options={ this.state.users} onChange={this.userDropdownchange(idx) }/>
                            </td>
                            { (this.state.userRoleList[idx]['selectedRolePrivilege'] == '' || this.state.userRoleList[idx]['selectedRolePrivilege'] == 'readOnlyRole' 
                            || (this.state.userRoleList[idx]['qaProjectUser'] == true&& this.state.userRoleList[idx]['isAdmin']==false) ) &&  
                              <td>

                              </td>
                            }
                            {
                             (((this.state.userRoleList[idx]['selectedRolePrivilege'] == 'executionRole' || this.state.userRoleList[idx]['selectedRolePrivilege'] == 'projectUser') 
                             && this.state.userTypeProject=="devProject" && this.state.userRoleList[idx]['qaProjectUser'] == false) || 
                             (this.state.userRoleList[idx]['selectedRolePrivilege'] != '' && this.state.userRoleList[idx]['selectedRolePrivilege'] != 'readOnlyRole' 
                             && this.state.userRoleList[idx]['qaProjectUser'] == false && this.state.userTypeProject=="qaProject")) &&
                             <td className="text-center">
                             <FormGroup check inline>
                               <Input className="form-check-input" type="checkbox" id="isAdmin" name="isAdmin" value="admin" defaultChecked={this.state.userRoleList[idx]['isAdmin']}
                                 onChange={this.checkBoxSelected(idx)}/>
                               <Label className="form-check-label" check htmlFor="isAdmin">Project Owner</Label>
                             </FormGroup>
                           </td>
                            }                           
                            <td className="text-center">
                              <button className="btn btn-danger btn-sm" onClick={this.handleRemoveSpecificRow(idx, 'user')}>
                                Remove
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    <button onClick={() => this.handleAddRow('user')} className="btn btn-primary">Add User</button>&nbsp;&nbsp;
                    <button onClick={() => this.handleRemoveRow('user')} className="btn btn-danger">
                      Delete Last User Row
                    </button>
                  </CardBody>
                </Card>

                {
                this.state.modelCategory==='Conversational AI'&& 
                <div className='form_grp'>
                <Col md="6">
                <h5><span style={{ color: 'red'}}>**</span>Cloud Configuration Details - Utterance Generation</h5>
                </Col>
                <Col>
                <Card> 
                  <CardBody style={{maxHeight: '300px', overflowY: 'auto'}}>
                  <Row>
                    {
                      this.state.modelCategory==='Conversational AI'&& 
                      <Col md="6">
                        <FormGroup>
                          <Label htmlFor="languageTranslationKey"> </Label>
                          <Label htmlFor="languageTranslationKey">Language Translation Key</Label>
                          <Input type="text" id="languageTranslationKey" 
                            placeholder="Enter Language Translation Key" 
                            name="languageTranslationKey" value={languageTranslationKey} 
                            disabled={this.state.editable}
                            onChange={this.handleChange} />
                          <FormText>Language Translation Key</FormText>
                        </FormGroup>
                      </Col>       
                    }

                  {
                    this.state.modelCategory==='Conversational AI'&& 
                    <Col md="6">
                      <FormGroup>
                        <Label htmlFor="languageTranslationEndpoint"> </Label>
                        <Label htmlFor="languageTranslationEndpoint">Language Translation End-point</Label>
                        <Input type="text" id="languageTranslationEndpoint" 
                          placeholder="Enter Language Translation End-point" 
                          name="languageTranslationEndpoint" value={languageTranslationEndpoint} 
                          disabled={this.state.editable}
                          onChange={this.handleChange} />
                        <FormText>Language Translation End-point</FormText>
                      </FormGroup>
                    </Col>       
                  }

                  {
                    this.state.modelCategory==='Conversational AI'&& 
                    <Col md="6">
                      <FormGroup>
                        <Label htmlFor="languageTranslationRegion"> </Label>
                        <Label htmlFor="languageTranslationRegion">Language Translation Region</Label>
                        <Input type="text" id="languageTranslationRegion" 
                          placeholder="Enter Language Translation Region" 
                          name="languageTranslationRegion" value={languageTranslationRegion} 
                          disabled={this.state.editable}
                          onChange={this.handleChange} />
                        <FormText>Language Translation Region</FormText>
                      </FormGroup>
                    </Col>       
                  }
                  </Row>
                  <Label style={{float: 'left'}}><span style={{ color: 'red'}}>**</span><strong>Cloud configuration details to be filled for utterance generation.</strong></Label>
                  </CardBody>
                </Card>  
                </Col>
                </div> 
                }
                
                {
                this.state.modelCategory==='Conversational AI'&& 
                <div className='form_grp'>
                <Col md="6">
                <h5><span style={{ color: 'red'}}>**</span>Cloud Configuration Details - Speech Generation</h5>
                </Col>
                <Col>
                <Card> 
                  <CardBody style={{maxHeight: '375px', overflowY: 'auto'}}>
                  <Row>
                    {
                      this.state.modelCategory==='Conversational AI'&& 
                      <Col md="6">
                      <FormGroup>
                            <Label htmlFor="awsAccessKey"> </Label>
                            <Label htmlFor="awsAccessKey">AWS Access Key</Label>
                            <Input type="text" id="awsAccessKey" 
                              placeholder="Enter Aws Access Key" 
                              name="awsAccessKey" value={awsAccessKey} 
                              disabled={this.state.editable}
                              onChange={this.handleChange} />
                      <FormText>Access Key from security credentials of user settings</FormText>
                      </FormGroup>
                      </Col>       
                    }
                  {
                    this.state.modelCategory==='Conversational AI'&& 
                    <Col md="6">
                    <FormGroup>
                          <Label htmlFor="awsSecretKey"> </Label>
                          <Label htmlFor="awsSecretKey">Aws Secret Key</Label>
                          <Input type="text" id="awsSecretKey" 
                            placeholder="Enter Aws Secret key" 
                            name="awsSecretKey" value={awsSecretKey} 
                            disabled={this.state.editable}
                            onChange={this.handleChange} />
                    <FormText>Secret Key from security credentials of user settings</FormText>
                    </FormGroup>
                    </Col>       
                  }
                  {
                    this.state.modelCategory==='Conversational AI'&& 
                    <Col md="6">
                    <FormGroup>
                          <Label htmlFor="awsRegion"> </Label>
                          <Label htmlFor="awsRegion">Aws Region</Label>
                          <Input type="text" id="awsRegion" 
                            placeholder="Enter Aws Region" 
                            name="awsRegion" value={awsRegion} 
                            disabled={this.state.editable}
                            onChange={this.handleChange} />
                    <FormText>Aws region from LEX portal</FormText>
                    </FormGroup>
                    </Col>       
                  }
                  {
                  this.state.modelCategory==='Conversational AI'&& 
                  <Col md="6">
                  <FormGroup>
                        <Label htmlFor="azureSubscriptionKey"> </Label>
                        <Label htmlFor="azureSubscriptionKey">Azure Subscription Key</Label>
                        <Input type="text" id="azureSubscriptionKey" 
                          placeholder="Enter Azure Subscription Key" 
                          name="azureSubscriptionKey" value={azureSubscriptionKey} 
                          disabled={this.state.editable}
                          onChange={this.handleChange} />
                  <FormText>Subscription Key mapped to text-speech model</FormText>
                  </FormGroup>
                  </Col>       
                }

                {
                  this.state.modelCategory==='Conversational AI'&& 
                  <Col md="6">
                  <FormGroup>
                        <Label htmlFor="azureRegion"> </Label>
                        <Label htmlFor="azureRegion">Azure Region</Label>
                        <Input type="text" id="azureRegion" 
                          placeholder="Enter Azure Region" 
                          name="azureRegion" value={azureRegion} 
                          disabled={this.state.editable}
                          onChange={this.handleChange} />
                  <FormText>Region from azure portal</FormText>
                  </FormGroup>
                  </Col>       
                }

                {
                  this.state.modelCategory==='Conversational AI'&& 
                  <Col md="6">
                  <FormGroup>
                  <Label htmlFor="file-input">GCP File</Label><br></br>
                  <input type="file" id="file" name="file" className="inputFile" accept=".json" onChange={e => this.fileUpload(e)} />
                  <FormText>Json file with GCP configuration</FormText>
                  </FormGroup>
                  </Col>
                }
                  </Row>
                  <Label style={{float: 'left'}}><span style={{ color: 'red'}}>**</span><strong>Cloud configuration details to be filled for speech generation.&nbsp;&nbsp;</strong></Label>
                <Label style={{float: 'left'}}><strong>After submitting, kindly navigate to project details page to generate/update speech configurations</strong></Label>
                  </CardBody>
                </Card>  
                </Col>
                </div> 
                }
              </CardBody>
              
              <CardFooter>
                <Button type="submit" size="sm" color="primary" style={{ marginRight: '10px' }}
                  disabled={!this.state.projectName.trim()} onClick={() => { this.handleSubmit(); }}>
                  <i className="fa fa-save"></i> Submit</Button>
                <Button type="reset" size="sm" color="info" tag={Link} to={`/settings/projects`}>
                  <i className="fa fa-arrow-left"></i> Back</Button>
                    <Label style={{float: 'right'}}><span style={{ color: 'red'}}>* </span><strong>Marked fields are mandatory</strong></Label>
              </CardFooter>
            </Card>
          </Col>
        </Row>
      }
      </div>
    )
  }
}
export default CreateProject;

// © [2023] Cognizant. All rights reserved.  Cognizant Confidential and/or Trade Secret.
// NOTICE: This unpublished material is proprietary to Cognizant and its suppliers,
// if any. The methods, techniques and technical concepts herein are considered Cognizant confidential
// and/or trade secret information. This material may be covered by U.S. and/or foreign patents or patent
// applications. Use, distribution or copying, in whole or in part, is forbidden, 
// except by express written permission of Cognizant.
