import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Breadcrumbs,
  Button,
  Chip,
  Paper,
  Stack,
  Typography,
} from "@mui/material";
import React, { useContext, useEffect, useState } from "react";
import { Link, useLocation, useParams } from "react-router-dom";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import metaDataIcon from "../../../assets/genaiIcons/terminal.png";
import metaDataSelectedIcon from "../../../assets/genaiIcons/terminal_active.png";
import evaluateIcon from "../../../assets/genaiIcons/find_in_page.png";
import evaluateSelectedIcon from "../../../assets/genaiIcons/find_in_page _active.png";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import inputIcon from "../../../assets/genaiIcons/contact_support.png";
import contextIcon from "../../../assets/genaiIcons/developer_mode_tv.png";
import responseIcon from "../../../assets/genaiIcons/mark_unread_chat_alt.png";
import { styled } from "@mui/material/styles";
import { getEvaluationRecordData } from "../../../_services/genai_evaluation.service";
import { AuthContext } from "../../../globals/AuthContext";
import CoveResults from "../../../components/GenAi_Evaluation/CoveResults/CoveResults";
import KeyboardBackspaceIcon from "@mui/icons-material/KeyboardBackspace";

const CustomAccordianSummary = styled((props) => (
  <AccordionSummary
    expandIcon={<KeyboardArrowRightIcon sx={{ fontSize: "0.9rem" }} />}
    {...props}
  />
))(({ theme }) => ({
  margin: 0,
  border: "1px solid #E6E6E6",
  borderRadius: "0.5rem 0.5rem 0 0",
  flexDirection: "row-reverse",
  "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded": {
    transform: "rotate(-90deg)",
  },
  "& .MuiAccordionSummary-content": {
    marginLeft: theme.spacing(1),
  },
}));

const redList = [
  "controversiality",
  "criminality",
  "harmfullness",
  "insensitivity",
  "maliciousness",
  "misogyny",
  "pii_detction",
  "stereotype",
];

const EvaluationDetails = () => {
  const [cove, setCove] = useState(false);
  const [value, setValue] = useState(0);
  const [data, setData] = useState({});
  const [coveData, setCoveData] = useState({})

  const ctx = useContext(AuthContext);

  const params = useParams();
  const { state } = useLocation();
  const breadcrumbs = [
    <Link
      style={{ color: "#313B3E", fontWeight: 400, fontSize: "20px" }}
      key="1"
      to={"/genai-assurance/genai_evaluate/evaluation_summary/" + params.id}
    >
      InputList
    </Link>,
    <Typography
      style={{ fontWeight: 500, fontSize: "20px", color: "#4546d9" }}
      key="3"
    >
      #{state.num}
    </Typography>,
  ];

  const metaData = [
    { name: "Tokens", value: 108 },
    { name: "Cost", value: (data.metadata && data.metadata.cost) || "NA" },
    {
      name: "Response Time",
      value: (data.metadata && data.metadata.latency) || "NA",
    },
  ];

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  useEffect(() => {
    getEvaluationRecordData(params.subId, ctx.projectSubType).then((result) => {
      setData(result.output);
    });
  }, []);

  return (
    <div style={{ margin: "1rem" }}>
      {cove && (
        <>
          <Button startIcon={<KeyboardBackspaceIcon/>}  variant="contained" onClick={() => setCove(false)}> Back </Button>
          <br />
          <br />
          <CoveResults initialData={coveData} />
        </>
      )}
      {!cove && (
        <Stack gap="1rem">
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
          >
            <Breadcrumbs
              separator={<NavigateNextIcon fontSize="medium" />}
              aria-label="breadcrumb"
            >
              {breadcrumbs}
            </Breadcrumbs>
          </Stack>
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="start"
            gap="1rem"
          >
            <Stack width="70%" gap="1rem">
              {!("Competency" in data) && (
                <>
                  <Accordion
                    square={false}
                    variant={"outlined"}
                    defaultExpanded
                    sx={{ borderRadius: "8px" }}
                  >
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel2-content"
                      id="panel2-header"
                      sx={{ borderRadius: "8px" }}
                    >
                      <Stack direction={"row"} alignItems="center" gap="0.2rem">
                        <img src={inputIcon} alt="inputIcon" />
                        <Typography
                          fontSize="18px"
                          fontWeight={500}
                          color={"#484A56"}
                        >
                          Input
                        </Typography>
                      </Stack>
                    </AccordionSummary>
                    <AccordionDetails
                      style={{
                        backgroundColor: "#E7F1F6",
                        margin: "0.5rem",
                        borderRadius: "8px",
                      }}
                    >
                      <Typography
                        color={"#484A56"}
                        fontSize="15px"
                        fontWeight={400}
                      >
                        {data.question}
                      </Typography>
                    </AccordionDetails>
                  </Accordion>
                  <Accordion
                    square={false}
                    variant={"outlined"}
                    sx={{ borderRadius: "8px" }}
                  >
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel2-content"
                      id="panel2-header"
                      sx={{ borderRadius: "8px" }}
                    >
                      <Stack direction={"row"} alignItems="center" gap="0.5rem">
                        <img src={responseIcon} alt="responseIcon" />
                        <Typography
                          fontSize="18px"
                          fontWeight={500}
                          color={"#484A56"}
                        >
                          Output
                        </Typography>
                      </Stack>
                    </AccordionSummary>
                    <AccordionDetails
                      style={{
                        backgroundColor: "#E7F1F6",
                        margin: "0.5rem",
                        borderRadius: "8px",
                      }}
                    >
                      <Typography
                        color={"#484A56"}
                        fontSize="15px"
                        fontWeight={400}
                      >
                        {ctx.projectSubType==="P2I" ? <img src={data.answer} style={{width: "100%"}} /> : data.answer}
                      </Typography>
                    </AccordionDetails>
                  </Accordion>
                  <Accordion
                    square={false}
                    variant={"outlined"}
                    sx={{ borderRadius: "8px" }}
                  >
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel2-content"
                      id="panel2-header"
                      sx={{ borderRadius: "8px" }}
                    >
                      <Stack direction={"row"} alignItems="center" gap="0.5rem">
                        <img src={contextIcon} alt="contextIcon" />
                        <Typography
                          fontSize="18px"
                          fontWeight={500}
                          color={"#484A56"}
                        >
                          Context
                        </Typography>
                      </Stack>
                    </AccordionSummary>
                    <AccordionDetails
                      style={{
                        backgroundColor: "#E7F1F6",
                        margin: "0.5rem",
                        borderRadius: "8px",
                      }}
                    >
                      {data.context &&
                        data.context.map((item) => (
                          <>
                            <Typography
                              color={"#484A56"}
                              fontSize="15px"
                              fontWeight={400}
                            >
                              {item}
                            </Typography>
                            <br />
                          </>
                        ))}
                    </AccordionDetails>
                  </Accordion>
                </>
              )}
              {"Competency" in data && (
                <>
                  <Accordion
                    square={false}
                    variant={"outlined"}
                    defaultExpanded
                    sx={{ borderRadius: "8px" }}
                  >
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel2-content"
                      id="panel2-header"
                      sx={{ borderRadius: "8px" }}
                    >
                      <Stack direction={"row"} alignItems="center" gap="0.2rem">
                        <img src={inputIcon} alt="inputIcon" />
                        <Typography
                          fontSize="18px"
                          fontWeight={500}
                          color={"#484A56"}
                        >
                          Input
                        </Typography>
                      </Stack>
                    </AccordionSummary>
                    <AccordionDetails
                      style={{
                        backgroundColor: "#E7F1F6",
                        margin: "0.5rem",
                        borderRadius: "8px",
                      }}
                    >
                      <Typography
                        color={"#484A56"}
                        fontSize="15px"
                        fontWeight={400}
                      >
                        {data.JD_Name}
                      </Typography>
                    </AccordionDetails>
                  </Accordion>
                  <Accordion
                    square={false}
                    variant={"outlined"}
                    defaultExpanded
                    sx={{ borderRadius: "8px" }}
                  >
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel2-content"
                      id="panel2-header"
                      sx={{ borderRadius: "8px" }}
                    >
                      <Stack direction={"row"} alignItems="center" gap="0.2rem">
                        <img src={responseIcon} alt="inputIcon" />
                        <Typography
                          fontSize="18px"
                          fontWeight={500}
                          color={"#484A56"}
                        >
                          Output
                        </Typography>
                      </Stack>
                    </AccordionSummary>
                    <AccordionDetails
                      style={{
                        backgroundColor: "#E7F1F6",
                        margin: "0.5rem",
                        borderRadius: "8px",
                      }}
                    >
                      <Typography
                        fontSize="15px"
                        fontWeight={400}
                        color={"#484A56"}
                      >
                        {data.Question}
                      </Typography>
                    </AccordionDetails>
                  </Accordion>

                  <Accordion
                    square={false}
                    variant={"outlined"}
                    sx={{ borderRadius: "8px" }}
                  >
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel2-content"
                      id="panel2-header"
                      sx={{ borderRadius: "8px" }}
                    >
                      <Stack direction={"row"} alignItems="center" gap="0.5rem">
                        <img src={contextIcon} alt="contextIcon" />
                        <Typography
                          fontSize="18px"
                          fontWeight={500}
                          color={"#484A56"}
                        >
                          Context
                        </Typography>
                      </Stack>
                    </AccordionSummary>
                    <AccordionDetails
                      style={{
                        backgroundColor: "#E7F1F6",
                        margin: "0.5rem",
                        borderRadius: "8px",
                      }}
                    >
                      {/* <Typography
                      fontSize="18px"
                      fontWeight={500}
                      color={"#484A56"}
                    >
                      Competency Description
                    </Typography>
                    <Typography
                      fontSize="15px"
                      fontWeight={400}
                      color={"#484A56"}
                    >
                      {data.Competency_description ||
                        data["Competency-description"]}
                    </Typography> 
                    <br /> */}
                      <Typography
                        fontSize="18px"
                        fontWeight={500}
                        color={"#484A56"}
                      >
                        JD Output Context
                      </Typography>
                      <Typography
                        fontSize="15px"
                        fontWeight={400}
                        color={"#484A56"}
                      >
                        {data["JD-context"] || data.JD_context}
                      </Typography>
                      <br />
                      <Typography
                        fontSize="18px"
                        fontWeight={500}
                        color={"#484A56"}
                      >
                        Competency Output Context
                      </Typography>
                      <Typography
                        fontSize="15px"
                        fontWeight={400}
                        color={"#484A56"}
                      >
                        {data.JD_competency_context ||
                          data["JD-competency-context"]}
                      </Typography>
                    </AccordionDetails>
                  </Accordion>
                </>
              )}
            </Stack>
            <Stack width="30%">
              <Paper>
                <Paper style={{ height: "auto" }}>
                  <Tabs
                    style={{
                      padding: 0,
                      margin: 0,
                      display: "flex",
                      alignItems: "start",
                    }}
                    value={value}
                    onChange={handleChange}
                    aria-label="icon position tabs example"
                  >
                    <Tab
                      style={{ padding: "0 1rem", margin: 0 }}
                      icon={
                        value === 0 ? (
                          <img src={metaDataSelectedIcon} alt="icon" />
                        ) : (
                          <img src={metaDataIcon} alt="icon" />
                        )
                      }
                      iconPosition="start"
                      label="Metadata"
                    />
                    <Tab
                      style={{ padding: "0 1rem" }}
                      icon={
                        value === 1 ? (
                          <img src={evaluateSelectedIcon} alt="icon" />
                        ) : (
                          <img src={evaluateIcon} alt="icon" />
                        )
                      }
                      iconPosition="start"
                      label="Evaluate"
                    />
                  </Tabs>
                </Paper>
                {value === 0 && (
                  <Stack
                    style={{ padding: "0.5rem 1rem 1rem 1rem" }}
                    gap="0.5rem"
                  >
                    {metaData.map((mdata) => (
                      <Stack
                        direction="row"
                        justifyContent="space-between"
                        alignItems="center"
                        style={{
                          backgroundColor: "#F9FDFF",
                          padding: "0.25rem 0.5rem",
                          border: "1px solid #BFBFBF",
                          borderRadius: "0.25rem",
                          fontWeight: 500,
                          fontSize: "14px",
                        }}
                      >
                        {mdata.name}
                        <Chip
                          style={{ borderRadius: "4px" }}
                          label={mdata.value}
                          variant="outlined"
                          color={
                            typeof mdata.value === "number"
                              ? "success"
                              : "primary"
                          }
                        />
                      </Stack>
                    ))}
                  </Stack>
                )}

                {value === 1 && (
                  <Stack
                    style={{ padding: "0.5rem 1rem 1rem 1rem" }}
                    gap="0.5rem"
                  >
                    {data.metrics.map((item, index) => (
                      // ((Object.keys(data.metrics).includes(item[0]) &&
                      //   Object.keys(data.metrics).includes(
                      //     item[0] + "_REASON"
                      //   )) ||
                      //   item[0] === "Direct-Indirect") &&
                      <Accordion sx={{ borderRadius: "8px" }}>
                        <CustomAccordianSummary
                          expandIcon={<KeyboardArrowRightIcon />}
                          aria-controls="panel2-content"
                          id="panel2-header"
                          sx={{ borderRadius: "8px" }}
                        >
                          <Stack
                            flexGrow={1}
                            direction="row"
                            justifyContent="space-between"
                            alignItems="center"
                          >
                            <Stack direction="row">
                              <Typography fontSize="14px" fontWeight={400}>
                                {item.name}
                              </Typography>
                            </Stack>
                            {ctx.projectName === "JD_QUESTIONNAIRE" ? (
                              <Chip
                                style={{
                                  height: "1rem",
                                  fontSize: "10px",
                                  color: item.status ? "#0fc7c7" : "#ff5473",
                                  border: item.status
                                    ? "1px solid #0fc7c7"
                                    : "1px solid #ff5473",
                                }}
                                label={item.status ? "Passed" : "Failed"}
                                variant="outlined"
                                color={item.status ? "success" : "error"}
                              />
                            ) : (
                              // redList.indexOf(item[0]) > -1 ? (
                              //   <Chip
                              //     style={{
                              //       height: "1rem",
                              //       fontSize: "10px",
                              //       color:
                              //         item[1] < 0.5 || item[1] === "Direct"
                              //           ? "#0fc7c7"
                              //           : "#ff5473",
                              //       border:
                              //         item[1] < 0.5 || item[1] === "Direct"
                              //           ? "1px solid #0fc7c7"
                              //           : "1px solid #ff5473",
                              //     }}
                              //     label={
                              //       item[1] < 0.5 || item[1] === "Direct"
                              //         ? "Passed"
                              //         : "Failed"
                              //     }
                              //     variant="outlined"
                              //     color={
                              //       item[1] < 0.5 || item[1] === "Direct"
                              //         ? "success"
                              //         : "error"
                              //     }
                              //   />
                              // ) :
                              <Chip
                                style={{
                                  height: "1rem",
                                  fontSize: "10px",
                                  color: item.status ? "#0fc7c7" : "#ff5473",
                                  border: item.status
                                    ? "1px solid #0fc7c7"
                                    : "1px solid #ff5473",
                                }}
                                label={item.status ? "Passed" : "Failed"}
                                variant="outlined"
                                color={item.status ? "success" : "error"}
                              />
                            )}
                          </Stack>
                        </CustomAccordianSummary>
                        <AccordionDetails
                          style={{
                            backgroundColor: "#E7F1F6",
                            margin: "0.5rem",
                            borderRadius: "0.5rem",
                          }}
                        >
                          <Typography
                            fontSize="12px"
                            fontWeight={400}
                            color={"#484A56"}
                          >
                            {item.hasOwnProperty("reason") && <strong>Reason: </strong>}

                            {/* {item[0] === "Direct-Indirect" && (
                                <>{item[1]} Question</>
                              )} */}

                            {item.reason}

                            {item.hasOwnProperty("recommendations") && <br/>}

                            {item.hasOwnProperty("recommendations") && <strong>Recommendations: </strong> }

                            {item.hasOwnProperty("recommendations") && item.recommendations}

                            {(item.name.toLowerCase() === "cove" ||
                              item.name.toUpperCase() === "CONSISTENT") && (
                              <Button onClick={() => { setCoveData(JSON.parse(item.reason)); setCove(true); }}>
                                {" "}
                                View Results{" "}
                              </Button>
                            )}

                            {item.name === "Factuality" && (
                              <>
                                <br />
                                <br />
                                Evidence:{" "}
                              </>
                            )}
                            {item.evidence}
                            {/* {"Competency" in data
                                ? data.metrics[
                                    item[0].split("_")[0] + "_reason"
                                  ] || "N/A"
                                : data.metrics[item[0] + "_reason"] || "N/A"} */}
                          </Typography>
                        </AccordionDetails>
                      </Accordion>
                    ))}

                    {Object.keys(data.custom_metrics).map((item, index) => (
                      <Accordion sx={{ borderRadius: "8px" }}>
                      <CustomAccordianSummary
                        expandIcon={<KeyboardArrowRightIcon />}
                        aria-controls="panel2-content"
                        id="panel2-header"
                        sx={{ borderRadius: "8px" }}
                      >
                        <Stack
                          flexGrow={1}
                          direction="row"
                          justifyContent="space-between"
                          alignItems="center"
                        >
                          <Stack direction="row">
                            <Typography fontSize="14px" fontWeight={400}>
                              {item.name}
                            </Typography>
                          </Stack>
                          {ctx.projectName === "JD_QUESTIONNAIRE" ? (
                            <Chip
                              style={{
                                height: "1rem",
                                fontSize: "10px",
                                color: item.status ? "#0fc7c7" : "#ff5473",
                                border: item.status
                                  ? "1px solid #0fc7c7"
                                  : "1px solid #ff5473",
                              }}
                              label={item.status ? "Passed" : "Failed"}
                              variant="outlined"
                              color={item.status ? "success" : "error"}
                            />
                          ) : (
                            // redList.indexOf(item[0]) > -1 ? (
                            //   <Chip
                            //     style={{
                            //       height: "1rem",
                            //       fontSize: "10px",
                            //       color:
                            //         item[1] < 0.5 || item[1] === "Direct"
                            //           ? "#0fc7c7"
                            //           : "#ff5473",
                            //       border:
                            //         item[1] < 0.5 || item[1] === "Direct"
                            //           ? "1px solid #0fc7c7"
                            //           : "1px solid #ff5473",
                            //     }}
                            //     label={
                            //       item[1] < 0.5 || item[1] === "Direct"
                            //         ? "Passed"
                            //         : "Failed"
                            //     }
                            //     variant="outlined"
                            //     color={
                            //       item[1] < 0.5 || item[1] === "Direct"
                            //         ? "success"
                            //         : "error"
                            //     }
                            //   />
                            // ) :
                            <Chip
                              style={{
                                height: "1rem",
                                fontSize: "10px",
                                color: item.status ? "#0fc7c7" : "#ff5473",
                                border: item.status
                                  ? "1px solid #0fc7c7"
                                  : "1px solid #ff5473",
                              }}
                              label={item.status ? "Passed" : "Failed"}
                              variant="outlined"
                              color={item.status ? "success" : "error"}
                            />
                          )}
                        </Stack>
                      </CustomAccordianSummary>
                      <AccordionDetails
                        style={{
                          backgroundColor: "#E7F1F6",
                          margin: "0.5rem",
                          borderRadius: "0.5rem",
                        }}
                      >
                        <Typography
                          fontSize="12px"
                          fontWeight={400}
                          color={"#484A56"}
                        >
                          {item.hasOwnProperty("reason") && <>Reason: </>}

                          {/* {item[0] === "Direct-Indirect" && (
                              <>{item[1]} Question</>
                            )} */}

                          {item.reason}

                          {(item.name.toLowerCase() === "cove" ||
                            item.name.toUpperCase() === "CONSISTENT") && (
                            <Button onClick={() => { setCoveData(JSON.parse(item.reason)); setCove(true); }}>
                              {" "}
                              View Results{" "}
                            </Button>
                          )}

                          {item.name === "Factuality" && (
                            <>
                              <br />
                              <br />
                              Evidence:{" "}
                            </>
                          )}
                          {item.evidence}
                          {/* {"Competency" in data
                              ? data.metrics[
                                  item[0].split("_")[0] + "_reason"
                                ] || "N/A"
                              : data.metrics[item[0] + "_reason"] || "N/A"} */}
                        </Typography>
                      </AccordionDetails>
                    </Accordion>

                      // <Accordion sx={{ borderRadius: "8px" }}>
                      //   <CustomAccordianSummary
                      //     expandIcon={<KeyboardArrowRightIcon />}
                      //     aria-controls="panel2-content"
                      //     id="panel2-header"
                      //     sx={{ borderRadius: "8px" }}
                      //   >
                      //     <Stack
                      //       flexGrow={1}
                      //       direction="row"
                      //       justifyContent="space-between"
                      //       alignItems="center"
                      //     >
                      //       <Stack direction="row">
                      //         <Typography fontSize="14px" fontWeight={400}>
                      //           {item}
                      //         </Typography>
                      //       </Stack>
                      //       {ctx.projectName === "JD_QUESTIONNAIRE" ? (
                      //         <Chip
                      //           style={{
                      //             height: "1rem",
                      //             fontSize: "10px",
                      //             color: data.custom_metrics[item].status==="Pass" ? "#0fc7c7" : "#ff5473",
                      //             border: data.custom_metrics[item].status==="Pass"
                      //               ? "1px solid #0fc7c7"
                      //               : "1px solid #ff5473",
                      //           }}
                      //           label={data.custom_metrics[item].status==="Pass" ? "Passed" : "Failed"}
                      //           variant="outlined"
                      //           color={data.custom_metrics[item].status==="Pass" ? "success" : "error"}
                      //         />
                      //       ) : (
                      //         <Chip
                      //           style={{
                      //             height: "1rem",
                      //             fontSize: "10px",
                      //             color: data.custom_metrics[item].status==="Pass" ? "#0fc7c7" : "#ff5473",
                      //             border: data.custom_metrics[item].status==="Pass"
                      //               ? "1px solid #0fc7c7"
                      //               : "1px solid #ff5473",
                      //           }}
                      //           label={data.custom_metrics[item].status==="Pass" ? "Passed" : "Failed"}
                      //           variant="outlined"
                      //           color={data.custom_metrics[item].status==="Pass" ? "success" : "error"}
                      //         />
                      //       )}
                      //     </Stack>
                      //   </CustomAccordianSummary>
                      //   <AccordionDetails
                      //     style={{
                      //       backgroundColor: "#E7F1F6",
                      //       margin: "0.5rem",
                      //       borderRadius: "0.5rem",
                      //     }}
                      //   >
                      //     <Typography
                      //       fontSize="12px"
                      //       fontWeight={400}
                      //       color={"#484A56"}
                      //     >
                      //       {data.custom_metrics[item].custom_name}
                      //       {data.custom_metrics[item].hasOwnProperty("reason") && <>Reason: </>}

                      //       // {data.custom_metrics[item].reason || "NA"} 
                      //     </Typography>
                      //   </AccordionDetails>
                      // </Accordion>
                    ))}
                  </Stack>
                )}
              </Paper>
            </Stack>
          </Stack>
        </Stack>
      )}
    </div>
  );
};

export default EvaluationDetails;
