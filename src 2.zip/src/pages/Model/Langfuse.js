import {
    Button,
    FormControl,
    FormLabel,
    MenuItem,
    Select,
    Stack,
    TextField,
} from "@mui/material";
import React, { useState } from "react";
import classes from "./LLM.module.css";
import { saveCredentialsforLangfuse } from "../../_services/model.service";

const langfuseFields = [
    { label: "Secret Key", key: "secret_key" },
    { label: "Public Key", key: "public_key" },
    { label: "Host", key: "host" },
];

const platformList = ["Langfuse", "Langsmith", "Arize", "Phoenix Arize"]

const Langfuse = () => {

    const [observabilityPlatformName, setObservabilityPlatformName] = useState("");
    const [modelDetails, setModelDetails] = useState({});
    const [successMessage, setSuccessMessage] = useState("")


    const handleCreate = () => {
        let data = {
            secret_key: modelDetails.secret_key,
            public_key: modelDetails.public_key,
            host: modelDetails.host
        };
        saveCredentialsforLangfuse(data).then((result) => {
            setSuccessMessage(result.message)
        });
        setModelDetails({});
        setObservabilityPlatformName("")
    };

    return (
        <>
            <div className={classes.content}>
                <Stack direction="column" spacing={2}>
                    <Stack direction="row" alignItems="center" spacing={2}>
                        <FormLabel sx={{ width: "10rem" }}>Observability Platform Name</FormLabel>
                        <FormLabel>:</FormLabel>
                        <FormControl sx={{ m: 1, width: "70%" }}>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                value={observabilityPlatformName}
                                onChange={(e) => setObservabilityPlatformName(e.target.value)}
                            >
                                {platformList.map((item) => (
                                    <MenuItem key={item} value={item}>
                                        {item}
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                    </Stack>

                    {observabilityPlatformName === "Langfuse"
                        && langfuseFields.map((item, index) => (
                            <>
                                <Stack direction="row" alignItems="center" spacing={2}>
                                    <FormLabel sx={{ width: "10rem" }}>{item.label}</FormLabel>
                                    <FormLabel>:</FormLabel>
                                    <FormControl sx={{ m: 1, width: "70%" }}>
                                        <TextField
                                            key={index}
                                            label={item.label}
                                            value={modelDetails[item.key]}
                                            variant="outlined"
                                            onChange={(e) => {
                                                setModelDetails((prev) => {
                                                    let obj = { ...prev };
                                                    obj[item.key] = e.target.value;
                                                    return obj;
                                                });
                                            }}
                                        />
                                    </FormControl>
                                </Stack>
                            </>
                        ))
                    }
                    <div
                        style={{
                            textAlign: "left",
                            paddingTop: "1rem",
                        }}
                    >
                        <Button
                            style={{ marginBottom: "1rem" }}
                            variant="contained"
                            color="primary"
                            onClick={handleCreate}
                        >
                            Create
                        </Button>
                    </div>
                </Stack>
                {successMessage.length > 0 && <div style={{ color: "green", textAlign: "center" }}>{successMessage}</div>}
            </div>
        </>
    );
};

export default Langfuse;
