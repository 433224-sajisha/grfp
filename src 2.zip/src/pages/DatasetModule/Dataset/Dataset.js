import {
  Box,
  Button,
  Chip,
  CircularProgress,
  IconButton,
  Modal,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  TextField,
  Typography,
} from "@mui/material";
import React, { useContext, useEffect, useState } from "react";
import DeleteIcon from "@mui/icons-material/Delete";
import RefreshIcon from "@mui/icons-material/Refresh";
import AddIcon from "@mui/icons-material/Add";
import CloseIcon from "@mui/icons-material/Close";
import styles from "./Dataset.module.css";
import { Link } from "react-router-dom";
import {
  createDataset,
  getAllDatasets,
  deleteDataset,
} from "../../../_services/genai_dataset.service";
import { AuthContext } from "../../../globals/AuthContext";
import { formatTimestamp } from "../../../_helpers/formatTime";
import Confirmation from "../../../components/Confirmation/Confirmation";

const Dataset = () => {
  const ctx = useContext(AuthContext);
  ctx.updateHeader("Dataset");

  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [rowPage, setRowPage] = useState(5);
  const [open, setOpen] = useState(false);
  const [datasetName, setDatasetName] = useState("");
  const [datasetDescription, setDatasetDescription] = useState("");
  const [refresh, setRefresh] = useState(true);
  const [datasetList, setDatasetList] = useState([]);
  const [confirm, setConfirm] = useState(false);
  const [selectedId, setSelectedId] = useState("");

  const handleChangeDatasetName = (event) => {
    setDatasetName(event.target.value);
  };

  const handleChangeDatasetDescription = (event) => {
    setDatasetDescription(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = {
      projectName: ctx.projectName,
      datasetName: datasetName,
      datasetDesc: datasetDescription,
      createdBy: ctx.username,
      modifiedBy: ctx.username,
      file_metadata: []
    };

    createDataset(data).then((result) => {
      setDatasetName("");
      setDatasetDescription("");
      setRefresh(true);
      setOpen(false);
    });
  };

  const getDatasetList = () => {
    const project_name = ctx.projectName;
    getAllDatasets(project_name).then((result) => {
      setDatasetList(result);
      setLoading(false);
    });
  };

  useEffect(() => {
    setLoading(true);
    if (refresh) {
      getDatasetList();
      setRefresh(false);
    }
  }, [refresh]);

  const handleDeleteDataset = (datasetId) => {
    deleteDataset(datasetId).then((result) => {
      setRefresh(true);
    });
  };

  const handleChangePage = (event, newpage) => {
    setPage(newpage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const toggleModal = () => {
    setOpen((prev) => !prev);
  };

  const getDocumentList = (paths) => {
    if (paths === "" || paths === null || paths === undefined) return [];
    let pathList = paths.split(",");
    let nameList = pathList.map((path) => {
      return { name: path.split("\\").reverse()[0] };
    });
    return nameList;
  };

  const toggleConfirm = () => {
    setConfirm(prev => !prev);
  }

  return (
    <div style={{ margin: "1rem", height: "calc(100vh - 75px)" }}>
      <Confirmation
        open={confirm}
        toggleConfirm={toggleConfirm}
        handleSubmit={() => {
          handleDeleteDataset(selectedId);
          toggleConfirm();
        }}
        message="Are you sure you want to delete this?"
      />
      <>
        <div className={styles.buttonContainer}>
          <Button variant="contained" onClick={toggleModal}>
            Create Dataset
            <AddIcon />
          </Button>
        </div>
        <TableContainer component={Paper}>
          <Table aria-label="Material-UI Table">
            <TableHead sx={{ background: "#111270", color: "#fff" }}>
              <TableRow sx={{ alignItems: "center", color: "#fff" }}>
                <TableCell
                  sx={{ width: "2.5rem", color: "#fff", textAlign: "left" }}
                >
                  S No.
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  Name
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  Description
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  Created By
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  Last Modified By
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  Last Modified Date
                </TableCell>
                <TableCell sx={{ color: "#fff", textAlign: "left" }}>
                  Action
                </TableCell>
              </TableRow>
            </TableHead>
            {loading === true ? (
              <TableBody>
                <TableRow>
                  <TableCell colSpan={8}>
                    <Stack width="100%" direction="row" justifyContent="center">
                      <CircularProgress />
                    </Stack>
                  </TableCell>
                </TableRow>
              </TableBody>
            ) : datasetList.length === 0 ? (
              <TableBody>
                <TableRow>
                  <TableCell colSpan={8}>
                    <Stack width="100%" direction="row" justifyContent="center">
                      No Data Available
                    </Stack>
                  </TableCell>
                </TableRow>
              </TableBody>
            ) : (
              <TableBody>
                {datasetList
                  .slice(page * rowPage, page * rowPage + rowPage)
                  .map((row, index) => {
                    const uniqueRowNumber = page * rowPage + index + 1;
                    return (
                      <TableRow
                        key={index}
                        style={
                          index % 2
                            ? { background: "#F6F6F6" }
                            : { background: "white" }
                        }
                      >
                        <TableCell>{uniqueRowNumber}</TableCell>
                        <TableCell>
                          <Link
                            to={row._id}
                            state={{
                              datasetId: row._id,
                              documentList: row.file_metadata
                            }}
                          >
                            {row.datasetName}
                          </Link>
                        </TableCell>
                        <TableCell>{row.datasetDesc}</TableCell>
                        <TableCell>{row.createdBy}</TableCell>
                        <TableCell>{row.modifiedBy}</TableCell>
                        <TableCell>
                          {formatTimestamp(row.modifiedDate)}
                        </TableCell>
                        <TableCell>
                          <IconButton
                            onClick={() => {
                              setSelectedId(row._id);
                              toggleConfirm();
                            }}
                          >
                            <DeleteIcon sx={{ color: "red" }} />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            )}
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={datasetList.length}
          rowsPerPage={rowPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </>

      <Modal
        open={open}
        onClose={toggleModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            maxWidth: "90%", // Adjust the maximum width as needed
            width: "auto",
            bgcolor: "background.paper",
            boxShadow: 24,
            overflow: "auto", // Enable scrolling if content overflows
            maxHeight: "80vh", // Set a maximum height to trigger scrolling
            p: 2,
            borderRadius: "1rem",
          }}
        >
          <div className={styles.modalHeader}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              Create Dataset
            </Typography>
            <IconButton onClick={toggleModal}>
              {" "}
              <CloseIcon />
            </IconButton>
          </div>
          <div className={styles.modalContent}>
            <TextField
              fullWidth
              id="outlined-basic"
              label="Name"
              variant="outlined"
              margin="dense"
              value={datasetName}
              onChange={handleChangeDatasetName}
            />
            <TextField
              fullWidth
              id="outlined-basic"
              label="Description"
              variant="outlined"
              margin="dense"
              multiline
              minRows={2}
              value={datasetDescription}
              onChange={handleChangeDatasetDescription}
            />
          </div>
          <div className={styles.modalFooter}>
            <Button
              centerRipple
              variant="contained"
              disabled={datasetName === ""}
              onClick={handleSubmit}
            >
              Submit
            </Button>
          </div>
        </Box>
      </Modal>
    </div>
  );
};

export default Dataset;
