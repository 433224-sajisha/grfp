import React from 'react';
const AugmentationGrid = ({ items, selected, onToggle }) => {
    return (
        <div className="augmentation-grid">
            {items.map((item, index) => (
                <label key={index} className="checkbox-pill">
                    <input
                        type="checkbox"
                        checked={selected.includes(item)}
                        onChange={() => onToggle(item)}
                    />
                    {item}
                </label>
            ))}
        </div>
    );
};
export default AugmentationGrid;