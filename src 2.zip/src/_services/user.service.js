import { authHeader, handleResponse } from '../_helpers';
import DOMPurify from 'dompurify';

export const userService = {
    login,
    logout,
    validateToken,
    generateToken,
    getAllUsers,
    createUser,
    getUserDetails,
    deleteUser,
    updateUser
};

function logout() {
    localStorage.removeItem('user');
    localStorage.removeItem('selectedRoles');
}

function handleUserToken(user,key) {
    if(key === 'token'){
        return user.jwttoken
    }
    if(key === 'name'){
        return user.username
    }
    if(key === 'text'){
        return user
    }
}

function login(authToken) {
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ authToken }),
        mode: 'cors',
        cache: 'default'
    };
    return fetch(`${process.env.PUBLIC_URL}/auth/login`, requestOptions)
        .then(handleResponseLogin)
        .then(user => {
            if (user) {
                localStorage.setItem('user', handleUserToken(user,'token'));
                localStorage.setItem('username',handleUserToken(user,'name'));
                // localStorage.setItem('projects', JSON.stringify(userValue.projects));
                // localStorage.setItem('userRolesList', JSON.stringify(userValue.userRolesList));
                localStorage.removeItem('sessionExpire');
            }
            return user;
        });
}

function validateToken() {
    let jwttoken = DOMPurify.sanitize(localStorage.getItem('user'));
    const requestOptions = {
        method: 'POST',
        body: JSON.stringify({jwttoken}),
        mode: 'cors',
        cache: 'default',
        headers: { 
            'Content-Type': 'application/json',
            'Authorization': authHeader()
         },
    };
    return fetch(`${process.env.PUBLIC_URL}/auth/token/validate`, requestOptions)
        .then(response => {
            if (response.status === 200) {
                return true;
            }else if(response.status === 201){
                response.text().then(text => {
                    localStorage.setItem('user',handleUserToken(text,'text'));
                    return true;
                });                
            } else {
                logout();
                localStorage.setItem('sessionExpire', 'Session is expired. Please login again.');
                return false;
            }
        });
}

function generateToken() {
    let jwttoken = DOMPurify.sanitize(localStorage.getItem('user'));
    const requestOptions = {
        method: 'POST',
        body: JSON.stringify({jwttoken}),
        mode: 'cors',
        cache: 'default',
        headers: { 
            'Content-Type': 'application/json',
            'Authorization': authHeader()
         },
    };
    return fetch(`${process.env.PUBLIC_URL}/auth/token/generate`, requestOptions)
        .then(handleResponseTokenGenerate)
        .then(user => {
            if (user) {
                localStorage.setItem('user', handleUserToken(user,'token'));
            }
            return user;
        });
}

function createUser(user) {
    const requestOptions = {
        method: 'POST',
        credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: { 
            'Content-Type': 'application/json',
            'Authorization': authHeader()
         },
        body: user
    };
    return fetch(`${process.env.PUBLIC_URL}/api/user/register`, requestOptions)
        .then(response => {
            if(response.status === 201) {
                return response;
            } else {
                return Promise.reject('Error while creating a user.');
            }
        })
}

function updateUser(user) {
    const requestOptions = {
        method: 'PUT',
        credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: { 
            'Content-Type': 'application/json',
            'Authorization': authHeader()
         },
        body: user
    };
    return fetch(`${process.env.PUBLIC_URL}/api/user/update`, requestOptions)
        .then(response => {
            if(response.status === 200) {
                return response;
            } else {
                return Promise.reject('Error while creating a user.');
            }
        })
}

function getAllUsers() {
    const requestOptions = {
        headers: {'Authorization': authHeader()}
    };
    return fetch(`${process.env.PUBLIC_URL}/api/user`, requestOptions).then(handleResponse);
}

function getUserDetails(username) {
    const requestOptions = {
        headers: {'Authorization': authHeader()}
    };
    return fetch(`${process.env.PUBLIC_URL}/api/user/name/`+ username, requestOptions).then(handleResponse);
}

function deleteUser(userid) {
    const requestOptions = {
        method: 'DELETE',
        headers: {'Authorization': authHeader()}
    };
    return fetch(`${process.env.PUBLIC_URL}/api/user/id/`+ userid, requestOptions).then(handleResponse);
}

function handleResponseLogin(response) {
    return response.text().then(text => {
        try {
            const data = text && JSON.parse(text);
            if (!response.ok) {
                const error = 'Entered credentials are wrong.';
                return Promise.reject(error);
            }
            return data;
        } catch(e) {
            const error = 'Back end service is not available.';
            return Promise.reject(error);
        }
    });
}

function handleResponseTokenGenerate(response) {
    return response.text().then(text => {
        try {
            const data = text && JSON.parse(text);
            if (!response.ok) {
                logout();
                localStorage.setItem('sessionExpire', 'Session is expired. Please login again.');
                return Promise.reject('Session is expired. Please login again.');
            }
            return data;
        } catch(e) {
            logout();
            localStorage.setItem('sessionExpire', 'Session is expired. Please login again.');
            return Promise.reject('Session is expired. Please login again.');
        }
    });
}

// © [2023] Cognizant. All rights reserved.  Cognizant Confidential and/or Trade Secret.
// NOTICE: This unpublished material is proprietary to Cognizant and its suppliers,
// if any. The methods, techniques and technical concepts herein are considered Cognizant confidential
// and/or trade secret information. This material may be covered by U.S. and/or foreign patents or patent
// applications. Use, distribution or copying, in whole or in part, is forbidden, 
// except by express written permission of Cognizant.