import { authHeader, handleResponse } from '../_helpers';

export const licenseService = {

    getLicenseDetails,
    uploadLicenseFile,
    checkInstanceValidity
};

function handleError(error){
    return String(error)
}

function uploadLicenseFile(licenseFile,createdby) {
    const formdata = new FormData();
    formdata.append('file', licenseFile);
    formdata.append('createdBy', createdby);
    const requestOptions = {
        method: 'POST',
        credentials: 'include',
        mode: 'cors',
        cache: 'default',
        headers: { 
            'Authorization': authHeader()
         },
        body: formdata
    };
    return fetch(`${process.env.PUBLIC_URL}/api/license/upload`, requestOptions)
        .then(handleResponse);
}

function getLicenseDetails() {
    const requestOptions = {
        headers: {'Authorization': authHeader()}
    };
    return fetch(`${process.env.PUBLIC_URL}/api/license/getDetails`, requestOptions).then(handleResponse);
}

function checkInstanceValidity() {
    const requestOptions = {
        headers: {'Authorization': authHeader()}
    };
    return fetch(`${process.env.PUBLIC_URL}/api/license/checkLicenseValidity`, requestOptions).then(handleResponse)
}


// © [2023] Cognizant. All rights reserved.  Cognizant Confidential and/or Trade Secret.
// NOTICE: This unpublished material is proprietary to Cognizant and its suppliers,
// if any. The methods, techniques and technical concepts herein are considered Cognizant confidential
// and/or trade secret information. This material may be covered by U.S. and/or foreign patents or patent
// applications. Use, distribution or copying, in whole or in part, is forbidden, 
// except by express written permission of Cognizant.