import { authHeader, handleResponse } from "../_helpers";
import axios from "axios";

export function createModelConfiguration(data) {
  const requestOptions = {
    method: "POST",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/model-config-controller/receive_model_configuration`,
    requestOptions
  ).then(handleResponse);
}

export function getAllModelConfigurations(projectName) {
  const requestOptions = {
    method: "GET",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/model-config-controller/getModelConfigurationByProjectName/` +
      projectName,
    requestOptions
  ).then(handleResponse);
}

export function getAllModelPlusConfigurationList(projectName) {
  const requestOptions = {
    method: "GET",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/getModelPlusConfigurationList/` +
      projectName,
    requestOptions
  ).then(handleResponse);
}

export function getExistingModels(data) {
  const requestOptions = {
    method: "POST",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/model-config-controller/get_model_details`,
    requestOptions
  ).then(handleResponse);
}

export function createNewModel(data) {
  const requestOptions = {
    method: "POST",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/model-config-controller/create_new_model`,
    requestOptions
  ).then(handleResponse);
}

export function saveCredentialsforLangfuse(data) {
  const requestOptions = {
    method: "POST",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/model-config-controller/save_credentials`,
    requestOptions
  ).then(handleResponse);
}

export function updateModel(data) {
  const requestOptions = {
    method: "PUT",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/model-config-controller/update_model_details`,
    requestOptions
  ).then(handleResponse);
}

export function deleteModelConfiguration(id) {
  const requestOptions = {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/controller/deleteModelPlusConfiguration/` +
      id,
    requestOptions
  ).then(handleResponse);
}

export function deleteLlmModelConfiguration(id) {
  const requestOptions = {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/model-config-controller/deleteModeLlm/` +
      id,
    requestOptions
  ).then(handleResponse);
}


export function updateModelConfiguration(data) {
  const requestOptions = {
    method: "PUT",
    // credentials: 'include',
    mode: "cors",
    cache: "default",
    headers: {
      "Content-Type": "application/json",
      // 'Authorization': authHeader()
    },
    body: JSON.stringify(data),
  };
  return fetch(
    `${process.env.REACT_APP_BASE_API_URL}/model-config-controller/update_model_configuration`,
    requestOptions
  ).then(handleResponse);
}