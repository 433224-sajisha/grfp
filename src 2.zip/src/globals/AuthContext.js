import { createContext, useState } from "react";

export const AuthContext = createContext({
  //   accessToken: null,
  username: "",
  projectName: "",
  projectId: "",
  //   role: "",
  header: "",
  datasetId: "",
  executionId: "",
  projectSubType: "",
  //   updateAccessToken: () => {},
  //   removeAccessToken: () => {},
  updateUser: () => {},
  updateSelectedProject: () => { },
  updateProjectId: () => {},
  //   updateRole: () => {},
  updateHeader: () => {},
  updateDatasetId: () => { },
  updateExecutionId: () => { },
  updateProjectSubType: () => { },
});

export const AuthProvider = ({ children }) => {
  //   const [accessToken, setAccessToken] = useState(
  //     localStorage.getItem("accessToken")
  //   );
  const [username, setUsername] = useState(localStorage.getItem("username"));
  const [projectName, setProjectName] = useState(
    localStorage.getItem("selectedProject")
  );
  const [header, setHeader] = useState(localStorage.getItem("header") || "Heading");
  const [datasetId, setDatasetId] = useState("");
  const [executionId, setExecutionId] = useState(localStorage.getItem("executionId") || "");
  const [projectId, setProjectId] = useState(localStorage.getItem("selectedProjectId") || "");
  const [projectSubType, setProjectSubType] = useState(localStorage.getItem("selectedProjectSubType") || "");
  // localStorage.getItem("datasetId") || 
  //   const [role, setRole] = useState(localStorage.getItem("role"));

  //   function updateAccessToken(token) {
  //     localStorage.setItem("accessToken", "Bearer " + token);
  //     setAccessToken("Bearer " + token);
  //   }
  //
  //   function removeAccessToken() {
  //     localStorage.removeItem("accessToken");
  //   }

  function updateUser(name) {
    localStorage.setItem("username", name);
    setUsername(name);
  }

  function updateSelectedProject(projectName) {
    localStorage.setItem("selectedProject", projectName);
    setProjectName(projectName);
  }

  function updateProjectId(id) {
    localStorage.setItem("selectedProjectId", id);
    setProjectId(id);
  }

  function updateHeader(header) {
    localStorage.setItem("header", header);
    setHeader(header);
  }

  function updateDatasetId(id) {
    localStorage.setItem("datasetId", id);
    setDatasetId(id);
  }

  function updateExecutionId(id) {
    localStorage.setItem("executionId", id);
    setExecutionId(id);
  }

  function updateProjectSubType(subType) {
    localStorage.setItem("selectedProjectSubType", subType);
    setProjectSubType(subType);
  }

  //   function updateRole(role) {
  //     localStorage.setItem("role", role);
  //     setRole(role);
  //   }

  const ctxValue = {
    // accessToken,
    // updateAccessToken,
    // removeAccessToken,
    updateUser,
    username,
    updateSelectedProject,
    projectName,
    updateProjectId,
    projectId,
    updateHeader,
    header,
    updateDatasetId,
    datasetId,
    updateExecutionId,
    executionId,
    updateProjectSubType,
    projectSubType
    // role,
    // updateRole,
  };

  return (
    <AuthContext.Provider value={ctxValue}>{children}</AuthContext.Provider>
  );
};
