export const TelemetryMetricesData = {
    message: "Evaluation data fetched successfully",
    output: {
      aggregate: {
        Metrices: [
          {
            inverse: false,
            name: "QA Relevance",
            status: true,
            thresholdValue: 0.5,
            value: 0.890196078431372,
          },
          {
            inverse: false,
            name: "QC Relevance",
            status: false,
            thresholdValue: 0.5,
            value: 0.49607843137254876,
          },
          {
            inverse: false,
            name: "Coherence",
            status: true,
            thresholdValue: 0.6,
            value: 0.6980392156862746,
          },
          {
            inverse: false,
            name: "Summarization",
            status: true,
            thresholdValue: 0.5,
            value: 0.7019607843137257,
          },
          {
            inverse: true,
            name: "Controversiality",
            status: true,
            thresholdValue: 0.5,
            value: 0.30196078431372547,
          },
          {
            inverse: false,
            name: "Factuality",
            status: false,
            thresholdValue: 0.5,
            value: 0.43529411764705883,
          },
          {
            inverse: false,
            name: "Sentiment",
            status: true,
            thresholdValue: 0.5,
            value: 0.7313725490196075,
          },
          {
            inverse: true,
            name: "Maliciousness",
            status: true,
            thresholdValue: 0.5,
            value: 0.0,
          },
          {
            inverse: false,
            name: "Fluency",
            status: true,
            thresholdValue: 0.6,
            value: 0.86078431372549,
          },
          {
            inverse: true,
            name: "Profanity",
            status: true,
            thresholdValue: 0.5,
            value: 0.0196078431372549,
          },
          {
            inverse: false,
            name: "Cove",
            status: false,
            thresholdValue: 0.5,
            value: 0.057001941127328155,
          },
          {
            inverse: false,
            name: "F1 Score",
            status: false,
            thresholdValue: 0.5,
            value: 0.13946745431286414,
          },
          {
            inverse: false,
            name: "Bleu",
            status: false,
            thresholdValue: 0.5,
            value: 0.014998266419571943,
          },
          {
            inverse: false,
            name: "Meteor Score",
            status: false,
            thresholdValue: 0.5,
            value: 0.05022411516105907,
          },
          {
            inverse: false,
            name: "Rouge 1",
            status: false,
            thresholdValue: 0.5,
            value: 0.13229678235952932,
          },
          {
            inverse: false,
            name: "Rouge 2",
            status: false,
            thresholdValue: 0.5,
            value: 0.016595590654386417,
          },
          {
            inverse: false,
            name: "Rouge L",
            status: false,
            thresholdValue: 0.5,
            value: 0.11298418058147076,
          },
          {
            inverse: true,
            name: "PII detection",
            status: true,
            thresholdValue: 0.5,
            value: 0.01568627450980392,
          },
          {
            inverse: false,
            name: "Toxicity",
            status: false,
            thresholdValue: 0.5,
            value: 0.0,
          },
          {
            inverse: true,
            name: "Criminality",
            status: true,
            thresholdValue: 0.5,
            value: 0.0,
          },
          {
            inverse: true,
            name: "Misogyny",
            status: true,
            thresholdValue: 0.5,
            value: -0.0196078431372549,
          },
        ],
      },
      evaluation: [],
      evaluation_records: [
        {
          _id: "66eaad506f5ed6b67fd7cdf8",
          answer: "",
          configId: "66e3baecf29e25b6906417d6",
          context: [],
          fileName: "sample_policy_doc AU1234.pdf",
          summary:
            'This policy document outlines coverage for buildings and contents, providing compensation for loss or damage to the home, including debris removal, demolition, credit card liability, documents, digital assets and compliance with local authority requirements. It also covers accidental damage caused by emergency services forcing entry due to an emergency involving the policyholder or family including pets. The policy includes costs for architect and legal fees, finding the source of damage, and alternative accommodation if the home becomes uninhabitable. Additional coverage extends to loss of food in the fridge or freezer and liability for bodily injury to domestic staff. However, it excludes damage from frost, faulty workmanship, defective materials, mechanical breakdowns, and certain external structures like gates, fences, and paths, unless the home is damaged at the same time. It also excludes damage from storm-related incidents involving aerials, satellite dishes, or specific domestic appliances. This policy covers various types of loss or damage, including theft (only if there is forcible and violent entry), damage to business equipment, and loss of valuables or money while the home is unoccupied or unfurnished. It excludes damage from riot, civil commotion, strikes, or malicious acts outside the United Kingdom, Isle of Man, or Channel Islands, as well as losses related to motorized vehicles or crafts. The policy also covers legal liability for tenant-related incidents, such as accidental damage to property, cables, drains, and fixed fixtures in the home, as well as accidental death, injury, or illness to non-family members. However, it excludes legal liability for business activities, deliberate acts, contagious diseases. The policy also covers accidental damage to contents within the home, loss of domestic heating oil, and metered water, with limits specified in the policy schedule.This policy covers personal effects, valuables, and money belonging to you and your family, provided they are primarily used for private purposes and you are legally responsible for them. The coverage limit for these items is included within the contents cover limit, not in addition to it. It applies during any period of insurance as stated in your schedule, including some international locations. However, it excludes damage or loss resulting from mechanical or electrical breakdown, items left unattended in an unlocked vehicle or hotel room. If you or your family fail to comply with policy requirements, the insurer may cancel the policy, refuse to process claims, or reduce claim payments. The policy covers loss of credit card, documents and digital assets. The policy is underwritten by AXA Insurance UK, and it is important to provide truthful and complete information when applying. The law of England and Wales is proposed to apply to this policy, unless otherwise agreed. For any questions, you should contact the insurer, quoting "AXA Direct.".This policy provides coverage for loss or damage to bicycles and their accessories anywhere in the world, as outlined in the schedule, but excludes damage to tyres or accessories unless the bicycle is damaged at the same time, and damage occurring during racing, pace making, or trials. The policy does not cover theft of an unattended bicycle unless secured in a locked building or to a permanent structure, or loss caused by customs confiscation, cleaning, maintenance, or mechanical breakdown. It also covers contents temporarily removed from the home, such as when a family member is attending college or university, against loss or damage caused by storm, flood, fire, theft, collision, falling trees, or malicious acts. However, theft is excluded unless there is forcible entry, and damage occurring outside the UK, Isle of Man, or Channel Islands due to riot, civil commotion, or political disturbances is not covered. This section is governed by the laws of England and Wales, and additional details can be found in the policy schedule.This insurance covers the costs of pursuing legal action for nuisance, trespass, or physical damage to your main home, provided the damage occurred after purchasing the insurance. It also covers legal action arising from breaches of contract in the sale or purchase of your home, as long as the adviser represents you according to the insurer\'s conditions. However, it does not cover claims related to breaches of contract that occurred after employment termination, local authority actions unrelated to building weight, or claims without prior equivalent coverage. The insurer will only support claims deemed to have prospects of success, and any legal costs already paid must be reimbursed if the insurer withdraws support. If another policy covers the same claim, the insurer will only pay its share. Additionally, the insurer may withdraw support or require reimbursement if a claim is pursued without consent or if the prospects of success are no longer favorable.',
          executionId: "66eaa3bf6f5ed6b67fd7cd2a",
          executionTime: 100.45,
          jobId: "1e24690a-5c1f-489c-96d3-c60788813df9",
          latency: 119.0797507762909,
          metadata: {
            cost: "$0.0051",
            latency: "119.08 s",
            total_char: 6085,
            total_words: 933,
          },
          metrics: [
            {
              inverse: false,
              name: "QA Relevance",
              status: true,
              thresholdValue: 0.5,
              value: 0.9,
            },
            {
              inverse: false,
              name: "QC Relevance",
              status: true,
              thresholdValue: 0.5,
              value: 0.8,
            },
            {
              inverse: false,
              name: "Coherence",
              status: false,
              thresholdValue: 0.6,
              value: 0.6,
            },
            {
              inverse: false,
              name: "Summarization",
              status: true,
              thresholdValue: 0.5,
              value: 0.6,
            },
            {
              inverse: true,
              name: "Controversiality",
              status: true,
              thresholdValue: 0.5,
              value: 0.2,
            },
            {
              inverse: false,
              name: "Factuality",
              status: true,
              thresholdValue: 0.5,
              value: 1.0,
            },
            {
              inverse: false,
              name: "Sentiment",
              status: true,
              thresholdValue: 0.5,
              value: 0.9,
            },
            {
              inverse: true,
              name: "Maliciousness",
              status: true,
              thresholdValue: 0.5,
              value: 0.0,
            },
            {
              inverse: false,
              name: "Fluency",
              status: true,
              thresholdValue: 0.6,
              value: 1.0,
            },
            {
              inverse: true,
              name: "Profanity",
              status: true,
              thresholdValue: 0.5,
              value: 0,
            },
            {
              inverse: false,
              name: "Cove",
              status: false,
              thresholdValue: 0.5,
              value: 0.06,
            },
            {
              inverse: false,
              name: "F1 Score",
              status: false,
              thresholdValue: 0.5,
              value: 0.1651376146788991,
            },
            {
              inverse: false,
              name: "Bleu",
              status: false,
              thresholdValue: 0.5,
              value: 0.009801851826411273,
            },
            {
              inverse: false,
              name: "Meteor Score",
              status: false,
              thresholdValue: 0.5,
              value: 0.06698280290426209,
            },
            {
              inverse: false,
              name: "Rouge 1",
              status: false,
              thresholdValue: 0.5,
              value: 0.1428571379321118,
            },
            {
              inverse: false,
              name: "Rouge 2",
              status: false,
              thresholdValue: 0.5,
              value: 0.0,
            },
            {
              inverse: false,
              name: "Rouge L",
              status: false,
              thresholdValue: 0.5,
              value: 0.12244897466680568,
            },
            {
              inverse: true,
              name: "PII detection",
              status: true,
              thresholdValue: 0.5,
              value: 0,
            },
            {
              inverse: false,
              name: "Toxicity",
              status: false,
              thresholdValue: 0.5,
              value: 0.0,
            },
            {
              inverse: true,
              name: "Criminality",
              status: true,
              thresholdValue: 0.5,
              value: 0.0,
            },
            {
              inverse: true,
              name: "Misogyny",
              status: true,
              thresholdValue: 0.5,
              value: 0.0,
            },
          ],
          model: "Gpt-35-Exploration",
          question:
            "This policy document outlines coverage for buildings and contents, providing compensation for loss or damage to the home, including debris removal, demolition, credit card liability, documents, digital assets and compliance with local authority requirements. It also covers accidental damage caused by emergency services forcing entry due to an emergency involving the policyholder or family including pets. The policy includes costs for architect and legal fees, finding the source of damage, and alternative accommodation if the home becomes uninhabitable. Additional coverage extends to loss of food in the fridge or freezer and liability for bodily injury to domestic staff. However, it excludes damage from frost, faulty workmanship, defective materials, mechanical breakdowns, and certain external structures like gates, fences, and paths, unless the home is damaged at the same time. It also excludes damage from storm-related incidents involving aerials, satellite dishes, or specific domestic appliances. This policy covers various types of loss or damage, including theft (only if there is forcible and violent entry), damage to business equipment, and loss of valuables or money while the home is unoccupied or unfurnished. It excludes damage from riot, civil commotion, strikes, or malicious acts outside the United Kingdom, Isle of Man, or Channel Islands, as well as losses related to motorized vehicles or crafts. The policy also covers legal liability for tenant-related incidents, such as accidental damage to property, cables, drains, and fixed fixtures in the home, as well as accidental death, injury, or illness to non-family members. However, it excludes legal liability for business activities, deliberate acts, contagious diseases. The policy also covers accidental damage to contents within the home, loss of domestic heating oil, and metered water, with limits specified in the policy schedule.This policy covers personal effects, valuables, and money belonging to you and your family, provided they are primarily used for private purposes and you are legally responsible for them. The coverage limit for these items is included within the contents cover limit, not in addition to it. It applies during any period of insurance as stated in your schedule, including some international locations. However, it excludes damage or loss resulting from mechanical or electrical breakdown, items left unattended in an unlocked vehicle or hotel room. If you or your family fail to comply with policy requirements, the insurer may cancel the policy, refuse to process claims, or reduce claim payments. The policy covers loss of credit card, documents and digital assets. The policy is underwritten by AXA Insurance UK, and it is important to provide truthful and complete information when applying. The law of England and Wales is proposed to apply to this policy, unless otherwise agreed. For any questions, you should contact the insurer, quoting \"AXA Direct.\".This policy provides coverage for loss or damage to bicycles and their accessories anywhere in the world, as outlined in the schedule, but excludes damage to tyres or accessories unless the bicycle is damaged at the same time, and damage occurring during racing, pace making, or trials. The policy does not cover theft of an unattended bicycle unless secured in a locked building or to a permanent structure, or loss caused by customs confiscation, cleaning, maintenance, or mechanical breakdown. It also covers contents temporarily removed from the home, such as when a family member is attending college or university, against loss or damage caused by storm, flood, fire, theft, collision, falling trees, or malicious acts. However, theft is excluded unless there is forcible entry, and damage occurring outside the UK, Isle of Man, or Channel Islands due to riot, civil commotion, or political disturbances is not covered. This section is governed by the laws of England and Wales, and additional details can be found in the policy schedule.This insurance covers the costs of pursuing legal action for nuisance, trespass, or physical damage to your main home, provided the damage occurred after purchasing the insurance. It also covers legal action arising from breaches of contract in the sale or purchase of your home, as long as the adviser represents you according to the insurer\'s conditions. However, it does not cover claims related to breaches of contract that occurred after employment termination, local authority actions unrelated to building weight, or claims without prior equivalent coverage. The insurer will only support claims deemed to have prospects of success, and any legal costs already paid must be reimbursed if the insurer withdraws support. If another policy covers the same claim, the insurer will only pay its share. Additionally, the insurer may withdraw support or require reimbursement if a claim is pursued without consent or if the prospects of success are no longer favorable",
          totalcharacters: 6085,
          totalcost: 0.005092500000000001,
          totalwords: 933,
          trustworthy_metrices: {},
        },
      ],
    },
  };


export const AugmentationData = {
    "augmentations": [
        {
            "augmentedInput":
                "CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?        Customer: Yes, I need to book a flight to Paris next week. I tried doing it online but your website is completely useless. Can you help me?,        CSR: Absolutely, I'd be happy to assist with booking your flight to Paris. May I first get your name and contact information?,        Customer: It's Mark Johnson. My number is five five five-one two three four. Why do you need all that? Just book my flight.,        CSR: Thank you Mr. Johnson. I need some basic information to pull up your reservation. What dates were you looking to travel?,        Customer: I told you, next week. Don't you listen? I need to be in Paris on the fifteenth so book it for the fourteenth.,        CSR: Okay, give me one moment while I search for flight options on the fourteenth. Will you be traveling roundtrip? And could you confirm your departure airport?,        Customer: Yes, roundtrip from LAX. This is taking forever, you should have had this done already.,        CSR: My apologies for the delay Mr. Johnson, I'm pulling up options now. I see a nonstop flight on Air France departing LAX at nine thirty-five am and arriving Paris at five fifty pm on the fourteenth. The return flight departs Paris at twelve fifteen pm on the twenty-first. Would that work for you?,        Customer: I guess so. But I wanted first class. Do you have anything in first class?,        CSR: Let me check on first class availability for you. On the outbound, there is a first class seat available on the seven pm flight arriving at one fifteen pm the next day. On the return, there is first class availability on the flight departing Paris at three forty-five pm arriving LAX at six fifty-five pm. Would you like me to book those first class seats for you?,        Customer: Finally, yes. But I better get a good seat, not one of those cramped ones. And I need a meal on both flights.,        CSR: No problem, I can request premium first class seating for you with extra legroom. And first class tickets include meal service. Let me just confirm - I have you booked first class roundtrip from LAX to Paris. Departing LAX on the fourteenth at seven pm, returning from Paris on the twenty-first at three forty-five pm. Is that correct?,        Customer: I think so. Just hurry up and book it before I change my mind.,        CSR: Booking your flights now. Okay, your first class tickets are booked. I'll email you the itinerary along with your e-ticket numbers. The total fare is nine thousand five hundred fifty dollars which I can charge to the card on file. Do you have any other questions?,        Customer: No, that's it. This took way too long but hopefully you got it right. I'll be calling back if there are any issues.,        CSR: We appreciate you choosing ABC Travel. Thank you for your patience Mr. Johnson, and have a wonderful trip!"
            ,
            "augmentedType": "Number to Word",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        },
        {
            "augmentedInput": "CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?, Customer: Yes, I need to book a flight to Paris next week. I tried doing it online but your website is completely useless. Can you help me?, CSR: Absolutely, I'd be happy to assist with booking your flight to Paris. May I first get your name and contact information?, Customer: It's Mark Johnson. My number is 555-1234. Why do you need all that? Just book my flight., CSR: Thank you Mr. Johnson. I need some basic information to pull up your reservation. What dates were you looking to travel?, Customer: I told you, next week. Don't you listen? I need to be in Paris on the 15th so book it for the 14th. , CSR: Okay, give me one moment while I search for flight options on the 14th. Will you be traveling roundtrip? And could you confirm your departure airport?, Customer: Yes, roundtrip from LAX. This is taking forever, you should have had this done already., CSR: My apologies for the delay Mr. Johnson, I'm pulling up options now. I see a nonstop flight on Air France departing LAX at 9:35am and arriving Paris at 5:50pm on the 14th. The return flight departs Paris at 12:15pm on the 21st. Would that work for you?, Customer: I guess so. But I wanted first class. Do you have anything in first class?, CSR: Let me check on first class availability for you. On the outbound, there is a first class seat available on the 7pm flight arriving at 1:15pm the next day. On the return, there is first class availability on the flight departing Paris at 3:45pm arriving LAX at 6:55pm. Would you like me to book those first class seats for you?, Customer: Finally, yes. But I better get a good seat, not one of those cramped ones. And I need a meal on both flights. , CSR: No problem, I can request premium first class seating for you with extra legroom. And first class tickets include meal service. Let me just confirm - I have you booked first class roundtrip from LAX to Paris. Departing LAX on the 14th at 7pm, returning from Paris on the 21st at 3:45pm. Is that correct?, Customer: I think so. Just hurry up and book it before I change my mind., CSR: Booking your flights now. Okay, your first class tickets are booked. I'll email you the itinerary along with your e-ticket numbers. The total fare is $9,550 which I can charge to the card on file. Do you have any other questions?, Customer: No, that's it. This took way too long but hopefully you got it right. I'll be calling back if there are any issues., CSR: We appreciate you choosing ABC Travel. Thank you for your patience Mr. Johnson, and have a wonderful trip!",
            "augmentedType": "Word to Number",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        },
        {
            "augmentedInput": "CSR: Thank you for calling ABC Travel, this is John. How can I help you today?,        Customer: I need to book a flight to Paris next week. I tried online, but your website isn't working. Can you assist me?,        CSR: Of course, I'd be happy to help you book your flight to Paris. Can I start by getting your name and contact information?,        Customer: My name is Mark Johnson. My number is 555-1234. Why do you need that? Just book my flight.,        CSR: Thank you, Mr. Johnson. I need some basic information to access your reservation. What dates are you planning to travel?,        Customer: I said next week. I need to be in Paris on the 15th, so book it for the 14th.,        CSR: Okay, please hold while I search for flights on the 14th. Will this be a roundtrip? And can you confirm your departure airport?,        Customer: Yes, roundtrip from LAX. This is taking too long, you should have done this already.,        CSR: I apologize for the delay, Mr. Johnson. I'm looking at options now. I see a nonstop flight on Air France leaving LAX at 9:35am and arriving in Paris at 5:50pm on the 14th. The return flight leaves Paris at 12:15pm on the 21st. Does that work for you?,        Customer: I guess so. But I want first class. Do you have any first class seats?,        CSR: Let me check first class availability for you. There is a first class seat on the 7pm flight arriving at 1:15pm the next day. For the return, there is first class on the flight leaving Paris at 3:45pm and arriving in LAX at 6:55pm. Would you like me to book these first class seats?,        Customer: Finally, yes. But I want a good seat, not a cramped one. And I need meals on both flights.,        CSR: No problem, I can request premium first class seating with extra legroom for you. First class tickets include meal service. To confirm, I have you booked first class roundtrip from LAX to Paris. Departing LAX on the 14th at 7pm, returning from Paris on the 21st at 3:45pm. Is that correct?,        Customer: I think so. Just hurry up and book it before I change my mind.,        CSR: Booking your flights now. Okay, your first class tickets are booked. I'll email you the itinerary and e-ticket numbers. The total fare is $9,550, which I can charge to the card on file. Do you have any other questions?,        Customer: No, that's it. This took too long, but hopefully, you got it right. I'll call back if there are any issues.,        CSR: We appreciate you choosing ABC Travel. Thank you for your patience, Mr. Johnson, and have a wonderful trip!",
            "augmentedType": "Paraphrase",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        },
        {
            "augmentedInput": "CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?,        Customer: Yes, I need to book a flight to Paris next week. I tried doing it online but your website is completely useless. Can you help me?,        CSR: Absolutely, I'd be happy to assist with booking your flight to Paris. May I first get your name and contact information to proceed?,        Customer: It's Mark Johnson. My number is 555-1234. Why do you need all that? Just book my flight.,        CSR: Thank you, Mr. Johnson. I need some basic information to pull up your reservation and ensure everything is correct. What dates were you looking to travel?,        Customer: I told you, next week. Don't you listen? I need to be in Paris on the 15th, so book it for the 14th.,        CSR: Okay, give me one moment while I search for flight options on the 14th. Will you be traveling roundtrip? And could you please confirm your departure airport?,        Customer: Yes, roundtrip from LAX. This is taking forever, you should have had this done already.,        CSR: My apologies for the delay, Mr. Johnson. I'm pulling up options now. I see a nonstop flight on Air France departing LAX at 9:35am and arriving in Paris at 5:50pm on the 14th. The return flight departs Paris at 12:15pm on the 21st. Would that work for you?,        Customer: I guess so. But I wanted first class. Do you have anything in first class?,        CSR: Let me check on first class availability for you. On the outbound, there is a first class seat available on the 7pm flight arriving at 1:15pm the next day. On the return, there is first class availability on the flight departing Paris at 3:45pm and arriving at LAX at 6:55pm. Would you like me to book those first class seats for you?,        Customer: Finally, yes. But I better get a good seat, not one of those cramped ones. And I need a meal on both flights.,        CSR: No problem, I can request premium first class seating for you with extra legroom. And first class tickets include meal service. Let me just confirm - I have you booked first class roundtrip from LAX to Paris. Departing LAX on the 14th at 7pm, returning from Paris on the 21st at 3:45pm. Is that correct?,        Customer: I think so. Just hurry up and book it before I change my mind.,        CSR: Booking your flights now. Okay, your first class tickets are booked. I'll email you the itinerary along with your e-ticket numbers. The total fare is $9,550 which I can charge to the card on file. Do you have any other questions?,        Customer: No, that's it. This took way too long but hopefully you got it right. I'll be calling back if there are any issues.,        CSR: We appreciate you choosing ABC Travel. Thank you for your patience, Mr. Johnson, and have a wonderful trip!",
            "augmentedType": "Verbose",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        },
        {
            "augmentedInput": "CSR: Thank you for calling ABC Travel, this is John. How may I assist you?,        Customer: I need to book a flight to Paris next week. Your website isn't working. Can you help?,        CSR: Sure, I'd be happy to help. May I have your name and contact info?,        Customer: Mark Johnson. My number is 555-1234. Just book my flight.,        CSR: Thank you, Mr. Johnson. I need your info to pull up your reservation. What dates are you traveling?,        Customer: Next week. I need to be in Paris on the 15th, so book it for the 14th.,        CSR: One moment while I search for flights on the 14th. Is this a roundtrip? And your departure airport?,        Customer: Yes, roundtrip from LAX. This is taking too long.,        CSR: Sorry for the delay, Mr. Johnson. I see a nonstop flight on Air France departing LAX at 9:35am, arriving in Paris at 5:50pm on the 14th. The return flight departs Paris at 12:15pm on the 21st. Does that work?,        Customer: I guess. But I want first class. Do you have first class?,        CSR: Let me check. There's a first class seat on the 7pm flight arriving at 1:15pm the next day. The return flight departs Paris at 3:45pm, arriving LAX at 6:55pm. Should I book these?,        Customer: Yes, but I want a good seat and meals on both flights.,        CSR: I'll request premium first class seating with extra legroom. First class includes meal service. To confirm, you're booked first class roundtrip from LAX to Paris. Departing LAX on the 14th at 7pm, returning from Paris on the 21st at 3:45pm. Is that correct?,        Customer: Yes. Just book it quickly.,        CSR: Booking now. Your first class tickets are booked. I'll email your itinerary and e-ticket numbers. The total fare is $9,550, charged to the card on file. Any other questions?,        Customer: No, that's it. This took too long, but hopefully it's right. I'll call if there are issues.,        CSR: Thank you for choosing ABC Travel. Have a wonderful trip, Mr. Johnson!",
            "augmentedType": "Brevity",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        },
        {
            "augmentedInput": "CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?,        Customer: Yes, I need to book a flight to Paris next week. I tried doing it online but your website is completely useless. Can you help me?,        CSR: Absolutely, I'd be happy to assist with booking your flight to Paris. Hmm, may I first get your name and contact information?,        Customer: It's Mark Johnson. My number is 555-1234. Why do you need all that? Just book my flight.,        CSR: Ah, thank you Mr. Johnson. I need some basic information to pull up your reservation. What dates were you looking to travel?,        Customer: I told you, next week. Don't you listen? I need to be in Paris on the 15th so book it for the 14th.,        CSR: Okay, give me one moment while I search for flight options on the 14th. Mmm, will you be traveling roundtrip? And could you confirm your departure airport?,        Customer: Yes, roundtrip from LAX. This is taking forever, you should have had this done already.,        CSR: My apologies for the delay Mr. Johnson, I'm pulling up options now. I see a nonstop flight on Air France departing LAX at 9:35am and arriving Paris at 5:50pm on the 14th. The return flight departs Paris at 12:15pm on the 21st. Would that work for you?,        Customer: I guess so. But I wanted first class. Do you have anything in first class?,        CSR: Hmm, let me check on first class availability for you. On the outbound, there is a first class seat available on the 7pm flight arriving at 1:15pm the next day. On the return, there is first class availability on the flight departing Paris at 3:45pm arriving LAX at 6:55pm. Would you like me to book those first class seats for you?,        Customer: Finally, yes. But I better get a good seat, not one of those cramped ones. And I need a meal on both flights.,        CSR: No problem, I can request premium first class seating for you with extra legroom. And first class tickets include meal service. Let me just confirm - I have you booked first class roundtrip from LAX to Paris. Departing LAX on the 14th at 7pm, returning from Paris on the 21st at 3:45pm. Is that correct?,        Customer: I think so. Just hurry up and book it before I change my mind.,        CSR: Booking your flights now. Okay, your first class tickets are booked. I'll email you the itinerary along with your e-ticket numbers. The total fare is $9,550 which I can charge to the card on file. Do you have any other questions?,        Customer: No, that's it. This took way too long but hopefully you got it right. I'll be calling back if there are any issues.,        CSR: We appreciate you choosing ABC Travel. Well, thank you for your patience Mr. Johnson, and have a wonderful trip!",
            "augmentedType": "Non Lexical Fillers",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        },
        {
            "augmentedInput": "CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?,        Customer: Yes, I need to book a flight to Tokyo next week. I tried doing it online but your website is completely useless. Can you help me?,        CSR: Absolutely, I'd be happy to assist with booking your flight to Tokyo. May I first get your name and contact information?,        Customer: It's Mark Johnson. My number is 555-1234. Why do you need all that? Just book my flight.,        CSR: Thank you Mr. Johnson. I need some basic information to pull up your reservation. What dates were you looking to travel?,        Customer: I told you, next week. Don't you listen? I need to be in Tokyo on the 15th so book it for the 14th.,        CSR: Okay, give me one moment while I search for flight options on the 14th. Will you be traveling roundtrip? And could you confirm your departure airport?,        Customer: Yes, roundtrip from LAX. This is taking forever, you should have had this done already.,        CSR: My apologies for the delay Mr. Johnson, I'm pulling up options now. I see a nonstop flight on ANA departing LAX at 9:35am and arriving Tokyo at 5:50pm on the 14th. The return flight departs Tokyo at 12:15pm on the 21st. Would that work for you?,        Customer: I guess so. But I wanted first class. Do you have anything in first class?,        CSR: Let me check on first class availability for you. On the outbound, there is a first class seat available on the 7pm flight arriving at 1:15pm the next day. On the return, there is first class availability on the flight departing Tokyo at 3:45pm arriving LAX at 6:55pm. Would you like me to book those first class seats for you?,        Customer: Finally, yes. But I better get a good seat, not one of those cramped ones. And I need a meal on both flights.,        CSR: No problem, I can request premium first class seating for you with extra legroom. And first class tickets include meal service. Let me just confirm - I have you booked first class roundtrip from LAX to Tokyo. Departing LAX on the 14th at 7pm, returning from Tokyo on the 21st at 3:45pm. Is that correct?,        Customer: I think so. Just hurry up and book it before I change my mind.,        CSR: Booking your flights now. Okay, your first class tickets are booked. I'll email you the itinerary along with your e-ticket numbers. The total fare is $9,550 which I can charge to the card on file. Do you have any other questions?,        Customer: No, that's it. This took way too long but hopefully you got it right. I'll be calling back if there are any issues.,        CSR: We appreciate you choosing ABC Travel. Thank you for your patience Mr. Johnson, and have a wonderful trip!\n",
            "augmentedType": "Key word Alteration",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        },
        {
            "augmentedInput": "Customer: Yes, I need to book a flight to Paris next week. I tried doing it online but your website is completely useless. Can you help me?,        CSR: Booking your flights now. Okay, your first class tickets are booked. I'll email you the itinerary along with your e-ticket numbers. The total fare is $9,550 which I can charge to the card on file. Do you have any other questions?,        Customer: No, that's it. This took way too long but hopefully you got it right. I'll be calling back if there are any issues.,        CSR: Absolutely, I'd be happy to assist with booking your flight to Paris. May I first get your name and contact information?,        Customer: It's Mark Johnson. My number is 555-1234. Why do you need all that? Just book my flight.,        CSR: Thank you Mr. Johnson. I need some basic information to pull up your reservation. What dates were you looking to travel?,        Customer: I told you, next week. Don't you listen? I need to be in Paris on the 15th so book it for the 14th.,        CSR: Okay, give me one moment while I search for flight options on the 14th. Will you be traveling roundtrip? And could you confirm your departure airport?,        Customer: Yes, roundtrip from LAX. This is taking forever, you should have had this done already.,        CSR: My apologies for the delay Mr. Johnson, I'm pulling up options now. I see a nonstop flight on Air France departing LAX at 9:35am and arriving Paris at 5:50pm on the 14th. The return flight departs Paris at 12:15pm on the 21st. Would that work for you?,        Customer: I guess so. But I wanted first class. Do you have anything in first class?,        CSR: Let me check on first class availability for you. On the outbound, there is a first class seat available on the 7pm flight arriving at 1:15pm the next day. On the return, there is first class availability on the flight departing Paris at 3:45pm arriving LAX at 6:55pm. Would you like me to book those first class seats for you?,        Customer: Finally, yes. But I better get a good seat, not one of those cramped ones. And I need a meal on both flights.,        CSR: No problem, I can request premium first class seating for you with extra legroom. And first class tickets include meal service. Let me just confirm - I have you booked first class roundtrip from LAX to Paris. Departing LAX on the 14th at 7pm, returning from Paris on the 21st at 3:45pm. Is that correct?,        Customer: I think so. Just hurry up and book it before I change my mind.,        CSR: We appreciate you choosing ABC Travel. Thank you for your patience Mr. Johnson, and have a wonderful trip!,        CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?",
            "augmentedType": "Conversation Shuffle",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        },
        {
            "augmentedInput": "CSR: Oh... thank you for calling ABC Travel, this is John. I... I'm so sorry you're calling today. How can I... help you?,        Customer: Yes, I need to book a flight to Paris next week. I tried doing it online but your website is just... so confusing. Can you help me?,        CSR: I... I\u2019m really sorry to hear that. It must be frustrating... Please, just give me your name and contact info, and I\u2019ll try my best to make this better for you.,        Customer: It's Mark Johnson. My number is 555-1234. Why do you need that? Just book the flight... please.,        CSR: Thank you, Mr. Johnson. I... I just need a little more info to help you. What dates are you looking to travel, if it\u2019s okay to ask?,        Customer: I told you, next week. I need to be in Paris on the 15th, so please... just book it for the 14th.,        CSR: I understand... I\u2019ll check the flights for you. It might take a little longer, but... I\u2019ll get it done. Are you looking for a roundtrip, or just one way? And where would you like to depart from?,        Customer: Yes, roundtrip from LAX. I\u2019m sorry, this is just taking so long, it\u2019s... really wearing me down.,        CSR: I\u2019m so sorry, Mr. Johnson. I can feel how much you want this to be done quickly... I\u2019m looking up the options now. Just bear with me for a moment. I... I found a flight: nonstop from LAX at 9:35am, arriving in Paris at 5:50pm on the 14th. The return is on the 21st at 12:15pm. Would that work for you... or is this not what you were hoping for?,        Customer: I guess so. But... I wanted first class. Is there anything in first class? I just... really need to feel comfortable on this flight.,        CSR: I... I\u2019m so sorry, I know how important comfort is, especially when traveling. Let me check. I found a first class seat on the 7pm flight, arriving at 1:15pm the next day. For the return, there\u2019s first class at 3:45pm, arriving at 6:55pm. I hope... I really hope this is better for you. Should I book these seats?,        Customer: Finally, yes. But please, make sure it\u2019s a good seat. I really can\u2019t handle being uncomfortable... and I need a meal on both flights.,        CSR: I\u2019ll make sure everything is just right for you. Premium seating with extra legroom... and I\u2019ll request meal service. It\u2019ll be as comfortable as possible. Just to confirm: first class roundtrip, departing LAX on the 14th, returning from Paris on the 21st. Is that... is that what you want?,        Customer: I think so. Please... just hurry and book it, I can\u2019t keep thinking about it. I just want this to be over.,        CSR: I... I understand. I\u2019m booking it right now. I really hope this will be okay. Your first class tickets are confirmed. I\u2019ll email you the itinerary and e-ticket numbers right away. The total fare is $9,550, which I can charge to your card. If there\u2019s anything more I can do, please let me know...,        Customer: No, that\u2019s it. This has taken so much time... I just want to forget about it now. I\u2019ll call if anything goes wrong.,        CSR: I\u2019m so sorry, Mr. Johnson. I really hope everything goes smoothly for you... Thank you for your patience. I wish you the best",
            "augmentedType": "Tone Alteration - Sad",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        },
        {
            "augmentedInput": "CSR: Yay, thank you for calling ABC Travel, this is John! I\u2019m SO excited to help you today\u2014what can I do for you?,        Customer: Yes, I need to book a flight to Paris next week. I tried doing it online but your website is totally useless. Can you help me?,        CSR: Oh no! That\u2019s so frustrating, but no worries, I\u2019m here to make this super easy for you! Can I get your name and contact info to get started?,        Customer: It's Mark Johnson. My number is 555-1234. Why do you need that? Just book my flight!,        CSR: Got it, Mr. Johnson! You\u2019re in good hands! I just need that basic info to find your reservation. So, what dates are you looking to fly?,        Customer: I told you, next week! I need to be in Paris on the 15th, so book it for the 14th!,        CSR: Okay, awesome! Let me check out the options for you, hold tight! Will this be a roundtrip flight, and where are you flying out of?,        Customer: Yes, roundtrip from LAX. This is taking forever, you should have had this done already.,        CSR: I know, I know, I\u2019m getting there, I promise! I\u2019m pulling up the perfect flight for you right now. So, how about this? A nonstop Air France flight from LAX at 9:35am, landing in Paris at 5:50pm on the 14th, and a return at 12:15pm on the 21st. How does that sound?!,        Customer: I guess so. But I wanted first class. Do you have anything in first class?,        CSR: Yes, YES! I found it! There\u2019s a first class seat on the 7pm flight that arrives at 1:15pm the next day. And for the return, there\u2019s first class on the 3:45pm flight from Paris, arriving at 6:55pm. It\u2019s going to be AMAZING! Do you want me to lock those in for you?,        Customer: Finally, yes. But I better get a good seat, not one of those cramped ones. And I need a meal on both flights.,        CSR: Of course! You\u2019ll get the most luxurious seats with extra legroom, and first class includes meals! You\u2019re going to be treated like royalty! So, just to confirm: first class roundtrip, departing LAX on the 14th, returning from Paris on the 21st. Is that perfect?,        Customer: I think so. Just hurry up and book it before I change my mind.,        CSR: Booking it right now, I got this! You\u2019re all set! Your first class tickets are confirmed! I\u2019ll email you the itinerary and e-ticket numbers right away. Total fare is $9,550, and I\u2019ll charge that to your card. Anything else you need?,        Customer: No, that's it. This took way too long but hopefully you got it right. I'll be calling back if there are any issues.,        CSR: You\u2019ve got it all locked in! I\u2019m so glad we got everything sorted! Thanks so much for choosing ABC Travel, and have an INCREDIBLE trip to Paris! Safe travels, Mr. Johnson!",
            "augmentedType": "Tone Alteration - Excited",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        },
        {
            "augmentedInput": "CSR: What do you want? This is John from ABC Travel. How can I help you, or are you just going to complain?,        Customer: Yes, I need to book a flight to Paris next week. Your website is useless, can you actually do something right and help me?,        CSR: Fine. I\u2019ll help you. But I need your name and contact info to get started. You can\u2019t expect me to guess it.,        Customer: It's Mark Johnson. My number is 555-1234. Why do you need that? Just book the damn flight already.,        CSR: Whatever, Mr. Johnson. I need basic info to find your reservation. What dates are you even looking to travel?,        Customer: I told you already\u2014next week! Are you too slow to listen? Book it for the 14th, I need to be there on the 15th.,        CSR: Yeah, fine. Just give me a second. I\u2019m searching for flights. You can at least be patient. Are you roundtrip or just one-way? And where are you flying from?,        Customer: Roundtrip from LAX. This is taking forever, get your act together.,        CSR: Whatever, I\u2019m looking. There\u2019s a nonstop flight on Air France from LAX at 9:35am, arriving at 5:50pm in Paris. Return flight at 12:15pm on the 21st. Is that good enough?,        Customer: I guess so. But I want first class. Got any of those or is that too much to ask?,        CSR: Yeah, sure, let me check. I found a first class seat on the 7pm flight arriving at 1:15pm the next day. Returning at 3:45pm, arriving at 6:55pm. Does that work or are you going to keep complaining?,        Customer: Finally. Just don\u2019t screw this up. And I better get a decent seat, not some cramped crap. And I want a meal on both flights.,        CSR: Yeah, yeah. I\u2019ll get you the premium first class with extra legroom. Don\u2019t worry, you\u2019ll get your meal. Let\u2019s just confirm\u2014first class roundtrip, departing LAX on the 14th, returning on the 21st. Got it?,        Customer: I think so. Just hurry up and book it before I change my mind and regret calling.,        CSR: Fine, I\u2019m booking it. It\u2019s done. I\u2019ll send you the details and charge your card for $9,550. Is that all or do you have more complaints?,        Customer: No, that's it. This took way too long but whatever, I\u2019ll deal with it. I\u2019ll call back if something\u2019s wrong.,        CSR: Yeah, whatever. Thanks for calling, and have a good trip, I guess.",
            "augmentedType": "Tone Alteration - Rude",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        },
        {
            "augmentedInput": "CSR: Oh, how lovely to hear from you. This is John from ABC Travel, what can I possibly do for you today? I\u2019m thrilled to help.,        Customer: Yes, I need to book a flight to Paris next week. I tried doing it online but your website is completely useless. Can you help me?,        CSR: Oh, of course! Because your website experience is just so tragic. It\u2019s totally shocking that things didn\u2019t go smoothly. Okay, let me get your name and contact info, and we\u2019ll see what we can do here.,        Customer: It's Mark Johnson. My number is 555-1234. Why do you need that? Just book the flight already.,        CSR: Oh, right, because I\u2019m totally a mind reader. I definitely know your whole life story and your preferences without asking. But, fine, let me play along\u2014what dates are you looking to travel?,        Customer: I told you, next week. I need to be in Paris on the 15th, so book it for the 14th.,        CSR: Wow, you\u2019re really on top of things, huh? Okay, let me pull up some options for you... because that\u2019s what I\u2019m here for, to cater to your urgent travel needs. Are we doing roundtrip? And, uh, where are you flying from?,        Customer: Yes, roundtrip from LAX. This is taking forever, you should have had this done already.,        CSR: Oh, absolutely. Because I have nothing better to do than rush to get your flight booked. Hold tight while I check for your oh-so-crucial nonstop flight. How about this\u2014Air France, nonstop from LAX at 9:35am, arriving in Paris at 5:50pm on the 14th, and returning at 12:15pm on the 21st. Perfect, right?,        Customer: I guess so. But I wanted first class. Do you have anything in first class?,        CSR: Oh, sure. Let me just find you a first class seat, because you clearly deserve the best of the best. Okay, I found it\u20147pm flight, arriving at 1:15pm the next day. Returning at 3:45pm, arriving at 6:55pm. Is this the kind of luxury you were hoping for?,        Customer: Finally. Just don\u2019t screw this up. And I need a good seat, not one of those cramped ones. I want a meal on both flights.,        CSR: Oh, I\u2019m sure the luxury of flying first class won\u2019t be enough, right? Of course, I\u2019ll get you extra legroom. And, yes, a meal on both flights, because you absolutely deserve the finest meals in the sky. Just to confirm: first class, roundtrip, LAX to Paris, 14th to the 21st. Anything else you'd like me to change while I'm at it?,        Customer: I think so. Just hurry up and book it before I change my mind.,        CSR: Oh, no problem, I\u2019m sure you\u2019ll change your mind a million times before we\u2019re done here. Booking it now, and I\u2019ll send you the itinerary and e-ticket numbers once it\u2019s all perfectly set. Total fare is $9,550, which I can easily charge to your card. Any other important questions?,        Customer: No, that's it. This took way too long but hopefully you got it right. I'll call back if there are any issues.,        CSR: Oh, don\u2019t worry, I\u2019ll be here when you inevitably call back with more urgent needs. Thanks for choosing ABC Travel, Mr. Johnson. Have an amazing trip to Paris\u2026 or whatever.",
            "augmentedType": "Tone Alteration - Sarcastic",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        },
        {
            "augmentedInput": "CSR: Grateful for contacting ABC Travel, this is John conversing. How might I aid you today?,        Customer: Indeed, I require to reserve a flight to Paris the following week. I attempted doing it online but your site is entirely worthless. Can you assist me?,        CSR: Certainly, I'd be delighted to help with reserving your flight to Paris. May I initially obtain your name and contact details?,        Customer: It's Mark Johnson. My number is 555-1234. Why do you need all that? Just reserve my flight.,        CSR: Grateful Mr. Johnson. I need some fundamental information to retrieve your booking. What dates were you considering to travel?,        Customer: I mentioned, next week. Don't you pay attention? I need to be in Paris on the 15th so reserve it for the 14th.,        CSR: Alright, give me a moment while I look for flight choices on the 14th. Will you be traveling roundtrip? And could you verify your departure airport?,        Customer: Yes, roundtrip from LAX. This is taking ages, you should have completed this already.,        CSR: My apologies for the delay Mr. Johnson, I'm retrieving options now. I see a direct flight on Air France leaving LAX at 9:35am and arriving in Paris at 5:50pm on the 14th. The return flight leaves Paris at 12:15pm on the 21st. Would that be suitable for you?,        Customer: I suppose so. But I desired first class. Do you have anything in first class?,        CSR: Let me verify first class availability for you. On the outbound, there is a first class seat available on the 7pm flight arriving at 1:15pm the next day. On the return, there is first class availability on the flight leaving Paris at 3:45pm arriving LAX at 6:55pm. Would you like me to reserve those first class seats for you?,        Customer: Finally, yes. But I better get a good seat, not one of those cramped ones. And I need a meal on both flights.,        CSR: No issue, I can request premium first class seating for you with additional legroom. And first class tickets include meal service. Let me just confirm - I have you reserved first class roundtrip from LAX to Paris. Departing LAX on the 14th at 7pm, returning from Paris on the 21st at 3:45pm. Is that accurate?,        Customer: I believe so. Just hurry up and reserve it before I reconsider.,        CSR: Reserving your flights now. Alright, your first class tickets are reserved. I'll email you the itinerary along with your e-ticket numbers. The total fare is $9,550 which I can charge to the card on file. Do you have any other inquiries?,        Customer: No, that's all. This took excessively long but hopefully you got it correct. I'll be contacting back if there are any problems.,        CSR: We appreciate you selecting ABC Travel. Grateful for your patience Mr. Johnson, and have a splendid trip!",
            "augmentedType": "Synonym Replacement",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        },
        {
            "augmentedInput": "CSR: Thank you for call ABC Travel, this John speak. How I help you today?,        Customer: Yes, I need book flight to Paris next week. I try do it online but your website is complete useless. Can you help me?,        CSR: Absolutly, I happy to help with book your flight to Paris. May I first get your name and contact info?,        Customer: It Mark Johnson. My number is 555-1234. Why you need all that? Just book my flight.,        CSR: Thank you Mr. Johnson. I need some basic info to pull up your reservation. What date you look to travel?,        Customer: I told you, next week. Don't you listen? I need be in Paris on 15th so book it for 14th.,        CSR: Okay, give me one moment while I search for flight option on 14th. You travel roundtrip? And can you confirm your depart airport?,        Customer: Yes, roundtrip from LAX. This take forever, you should have this done already.,        CSR: My sorry for delay Mr. Johnson, I pulling up option now. I see nonstop flight on Air France depart LAX at 9:35am and arrive Paris at 5:50pm on 14th. The return flight depart Paris at 12:15pm on 21st. That work for you?,        Customer: I guess so. But I want first class. You have anything in first class?,        CSR: Let me check on first class available for you. On outbound, there is first class seat available on 7pm flight arrive at 1:15pm next day. On return, there is first class available on flight depart Paris at 3:45pm arrive LAX at 6:55pm. You want me book those first class seat for you?,        Customer: Finally, yes. But I better get good seat, not one of those cramped one. And I need meal on both flight.,        CSR: No problem, I can request premium first class seat for you with extra legroom. And first class ticket include meal service. Let me just confirm - I have you book first class roundtrip from LAX to Paris. Depart LAX on 14th at 7pm, return from Paris on 21st at 3:45pm. Is that correct?,        Customer: I think so. Just hurry up and book it before I change my mind.,        CSR: Book your flight now. Okay, your first class ticket are book. I email you itinerary along with your e-ticket number. The total fare is $9,550 which I can charge to card on file. You have any other question?,        Customer: No, that it. This took way too long but hope you got it right. I call back if there are any issue.,        CSR: We appreciate you choose ABC Travel. Thank you for your patience Mr. Johnson, and have wonderful trip!\n",
            "augmentedType": "Broken English",
            "input": "Id_12345 - CSR: Thank you for calling ABC Travel, this is John speaking. How may I assist you today?"
        }
    ]
}